declare module 'simple-peer' {
  import { EventEmitter } from 'events';

  interface SimplePeerOptions {
    initiator?: boolean;
    channelConfig?: object;
    channelName?: string;
    config?: object;
    offerConstraints?: object;
    answerConstraints?: object;
    sdpTransform?: (sdp: string) => string;
    stream?: MediaStream;
    streams?: MediaStream[];
    trickle?: boolean;
    allowHalfTrickle?: boolean;
    objectMode?: boolean;
    wrtc?: object;
  }

  interface SimplePeerData {
    type: string;
    sdp: string;
  }

  declare class SimplePeer extends EventEmitter {
    constructor(opts?: SimplePeerOptions);
    signal(data: any): void;
    send(data: string | Blob | ArrayBuffer | ArrayBufferView): void;
    destroy(err?: Error): void;
    on(event: 'signal', listener: (data: any) => void): this;
    on(event: 'connect', listener: () => void): this;
    on(event: 'data', listener: (data: any) => void): this;
    on(event: 'stream', listener: (stream: MediaStream) => void): this;
    on(event: 'track', listener: (track: MediaStreamTrack, stream: MediaStream) => void): this;
    on(event: 'close', listener: () => void): this;
    on(event: 'error', listener: (err: Error) => void): this;
    on(event: string, listener: (...args: any[]) => void): this;
  }

  export = SimplePeer;
}