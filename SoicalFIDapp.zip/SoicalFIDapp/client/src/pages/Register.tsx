import { useState } from "react";
import { useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { useAuth } from "@/contexts/Web3Context";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, LogIn, Wallet, UserPlus } from "lucide-react";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";

const registerSchema = z.object({
  username: z
    .string()
    .min(3, { message: "Username must be at least 3 characters." })
    .max(50, { message: "Username must be less than 50 characters." }),
  password: z
    .string()
    .min(8, { message: "Password must be at least 8 characters." }),
  email: z
    .string()
    .email({ message: "Please enter a valid email address." }),
  walletAddress: z
    .string()
    .optional()
});

export default function Register() {
  const [_, navigate] = useLocation();
  const { connectWallet, isConnecting, account } = useAuth();
  const { toast } = useToast();
  
  // Form for registration
  const form = useForm<z.infer<typeof registerSchema>>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: "",
      password: "",
      email: "",
      walletAddress: ""
    },
  });
  
  // Effect to update wallet address in form when connected
  useState(() => {
    if (account) {
      form.setValue('walletAddress', account);
    }
  });
  
  // Registration mutation
  const registerMutation = useMutation({
    mutationFn: async (data: z.infer<typeof registerSchema>) => {
      return apiRequest('/api/users/register', 'POST', data);
    },
    onSuccess: (data) => {
      toast({
        title: "Registration successful",
        description: "Welcome to DappDate! Let's create your profile.",
      });
      
      // In a real app, would handle authentication state
      // Redirect to complete profile setup
      navigate("/profile");
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Registration failed",
        description: error instanceof Error ? error.message : "Could not create account",
      });
    }
  });
  
  // Handle form submission
  const onSubmit = async (values: z.infer<typeof registerSchema>) => {
    // 如果未連接錢包，則嘗試連接
    if (!values.walletAddress && !account) {
      try {
        const walletAddress = await connectWallet();
        if (walletAddress) {
          values.walletAddress = walletAddress;
        }
      } catch (error) {
        toast({
          variant: "destructive",
          title: "錢包連接失敗",
          description: "請連接您的錢包以繼續註冊",
        });
        return;
      }
    }
    
    // 使用已連接的錢包地址或輸入的地址
    values.walletAddress = account || values.walletAddress;
    
    if (!values.walletAddress) {
      toast({
        variant: "destructive",
        title: "需要錢包",
        description: "註冊需要提供錢包地址",
      });
      return;
    }
    
    // 模擬註冊成功
    toast({
      title: "註冊成功",
      description: "歡迎來到 C_C！讓我們創建您的個人資料。",
    });
    
    // 等待一會兒後重定向到登錄頁面
    setTimeout(() => {
      navigate("/login");
    }, 1500);
  };
  
  // Handle wallet connection
  const handleConnectWallet = async () => {
    try {
      const walletAddress = await connectWallet();
      
      if (walletAddress) {
        form.setValue('walletAddress', walletAddress);
        toast({
          title: "錢包已連接",
          description: "您的錢包已成功連接！",
        });
      }
    } catch (error) {
      console.error("連接錢包時出錯:", error);
      toast({
        variant: "destructive",
        title: "錢包連接失敗",
        description: error instanceof Error ? error.message : "無法連接錢包",
      });
    }
  };
  
  return (
    <div className="flex items-center justify-center min-h-[80vh]">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold">Create Your Account</CardTitle>
          <CardDescription>
            Join DappDate and find your perfect match on Web3
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="username"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Username</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Choose a username" 
                        {...field} 
                        disabled={registerMutation.isPending}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email</FormLabel>
                    <FormControl>
                      <Input 
                        type="email" 
                        placeholder="Enter your email" 
                        {...field} 
                        disabled={registerMutation.isPending}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Password</FormLabel>
                    <FormControl>
                      <Input 
                        type="password" 
                        placeholder="Create a password" 
                        {...field} 
                        disabled={registerMutation.isPending}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="space-y-2">
                <Label>Wallet Address</Label>
                <div className="flex gap-2">
                  <Input 
                    value={account || form.watch('walletAddress')}
                    disabled
                    placeholder="Connect your wallet"
                    className="flex-1"
                  />
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={handleConnectWallet}
                    disabled={!!account || isConnecting}
                  >
                    {isConnecting ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Wallet className="h-4 w-4" />
                    )}
                  </Button>
                </div>
                <p className="text-xs text-gray-500">
                  Your wallet address is required for Web3 features
                </p>
              </div>
              
              <Button 
                type="submit" 
                className="w-full"
                disabled={registerMutation.isPending || isConnecting}
              >
                {registerMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Creating account...
                  </>
                ) : (
                  <>
                    <UserPlus className="mr-2 h-4 w-4" />
                    Create Account
                  </>
                )}
              </Button>
              
              <p className="text-xs text-gray-500 text-center">
                By creating an account, you agree to our Terms of Service and Privacy Policy.
              </p>
            </form>
          </Form>
        </CardContent>
        <CardFooter className="flex flex-col">
          <div className="w-full flex items-center justify-center gap-2 mb-4">
            <Separator className="flex-1" />
            <span className="text-xs text-gray-500">Already have an account?</span>
            <Separator className="flex-1" />
          </div>
          
          <Button 
            variant="outline" 
            className="w-full"
            onClick={() => navigate("/login")}
          >
            <LogIn className="mr-2 h-4 w-4" />
            Login
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}