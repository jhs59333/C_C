import { useState } from "react";
import MemberList from "@/components/members/MemberList";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/Web3Context";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";

const Dashboard = () => {
  const { account, connectWallet } = useAuth();
  const { toast } = useToast();

  const handleConnect = () => {
    if (!account) {
      connectWallet().catch(error => {
        toast({
          title: "Wallet Connection Failed",
          description: error.message || "Please check your MetaMask wallet settings",
          variant: "destructive"
        });
      });
    }
  };

  const features = [
    {
      title: "Secure Encrypted Dating Platform",
      description: "All profiles and communications are secured with blockchain technology, ensuring your privacy and security",
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-pink-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
        </svg>
      )
    },
    {
      title: "Reputation-Based Matching",
      description: "Our unique reputation system ensures high-quality interactions and authentic user profiles",
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-pink-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />
        </svg>
      )
    },
    {
      title: "Anonymous Blockchain Interaction",
      description: "Use your crypto wallet to date anonymously without exposing your real identity",
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-pink-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
        </svg>
      )
    }
  ];
  
  const workflow = [
    {
      step: 1,
      title: "Connect Your Wallet",
      description: "Start by connecting your Web3 wallet to access all features securely",
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-pink-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z" />
        </svg>
      )
    },
    {
      step: 2,
      title: "Complete Your Profile",
      description: "Fill in your profile details to help others discover you",
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-pink-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
        </svg>
      )
    },
    {
      step: 3,
      title: "Discover Matches",
      description: "Browse through potential matches based on your preferences",
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-pink-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
        </svg>
      )
    },
    {
      step: 4,
      title: "Connect and Chat",
      description: "Start conversations with your matches and build connections",
      icon: (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-pink-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
        </svg>
      )
    }
  ];

  return (
    <>
      {/* Hero Section */}
      <div className="mb-10 mt-4 text-center">
        <h1 className="text-4xl md:text-5xl font-bold tracking-tight bg-gradient-to-r from-pink-600 to-purple-600 text-transparent bg-clip-text mb-4">
          C_C
        </h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto mb-8">
          The first decentralized dating platform combining blockchain technology with social matching. Secure, transparent, and innovative.
        </p>
        {!account ? (
          <Button 
            onClick={handleConnect}
            className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white font-medium py-2 px-6 rounded-lg"
            size="lg"
          >
            Connect Wallet to Start Dating
          </Button>
        ) : (
          <Link href="/discover">
            <Button
              className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white font-medium py-2 px-6 rounded-lg"
              size="lg"
            >
              Find Matches Now
            </Button>
          </Link>
        )}
      </div>

      {/* Getting Started Workflow */}
      <div className="mb-10">
        <h2 className="text-2xl font-bold text-center mb-8">Getting Started</h2>
        <div className="grid md:grid-cols-4 gap-4">
          {workflow.map((item) => (
            <Card key={item.step} className="border-gray-200 hover:shadow-md transition-shadow relative overflow-hidden">
              <div className="absolute top-0 left-0 bg-pink-500 text-white w-8 h-8 flex items-center justify-center rounded-br-lg font-bold">
                {item.step}
              </div>
              <CardHeader className="pt-10">
                <div className="mb-2">{item.icon}</div>
                <CardTitle className="text-lg">{item.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>{item.description}</CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
      
      {/* Features Section */}
      <div className="mb-10">
        <h2 className="text-2xl font-bold text-center mb-8">Unique Features</h2>
        <div className="grid md:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <Card key={index} className="border-gray-200 hover:shadow-md transition-shadow">
              <CardHeader>
                <div className="mb-4">{feature.icon}</div>
                <CardTitle>{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>{feature.description}</CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
      
      {/* Recent Members Section */}
      <div className="mb-10">
        <h2 className="text-2xl font-bold text-center mb-8">Recent Members</h2>
        <MemberList limit={3} />
      </div>
      
      {/* Call to Action */}
      <div className="bg-gradient-to-r from-pink-50 to-purple-50 p-8 rounded-2xl text-center mb-10">
        <h3 className="text-2xl font-bold mb-4">Ready to start your blockchain dating journey?</h3>
        <p className="mb-6 text-gray-600">Join us and experience secure, innovative dating.</p>
        {!account ? (
          <Button 
            onClick={handleConnect}
            className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white"
            size="lg"
          >
            Connect Wallet Now
          </Button>
        ) : (
          <Link href="/profile">
            <Button
              className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white"
              size="lg"
            >
              Complete Your Profile
            </Button>
          </Link>
        )}
      </div>
    </>
  );
};

export default Dashboard;
