import React, { useState, useEffect, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { useAuth } from "@/contexts/Web3Context";
import { apiRequest } from "@/lib/queryClient";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Send, 
  User2, 
  MessageSquare,
  ChevronLeft,
  Loader2,
  Calendar,
  Clock,
  Phone
} from "lucide-react";
import { format } from "date-fns";
import CallButton from "@/components/call/CallButton";

export default function Messages() {
  const { isConnected } = useAuth();
  const { toast } = useToast();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Mock user ID for demo - in a real app, this would be from authentication
  const userId = 1;
  
  // State to track selected match for conversation
  const [selectedMatchId, setSelectedMatchId] = useState<number | null>(null);
  const [messageInput, setMessageInput] = useState("");
  const [isMobileView, setIsMobileView] = useState(false);
  const [showConversation, setShowConversation] = useState(false);
  
  // Update mobile view state based on window size
  useEffect(() => {
    const handleResize = () => {
      setIsMobileView(window.innerWidth < 768);
    };
    
    handleResize();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);
  
  // Handle mobile view navigation
  useEffect(() => {
    if (selectedMatchId && isMobileView) {
      setShowConversation(true);
    } else {
      setShowConversation(false);
    }
  }, [selectedMatchId, isMobileView]);
  
  // Fetch user's matches
  const { 
    data: matches = [], 
    isLoading: matchesLoading 
  } = useQuery<any[]>({
    queryKey: ['/api/matches/user', userId],
    enabled: !!userId && isConnected,
  });
  
  // Fetch messages for selected match
  const { 
    data: messages = [], 
    isLoading: messagesLoading,
    refetch: refetchMessages
  } = useQuery<any[]>({
    queryKey: ['/api/messages/match', selectedMatchId],
    enabled: !!selectedMatchId,
  });
  
  // Create message mutation
  const sendMessage = useMutation({
    mutationFn: async (content: string) => {
      if (!selectedMatchId) throw new Error("No conversation selected");
      
      return apiRequest('/api/messages', 'POST', {
        matchId: selectedMatchId,
        senderId: userId,
        content,
        isRead: false
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/messages/match', selectedMatchId] });
      setMessageInput("");
      
      // Scroll to bottom after message is sent and list is updated
      setTimeout(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
      }, 100);
    },
    onError: (err) => {
      console.error("Error sending message:", err);
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    }
  });
  
  // Auto-scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);
  
  // Handle sending a message
  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageInput.trim()) return;
    
    sendMessage.mutate(messageInput);
  };
  
  // Handle selecting a conversation
  const handleSelectMatch = (matchId: number) => {
    setSelectedMatchId(matchId);
  };
  
  // Go back to match list on mobile
  const handleBackToMatches = () => {
    setShowConversation(false);
  };
  
  // Show connect wallet message if not connected
  if (!isConnected) {
    return (
      <div className="flex flex-col items-center justify-center h-[60vh] max-w-md mx-auto text-center">
        <div className="bg-primary/10 p-6 rounded-full mb-4">
          <MessageSquare className="h-10 w-10 text-primary" />
        </div>
        <h2 className="text-2xl font-bold mb-2">Connect to Message</h2>
        <p className="text-gray-500 mb-4">
          Connect your wallet to view your messages and chat with your matches.
        </p>
        <Button className="w-full">Connect Wallet</Button>
      </div>
    );
  }
  
  // Format time for messages
  const formatMessageTime = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const isToday = date.toDateString() === now.toDateString();
    
    if (isToday) {
      return format(date, "h:mm a"); // e.g. "3:30 PM"
    } else {
      return format(date, "MMM d"); // e.g. "Apr 15"
    }
  };
  
  // Group messages by date
  const groupMessagesByDate = (messageList: any[] = []) => {
    const groups: {[key: string]: any[]} = {};
    
    messageList.forEach(msg => {
      const date = new Date(msg.createdAt);
      const dateStr = format(date, "MMM d, yyyy");
      
      if (!groups[dateStr]) {
        groups[dateStr] = [];
      }
      
      groups[dateStr].push(msg);
    });
    
    return Object.entries(groups).map(([date, messages]) => ({
      date,
      messages
    }));
  };
  
  // Get selected match details
  const selectedMatch = matches?.find(match => match.id === selectedMatchId);
  const otherUser = selectedMatch?.otherUser;
  
  // Messages grouped by date
  const messageGroups = groupMessagesByDate(messages);
  
  return (
    <div className="h-[calc(100vh-180px)] flex flex-col">
      <h1 className="text-3xl font-bold mb-6">Messages</h1>
      
      <div className="flex flex-1 gap-6 overflow-hidden">
        {/* Matches List - Hidden on mobile when conversation is shown */}
        <div className={`w-full md:w-1/3 flex-shrink-0 overflow-hidden ${isMobileView && showConversation ? 'hidden' : 'block'}`}>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-medium">Your Matches</h2>
            <Badge>{matches?.length || 0}</Badge>
          </div>
          
          {matchesLoading ? (
            <div className="space-y-3">
              {[1, 2, 3].map(i => (
                <div key={i} className="flex items-center gap-4 p-3">
                  <Skeleton className="h-12 w-12 rounded-full" />
                  <div className="space-y-2">
                    <Skeleton className="h-4 w-24" />
                    <Skeleton className="h-3 w-40" />
                  </div>
                </div>
              ))}
            </div>
          ) : matches?.length === 0 ? (
            <div className="text-center py-8 border rounded-lg bg-gray-50">
              <User2 className="mx-auto h-8 w-8 text-gray-400 mb-2" />
              <p className="text-gray-500">No matches yet</p>
              <p className="text-sm text-gray-400 mt-1">
                Start discovering new people
              </p>
            </div>
          ) : (
            <ScrollArea className="h-[calc(100vh-260px)]">
              <div className="space-y-1 pr-4">
                {matches?.map(match => (
                  <div
                    key={match.id}
                    className={`flex items-center gap-3 p-3 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors
                      ${selectedMatchId === match.id ? 'bg-primary/10 hover:bg-primary/10' : ''}`}
                    onClick={() => handleSelectMatch(match.id)}
                  >
                    <Avatar>
                      <AvatarImage src={match.otherUser?.profilePicture || ""} />
                      <AvatarFallback>
                        {match.otherUser?.displayName?.slice(0, 2).toUpperCase() || "??"}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-center">
                        <p className="font-medium truncate">
                          {match.otherUser?.displayName}
                        </p>
                        <span className="text-xs text-gray-500">
                          {match.lastInteraction ? format(new Date(match.lastInteraction), "MMM d") : "New"}
                        </span>
                      </div>
                      <p className="text-sm text-gray-500 truncate">
                        {match.status === "matched" ? "Tap to chat" : match.status === "pending" ? "Pending match" : "Rejected"}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          )}
        </div>
        
        {/* Conversation - Hidden on mobile unless a conversation is selected */}
        <div className={`flex-1 flex flex-col overflow-hidden ${isMobileView && !showConversation ? 'hidden' : 'block'}`}>
          {!selectedMatchId ? (
            <div className="flex flex-col items-center justify-center h-full text-center">
              <MessageSquare className="h-12 w-12 text-gray-300 mb-4" />
              <h2 className="text-xl font-medium text-gray-700">No Conversation Selected</h2>
              <p className="text-gray-500 max-w-xs mt-2">
                Select a match from the list to start messaging.
              </p>
            </div>
          ) : (
            <>
              {/* Conversation Header */}
              <div className="flex items-center gap-3 p-4 border-b">
                {isMobileView && (
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    onClick={handleBackToMatches} 
                    className="mr-1"
                  >
                    <ChevronLeft className="h-5 w-5" />
                  </Button>
                )}
                
                <Avatar>
                  <AvatarImage src={otherUser?.profilePicture || ""} />
                  <AvatarFallback>
                    {otherUser?.displayName?.slice(0, 2).toUpperCase() || "??"}
                  </AvatarFallback>
                </Avatar>
                
                <div className="flex-1">
                  <h3 className="font-medium">{otherUser?.displayName}</h3>
                  <div className="flex items-center text-xs text-gray-500">
                    <span className={`w-2 h-2 rounded-full mr-1 ${
                      // This would use real online status in a production app
                      Math.random() > 0.5 ? 'bg-green-500' : 'bg-gray-300'
                    }`}></span>
                    {Math.random() > 0.5 ? 'Online' : 'Offline'}
                  </div>
                </div>
                
                {/* Call Button */}
                {selectedMatch && otherUser && (
                  <CallButton 
                    matchId={selectedMatch.id}
                    recipientId={otherUser.id}
                    recipientName={otherUser.displayName}
                  />
                )}
              </div>
              
              {/* Messages */}
              <ScrollArea className="flex-1 p-4">
                {messagesLoading ? (
                  <div className="space-y-4">
                    {[1, 2, 3].map(i => (
                      <div key={i} className={`flex ${i % 2 === 0 ? 'justify-end' : 'justify-start'}`}>
                        <Skeleton className={`h-12 w-40 rounded-xl ${i % 2 === 0 ? 'rounded-tr-sm' : 'rounded-tl-sm'}`} />
                      </div>
                    ))}
                  </div>
                ) : messages?.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-full text-center">
                    <div className="bg-primary/10 p-4 rounded-full mb-3">
                      <MessageSquare className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="font-medium">No messages yet</h3>
                    <p className="text-sm text-gray-500 mt-1 max-w-xs">
                      Send your first message to start the conversation.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-6">
                    {messageGroups.map((group, groupIndex) => (
                      <div key={groupIndex} className="space-y-4">
                        <div className="flex justify-center">
                          <Badge variant="outline" className="bg-gray-50 text-gray-500 font-normal">
                            <Calendar className="h-3 w-3 mr-1" />
                            {group.date}
                          </Badge>
                        </div>
                        
                        {group.messages.map((message: any) => {
                          const isSentByMe = message.senderId === userId;
                          
                          return (
                            <div 
                              key={message.id}
                              className={`flex ${isSentByMe ? 'justify-end' : 'justify-start'}`}
                            >
                              <div className="flex flex-col max-w-[80%]">
                                <div 
                                  className={`
                                    px-4 py-2 rounded-xl 
                                    ${isSentByMe 
                                      ? 'bg-primary text-white rounded-tr-sm' 
                                      : 'bg-gray-100 text-gray-800 rounded-tl-sm'
                                    }
                                  `}
                                >
                                  {message.content}
                                </div>
                                <div 
                                  className={`
                                    flex items-center mt-1 text-xs text-gray-500
                                    ${isSentByMe ? 'justify-end' : 'justify-start'}
                                  `}
                                >
                                  <Clock className="h-3 w-3 mr-1" />
                                  {formatMessageTime(message.createdAt)}
                                  {isSentByMe && message.isRead && (
                                    <span className="ml-1 text-blue-500">•&nbsp;Read</span>
                                  )}
                                </div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    ))}
                    <div ref={messagesEndRef} />
                  </div>
                )}
              </ScrollArea>
              
              {/* Message Input */}
              <form onSubmit={handleSendMessage} className="p-4 border-t">
                <div className="flex gap-2">
                  <Input
                    value={messageInput}
                    onChange={(e) => setMessageInput(e.target.value)}
                    placeholder="Type a message..."
                    disabled={sendMessage.isPending}
                    className="flex-1"
                  />
                  <Button 
                    type="submit" 
                    disabled={!messageInput.trim() || sendMessage.isPending}
                  >
                    {sendMessage.isPending ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Send className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  );
}