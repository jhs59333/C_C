import { useState } from "react";
import { useAuth } from "@/contexts/Web3Context";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";

const Settings = () => {
  const { account, shortAddress, disconnectWallet } = useAuth();
  const { toast } = useToast();
  const [displayName, setDisplayName] = useState("");
  const [email, setEmail] = useState("");
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [proposalNotifications, setProposalNotifications] = useState(true);
  const [voteNotifications, setVoteNotifications] = useState(true);
  
  const handleSaveProfile = () => {
    toast({
      title: "Profile Updated",
      description: "Your profile information has been updated.",
      variant: "default"
    });
  };
  
  const copyAddressToClipboard = () => {
    if (account) {
      navigator.clipboard.writeText(account);
      toast({
        title: "Address Copied",
        description: "Your Ethereum address has been copied to clipboard.",
        variant: "default"
      });
    }
  };
  
  return (
    <>
      {/* Settings Header */}
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-800">Settings</h2>
        <p className="text-gray-600">Manage your account and preferences</p>
      </div>
      
      <Tabs defaultValue="profile" className="w-full">
        <TabsList className="grid grid-cols-3 mb-6 w-full max-w-md">
          <TabsTrigger value="profile">Profile</TabsTrigger>
          <TabsTrigger value="wallet">Wallet</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
        </TabsList>
        
        <TabsContent value="profile">
          <Card>
            <CardHeader>
              <CardTitle>Profile Information</CardTitle>
              <CardDescription>
                Update your profile information visible to other DAO members.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="display-name">Display Name</Label>
                <Input 
                  id="display-name" 
                  placeholder="Enter a display name" 
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                />
                <p className="text-xs text-gray-500">
                  This name will be displayed instead of your wallet address.
                </p>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="email">Email Address</Label>
                <Input 
                  id="email" 
                  type="email" 
                  placeholder="your@email.com" 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
                <p className="text-xs text-gray-500">
                  Your email will not be displayed publicly.
                </p>
              </div>
              
              <Button onClick={handleSaveProfile}>Save Changes</Button>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="wallet">
          <Card>
            <CardHeader>
              <CardTitle>Wallet Settings</CardTitle>
              <CardDescription>
                Manage your connected wallet and transactions.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-700">Connected Wallet</p>
                    <p className="mt-1 text-sm text-gray-500">Your Ethereum wallet is connected</p>
                  </div>
                  <div className="bg-green-100 px-3 py-1 rounded-full text-green-800 text-xs font-medium flex items-center">
                    <span className="h-2 w-2 bg-green-500 rounded-full mr-2"></span>
                    Connected
                  </div>
                </div>
                
                <div className="mt-4 p-3 bg-white rounded border border-gray-200">
                  <p className="text-xs text-gray-500">Your Address</p>
                  <div className="flex items-center mt-1">
                    <code className="text-sm font-mono bg-gray-100 px-2 py-1 rounded flex-1 overflow-hidden text-ellipsis">
                      {account || 'Not connected'}
                    </code>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={copyAddressToClipboard}
                      disabled={!account}
                      className="ml-2"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <rect x="9" y="9" width="13" height="13" rx="2" ry="2"/>
                        <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
                      </svg>
                    </Button>
                  </div>
                </div>
                
                <div className="mt-4">
                  <Button variant="outline" className="w-full" onClick={disconnectWallet}>
                    Disconnect Wallet
                  </Button>
                </div>
              </div>
              
              <div>
                <h4 className="text-sm font-medium mb-2">Gas Price Settings</h4>
                <div className="grid grid-cols-3 gap-2">
                  <Button variant="outline" className="text-sm">
                    Low
                    <span className="block text-xs text-gray-500">Slower</span>
                  </Button>
                  <Button variant="default" className="text-sm">
                    Medium
                    <span className="block text-xs">Average</span>
                  </Button>
                  <Button variant="outline" className="text-sm">
                    High
                    <span className="block text-xs text-gray-500">Faster</span>
                  </Button>
                </div>
                <p className="text-xs text-gray-500 mt-2">
                  Sets the gas price for all your transactions.
                </p>
              </div>
              
              <Separator />
              
              <div>
                <h4 className="text-sm font-medium mb-2">Transaction History</h4>
                <Button variant="outline" size="sm" className="w-full">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
                    <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/>
                    <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>
                  </svg>
                  View on Etherscan
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="notifications">
          <Card>
            <CardHeader>
              <CardTitle>Notification Settings</CardTitle>
              <CardDescription>
                Configure how you want to be notified about DAO activities.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="email-notifications" className="text-base">Email Notifications</Label>
                    <p className="text-sm text-gray-500">Receive updates via email</p>
                  </div>
                  <Switch 
                    id="email-notifications" 
                    checked={emailNotifications}
                    onCheckedChange={setEmailNotifications}
                  />
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="proposal-notifications" className="text-base">New Proposals</Label>
                    <p className="text-sm text-gray-500">Get notified about new DAO proposals</p>
                  </div>
                  <Switch 
                    id="proposal-notifications" 
                    checked={proposalNotifications}
                    onCheckedChange={setProposalNotifications}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="vote-notifications" className="text-base">Voting Results</Label>
                    <p className="text-sm text-gray-500">Get notified when proposals you voted on are executed or rejected</p>
                  </div>
                  <Switch 
                    id="vote-notifications" 
                    checked={voteNotifications}
                    onCheckedChange={setVoteNotifications}
                  />
                </div>
                
                <Button onClick={() => {
                  toast({
                    title: "Notification Settings Saved",
                    description: "Your notification preferences have been updated.",
                    variant: "default"
                  });
                }}>
                  Save Notification Settings
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </>
  );
};

export default Settings;
