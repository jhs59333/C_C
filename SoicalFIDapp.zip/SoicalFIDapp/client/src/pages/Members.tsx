import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import MemberList from "@/components/members/MemberList";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Member } from "@shared/schema";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

const Members = () => {
  const { data: members, isLoading } = useQuery<Member[]>({
    queryKey: ['/api/members'],
  });

  // Generate data for the token distribution chart
  const generateTokenDistributionData = () => {
    if (!members || members.length === 0) return [];
    
    // Group members by token balance ranges
    const ranges = [
      { range: '0-1K', min: 0, max: 1000, count: 0 },
      { range: '1K-5K', min: 1000, max: 5000, count: 0 },
      { range: '5K-10K', min: 5000, max: 10000, count: 0 },
      { range: '10K-25K', min: 10000, max: 25000, count: 0 },
      { range: '25K-50K', min: 25000, max: 50000, count: 0 },
      { range: '50K+', min: 50000, max: Infinity, count: 0 },
    ];
    
    members.forEach(member => {
      const range = ranges.find(r => member.tokenBalance >= r.min && member.tokenBalance < r.max);
      if (range) {
        range.count++;
      }
    });
    
    return ranges;
  };

  // Calculate member growth over time (mock data in a real app this would come from the blockchain)
  const memberGrowthData = [
    { month: 'Jan', members: 12 },
    { month: 'Feb', members: 19 },
    { month: 'Mar', members: 22 },
    { month: 'Apr', members: 28 },
    { month: 'May', members: 35 },
    { month: 'Jun', members: 42 },
    { month: 'Jul', members: 49 },
  ];

  return (
    <>
      {/* Members Header */}
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-800">Members</h2>
        <p className="text-gray-600">View all DAO members and their token holdings</p>
      </div>

      {/* Member Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <Card className="bg-white">
          <CardContent className="p-6">
            <div className="flex flex-col">
              <p className="text-sm text-gray-500">Total Members</p>
              <div className="mt-2 flex items-baseline">
                <span className="text-3xl font-bold">{members?.length || 0}</span>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-white">
          <CardContent className="p-6">
            <div className="flex flex-col">
              <p className="text-sm text-gray-500">Total DAO Tokens</p>
              <div className="mt-2 flex items-baseline">
                <span className="text-3xl font-bold">
                  {members ? members.reduce((sum, member) => sum + member.tokenBalance, 0).toLocaleString() : 0}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-white">
          <CardContent className="p-6">
            <div className="flex flex-col">
              <p className="text-sm text-gray-500">New Members (30d)</p>
              <div className="mt-2 flex items-baseline">
                <span className="text-3xl font-bold">14</span>
                <span className="ml-2 text-sm text-green-600 flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="m18 15-6-6-6 6" />
                  </svg>
                  40%
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* Token Distribution */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-semibold">Token Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={generateTokenDistributionData()}>
                  <XAxis dataKey="range" />
                  <YAxis />
                  <Tooltip formatter={(value) => [`${value} members`, 'Count']} />
                  <Bar dataKey="count" fill="#3B82F6" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Member Growth */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-semibold">Member Growth</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={memberGrowthData}>
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip formatter={(value) => [`${value} members`, 'Total']} />
                  <Bar dataKey="members" fill="#10B981" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Member List */}
      <MemberList showViewAll={false} title="All Members" />
    </>
  );
};

export default Members;
