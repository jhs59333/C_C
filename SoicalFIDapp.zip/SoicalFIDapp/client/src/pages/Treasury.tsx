import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import TreasuryOverview from "@/components/treasury/TreasuryOverview";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp, TrendingDown, DollarSign, ArrowRight } from "lucide-react";
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from "recharts";

interface TreasuryData {
  tokenBalance: number;
  ethBalance: string;
  usdValue: string;
}

const Treasury = () => {
  const { data: treasury } = useQuery<TreasuryData>({
    queryKey: ['/api/treasury'],
  });

  // Mock transaction data (in a real app, this would come from the blockchain)
  const recentTransactions = [
    { id: 1, type: 'deposit', amount: '5.0 ETH', from: '0x71C...83a4', to: 'DAO Treasury', date: '2 days ago' },
    { id: 2, type: 'withdraw', amount: '10,000 DAO', from: 'DAO Treasury', to: 'Marketing', date: '5 days ago' },
    { id: 3, type: 'deposit', amount: '20,000 DAO', from: '0x32A...f77C', to: 'DAO Treasury', date: '1 week ago' },
  ];

  // Asset allocation data for the pie chart
  const assetAllocation = [
    { name: 'ETH', value: treasury ? parseFloat(treasury.ethBalance) * 2000 : 0 }, // Assuming ETH price of $2000
    { name: 'DAO Token', value: treasury ? (treasury.tokenBalance * 0.5) : 0 }, // Assuming DAO token price of $0.50
    { name: 'Stablecoins', value: 50000 }, // Mock value
    { name: 'Other Assets', value: 75000 }, // Mock value
  ];

  // Colors for the pie chart
  const COLORS = ['#3B82F6', '#10B981', '#8B5CF6', '#F59E0B'];

  return (
    <>
      {/* Treasury Header */}
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-800">Treasury</h2>
        <p className="text-gray-600">View and manage the DAO's assets</p>
      </div>

      {/* Treasury Overview */}
      <div className="mb-6">
        <TreasuryOverview />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* Asset Allocation */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-semibold">Asset Allocation</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={assetAllocation}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {assetAllocation.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip 
                    formatter={(value) => [`$${value.toLocaleString()}`, 'Value']}
                  />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Recent Transactions */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg font-semibold">Recent Transactions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentTransactions.map((tx) => (
                <div key={tx.id} className="bg-gray-50 p-4 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center">
                      {tx.type === 'deposit' ? (
                        <div className="bg-green-100 p-2 rounded-full mr-3">
                          <TrendingUp className="h-5 w-5 text-green-600" />
                        </div>
                      ) : (
                        <div className="bg-red-100 p-2 rounded-full mr-3">
                          <TrendingDown className="h-5 w-5 text-red-600" />
                        </div>
                      )}
                      <div>
                        <p className="font-medium">{tx.type === 'deposit' ? 'Deposit' : 'Withdrawal'}</p>
                        <p className="text-sm text-gray-500">{tx.date}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className={`font-medium ${tx.type === 'deposit' ? 'text-green-600' : 'text-red-600'}`}>
                        {tx.type === 'deposit' ? '+' : '-'} {tx.amount}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center text-sm text-gray-600">
                    <span className="font-mono">{tx.from}</span>
                    <ArrowRight className="h-3 w-3 mx-2" />
                    <span className="font-mono">{tx.to}</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Treasury Metrics */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-semibold">Treasury Metrics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-blue-50 rounded-lg p-4">
              <div className="flex items-center mb-2">
                <div className="bg-blue-100 p-2 rounded-full mr-3">
                  <DollarSign className="h-5 w-5 text-blue-600" />
                </div>
                <p className="text-gray-700 font-medium">Cash Runway</p>
              </div>
              <p className="text-2xl font-bold">24 months</p>
              <p className="text-sm text-gray-500 mt-1">Based on current spending</p>
            </div>
            
            <div className="bg-green-50 rounded-lg p-4">
              <div className="flex items-center mb-2">
                <div className="bg-green-100 p-2 rounded-full mr-3">
                  <TrendingUp className="h-5 w-5 text-green-600" />
                </div>
                <p className="text-gray-700 font-medium">Monthly Yield</p>
              </div>
              <p className="text-2xl font-bold">$12,450</p>
              <p className="text-sm text-gray-500 mt-1">From staking and DeFi</p>
            </div>
            
            <div className="bg-purple-50 rounded-lg p-4">
              <div className="flex items-center mb-2">
                <div className="bg-purple-100 p-2 rounded-full mr-3">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                  </svg>
                </div>
                <p className="text-gray-700 font-medium">Growth (YTD)</p>
              </div>
              <p className="text-2xl font-bold">+32.5%</p>
              <p className="text-sm text-gray-500 mt-1">Compared to $940,000 in Jan</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </>
  );
};

export default Treasury;
