import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { useAuth } from "@/contexts/Web3Context";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Heart, 
  X, 
  StarIcon, 
  MapPin, 
  Shield, 
  Loader2,
  RefreshCcw,
  Users
} from "lucide-react";

export default function Discover() {
  const { isConnected } = useAuth();
  const { toast } = useToast();
  
  // Mock user ID for demo - in a real app, this would be from authentication
  const userId = 1;
  
  // Use state to track current potential match index
  const [currentIndex, setCurrentIndex] = useState(0);
  
  // 當前選中的標籤
  const [activeTab, setActiveTab] = useState<string>("for-you");
  
  // Fetch potential matches (matches based on user preferences)
  const { 
    data: potentialMatches, 
    isLoading: isPotentialLoading, 
    isError: isPotentialError, 
    error: potentialError 
  } = useQuery({
    queryKey: ['/api/matches/potential', userId],
    enabled: !!userId && isConnected,
  });
  
  // Fetch discover profiles (more general exploration)
  const { 
    data: discoverProfiles, 
    isLoading: isDiscoverLoading, 
    isError: isDiscoverError, 
    error: discoverError 
  } = useQuery({
    queryKey: ['/api/matches/discover', userId],
    enabled: !!userId && isConnected,
  });
  
  // Get the current active data based on the selected tab
  const currentData = activeTab === "for-you" ? potentialMatches : discoverProfiles;
  const isLoading = activeTab === "for-you" ? isPotentialLoading : isDiscoverLoading;
  const isError = activeTab === "for-you" ? isPotentialError : isDiscoverError;
  const error = activeTab === "for-you" ? potentialError : discoverError;
  
  // Create match mutation
  const createMatch = useMutation({
    mutationFn: async (otherUserId: number) => {
      return apiRequest('/api/matches', 'POST', {
        user1Id: userId,
        user2Id: otherUserId
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/matches/user', userId] });
      toast({
        title: "已喜歡！",
        description: "你已喜歡此用戶資料。如果對方也喜歡你，將會成為配對！",
      });
      // Move to next profile
      setCurrentIndex(prev => prev + 1);
    },
    onError: (err) => {
      console.error("Error creating match:", err);
      toast({
        title: "錯誤",
        description: "無法喜歡此資料。請稍後再試。",
        variant: "destructive",
      });
    }
  });
  
  // Handle like action
  const handleLike = (profileId: number) => {
    if (!isConnected) {
      toast({
        title: "未連接錢包",
        description: "請連接您的錢包以喜歡資料。",
        variant: "destructive",
      });
      return;
    }
    
    createMatch.mutate(profileId);
  };
  
  // Handle skip action
  const handleSkip = () => {
    setCurrentIndex(prev => prev + 1);
  };
  
  // Handle tab change
  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
    setCurrentIndex(0); // Reset index when changing tabs
  };
  
  // Get current profile to display
  const currentProfile = currentData && currentData[currentIndex]?.profile;
  const matchQuality = currentData && currentData[currentIndex]?.matchQuality;
  
  // If no more profiles
  const noMoreProfiles = currentData && currentIndex >= currentData.length;
  
  if (!isConnected) {
    return (
      <div className="max-w-md mx-auto">
        <h1 className="text-3xl font-bold mb-4">探索</h1>
      
        <Tabs 
          defaultValue="for-you" 
          value={activeTab} 
          onValueChange={handleTabChange}
          className="mb-6"
        >
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="for-you" className="flex items-center gap-2">
              <Heart className="h-4 w-4" />
              <span>為你推薦</span>
            </TabsTrigger>
            <TabsTrigger value="discover" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              <span>探索更多</span>
            </TabsTrigger>
          </TabsList>
        </Tabs>
        
        <div className="flex flex-col items-center justify-center py-16 text-center">
          <div className="bg-primary/10 p-6 rounded-full mb-4">
            <Heart className="h-10 w-10 text-primary" />
          </div>
          <h2 className="text-2xl font-bold mb-2">連接錢包開始</h2>
          <p className="text-gray-500 mb-4">
            連接您的錢包以開始探索潛在配對並開始您的 Web3 社交之旅。
          </p>
          <Button className="w-full">連接錢包</Button>
        </div>
      </div>
    );
  }
  
  if (isLoading) {
    return (
      <div className="max-w-md mx-auto">
        <h1 className="text-3xl font-bold mb-4">探索</h1>
        
        <Tabs 
          defaultValue="for-you" 
          value={activeTab} 
          onValueChange={handleTabChange}
          className="mb-6"
        >
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="for-you" className="flex items-center gap-2">
              <Heart className="h-4 w-4" />
              <span>為你推薦</span>
            </TabsTrigger>
            <TabsTrigger value="discover" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              <span>探索更多</span>
            </TabsTrigger>
          </TabsList>
        </Tabs>
        
        <Card className="overflow-hidden">
          <CardContent className="p-0">
            <Skeleton className="aspect-[3/4] w-full" />
            <div className="p-4 space-y-4">
              <Skeleton className="h-8 w-3/4" />
              <Skeleton className="h-4 w-1/2" />
              <div className="flex gap-2">
                <Skeleton className="h-6 w-16 rounded-full" />
                <Skeleton className="h-6 w-16 rounded-full" />
                <Skeleton className="h-6 w-16 rounded-full" />
              </div>
              <div className="flex justify-between mt-6">
                <Skeleton className="h-12 w-12 rounded-full" />
                <Skeleton className="h-12 w-12 rounded-full" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  if (isError) {
    return (
      <div className="max-w-md mx-auto">
        <h1 className="text-3xl font-bold mb-4">探索</h1>
        
        <Tabs 
          defaultValue="for-you" 
          value={activeTab} 
          onValueChange={handleTabChange}
          className="mb-6"
        >
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="for-you" className="flex items-center gap-2">
              <Heart className="h-4 w-4" />
              <span>為你推薦</span>
            </TabsTrigger>
            <TabsTrigger value="discover" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              <span>探索更多</span>
            </TabsTrigger>
          </TabsList>
        </Tabs>
        
        <div className="text-center py-10">
          <div className="bg-red-50 p-6 rounded-lg mb-4">
            <X className="h-10 w-10 text-red-500 mx-auto" />
          </div>
          <h2 className="text-2xl font-bold mb-2">發生錯誤</h2>
          <p className="text-gray-500 mb-4">
            {error instanceof Error ? error.message : "無法載入配對資料。"}
          </p>
          <Button 
            onClick={() => {
              const queryKey = activeTab === "for-you" 
                ? ['/api/matches/potential', userId] 
                : ['/api/matches/discover', userId];
              queryClient.invalidateQueries({ queryKey });
            }}
            className="w-full"
          >
            重試
          </Button>
        </div>
      </div>
    );
  }
  
  if (noMoreProfiles) {
    return (
      <div className="max-w-md mx-auto">
        <h1 className="text-3xl font-bold mb-4">探索</h1>
        
        <Tabs 
          defaultValue="for-you" 
          value={activeTab} 
          onValueChange={handleTabChange}
          className="mb-6"
        >
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="for-you" className="flex items-center gap-2">
              <Heart className="h-4 w-4" />
              <span>為你推薦</span>
            </TabsTrigger>
            <TabsTrigger value="discover" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              <span>探索更多</span>
            </TabsTrigger>
          </TabsList>
        </Tabs>
        
        <div className="text-center py-10">
          <div className="bg-primary/10 p-6 rounded-full mb-4 mx-auto w-fit">
            <Heart className="h-10 w-10 text-primary" />
          </div>
          <h2 className="text-2xl font-bold mb-2">無更多資料</h2>
          <p className="text-gray-500 mb-6">
            {activeTab === "for-you" 
              ? "你已查看所有推薦的配對。稍後再來查看新的用戶。" 
              : "你已查看本類別下的所有用戶。請嘗試其他類別或稍後再來。"}
          </p>
          
          <div className="flex flex-col space-y-3">
            <Button onClick={() => setCurrentIndex(0)} variant="outline" className="w-full">
              <RefreshCcw className="mr-2 h-4 w-4" />
              重新開始
            </Button>
            
            {activeTab === "for-you" && (
              <Button 
                onClick={() => handleTabChange("discover")} 
                variant="default" 
                className="w-full bg-gradient-to-r from-pink-500 to-rose-500"
              >
                <Users className="mr-2 h-4 w-4" />
                探索更多用戶
              </Button>
            )}
            
            {activeTab === "discover" && (
              <Button 
                onClick={() => handleTabChange("for-you")} 
                variant="default" 
                className="w-full bg-gradient-to-r from-pink-500 to-rose-500"
              >
                <Heart className="mr-2 h-4 w-4" />
                查看推薦配對
              </Button>
            )}
          </div>
          
          <p className="text-sm text-gray-400 mt-4">
            完善你的個人資料以獲得更準確的配對。
          </p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="max-w-md mx-auto">
      <h1 className="text-3xl font-bold mb-4">探索</h1>
      
      <Tabs 
        defaultValue="for-you" 
        value={activeTab} 
        onValueChange={handleTabChange}
        className="mb-6"
      >
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="for-you" className="flex items-center gap-2">
            <Heart className="h-4 w-4" />
            <span>為你推薦</span>
          </TabsTrigger>
          <TabsTrigger value="discover" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            <span>探索更多</span>
          </TabsTrigger>
        </TabsList>
      </Tabs>
      
      <Card className="overflow-hidden">
        <CardContent className="p-0">
          {/* Profile Image */}
          <div className="relative">
            <div className="aspect-[3/4] bg-gray-100 flex items-center justify-center">
              {currentProfile?.profilePicture ? (
                <img 
                  src={currentProfile.profilePicture} 
                  alt={currentProfile.displayName}
                  className="w-full h-full object-cover"
                />
              ) : (
                <Avatar className="h-32 w-32">
                  <AvatarFallback>
                    {currentProfile?.displayName.slice(0, 2).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
              )}
            </div>
            
            {/* Match quality indicator */}
            <div className="absolute top-4 right-4 bg-black/60 text-white rounded-full px-3 py-1 text-sm flex items-center">
              <StarIcon className="h-4 w-4 mr-1 text-yellow-400" />
              <span>{Math.round(matchQuality * 100)}% Match</span>
            </div>
          </div>
          
          {/* Profile Info */}
          <div className="p-4 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold flex items-center gap-2">
                  {currentProfile?.displayName}
                  {currentProfile?.verificationStatus && (
                    <Shield className="h-5 w-5 text-blue-500" />
                  )}
                </h2>
                <div className="flex items-center text-gray-500 text-sm">
                  <span>{currentProfile?.age} years</span>
                  {currentProfile?.location && (
                    <>
                      <span className="mx-1">•</span>
                      <MapPin className="h-3 w-3 mr-1" />
                      <span>{currentProfile.location}</span>
                    </>
                  )}
                </div>
              </div>
              <div className="bg-primary/10 text-primary rounded-full h-10 w-10 flex items-center justify-center">
                <StarIcon className="h-5 w-5" />
                <span className="text-sm font-medium">{currentProfile?.reputationScore}</span>
              </div>
            </div>
            
            <p className="text-gray-700">
              {currentProfile?.bio || "No bio available."}
            </p>
            
            {/* Interests */}
            <div className="flex flex-wrap gap-2">
              {currentProfile?.interests && currentProfile.interests.map((interest, index) => (
                <Badge key={index} variant="outline" className="bg-gray-50">
                  {interest}
                </Badge>
              ))}
            </div>
            
            {/* Action Buttons */}
            <div className="flex justify-between pt-4">
              <Button 
                onClick={handleSkip}
                variant="outline" 
                size="lg" 
                className="rounded-full h-14 w-14 p-0"
              >
                <X className="h-6 w-6 text-gray-500" />
              </Button>
              
              <Button 
                onClick={() => handleLike(currentProfile?.userId)}
                variant="default" 
                size="lg" 
                className="rounded-full h-14 w-14 p-0 bg-gradient-to-r from-pink-500 to-rose-500"
                disabled={createMatch.isPending}
              >
                {createMatch.isPending ? (
                  <Loader2 className="h-6 w-6 animate-spin" />
                ) : (
                  <Heart className="h-6 w-6" />
                )}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}