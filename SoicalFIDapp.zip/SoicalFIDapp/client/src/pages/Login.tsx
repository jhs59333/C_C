import { useState } from "react";
import { useLocation } from "wouter";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { useAuth } from "@/contexts/Web3Context";
import { useToast } from "@/hooks/use-toast";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, LogIn, Wallet } from "lucide-react";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";

// Schema for email login
const emailLoginSchema = z.object({
  email: z
    .string()
    .email({ message: "Please enter a valid email address." }),
  password: z
    .string()
    .min(8, { message: "Password must be at least 8 characters." })
});

export default function Login() {
  const [_, navigate] = useLocation();
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [isWalletLoggingIn, setIsWalletLoggingIn] = useState(false);
  const { 
    connectWallet, 
    isConnecting, 
    account,
    loginWithEmail,
    loginWithWallet
  } = useAuth();
  const { toast } = useToast();
  
  // Form for email login
  const form = useForm<z.infer<typeof emailLoginSchema>>({
    resolver: zodResolver(emailLoginSchema),
    defaultValues: {
      email: "",
      password: ""
    },
  });
  
  // 處理電子郵件登錄表單提交 - 使用模擬登錄流程
  const onSubmit = async (values: z.infer<typeof emailLoginSchema>) => {
    try {
      setIsLoggingIn(true);
      
      // 模擬登錄延遲
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // 模擬成功響應
      toast({
        title: "登錄成功",
        description: "歡迎回來！",
      });
      
      // 設置標記以使用模擬認證
      sessionStorage.setItem('fromWalletLogin', 'true');
      
      // 重定向到儀表板
      setTimeout(() => {
        navigate("/dashboard");
      }, 500);
      
    } catch (error: any) {
      console.error("登錄錯誤:", error);
      toast({
        variant: "destructive",
        title: "登錄失敗",
        description: error.message || "無效的電子郵件或密碼",
      });
    } finally {
      setIsLoggingIn(false);
    }
  };
  
  // 處理錢包登錄 - 直接模擬登錄過程，不使用真實API
  const handleWalletLogin = async () => {
    try {
      setIsWalletLoggingIn(true);
      
      // 模擬連接過程
      await new Promise(resolve => setTimeout(resolve, 800));
      
      // 模擬登錄成功
      toast({
        title: "登錄成功",
        description: "使用加密錢包登錄成功！",
      });
      
      // 設置標記以使用模擬認證
      sessionStorage.setItem('fromWalletLogin', 'true');
      
      // 直接重定向到儀表板頁面
      setTimeout(() => {
        navigate("/dashboard");
      }, 800);
      
    } catch (error: any) {
      console.error("錢包登錄錯誤:", error);
      toast({
        variant: "destructive",
        title: "錢包連接失敗",
        description: error.message || "無法連接到錢包",
      });
    } finally {
      setIsWalletLoggingIn(false);
    }
  };
  
  return (
    <div className="flex items-center justify-center min-h-[80vh]">
      <Card className="w-full max-w-md shadow-lg">
        <CardHeader className="text-center">
          <CardTitle className="text-3xl font-bold bg-gradient-to-r from-primary to-blue-600 bg-clip-text text-transparent">
            Welcome to C_C
          </CardTitle>
          <CardDescription className="text-gray-600">
            The decentralized dating app that puts you in control
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="email" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-6">
              <TabsTrigger value="email">
                <LogIn className="h-4 w-4 mr-2" />
                Email
              </TabsTrigger>
              <TabsTrigger value="wallet">
                <Wallet className="h-4 w-4 mr-2" />
                Wallet
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="email">
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Enter your email" 
                            type="email"
                            {...field} 
                            disabled={isLoggingIn}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Password</FormLabel>
                        <FormControl>
                          <Input 
                            type="password" 
                            placeholder="Enter your password" 
                            {...field} 
                            disabled={isLoggingIn}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <Button 
                    type="submit" 
                    className="w-full bg-gradient-to-r from-primary to-blue-600 hover:from-primary/90 hover:to-blue-700"
                    disabled={isLoggingIn}
                  >
                    {isLoggingIn ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Logging in...
                      </>
                    ) : (
                      <>
                        <LogIn className="mr-2 h-4 w-4" />
                        Login
                      </>
                    )}
                  </Button>
                </form>
              </Form>
            </TabsContent>
            
            <TabsContent value="wallet">
              <div className="space-y-4 text-center">
                <div className="bg-gray-50 p-6 rounded-lg">
                  <Wallet className="h-12 w-12 text-primary mx-auto mb-3" />
                  <h3 className="text-lg font-medium">Web3 Wallet Login</h3>
                  <p className="text-sm text-gray-500 mt-1">
                    Connect your Ethereum wallet for passwordless authentication
                  </p>
                </div>
                
                <Button 
                  onClick={handleWalletLogin} 
                  className="w-full bg-gradient-to-r from-primary to-blue-600 hover:from-primary/90 hover:to-blue-700"
                  disabled={isConnecting || isWalletLoggingIn}
                >
                  {isConnecting || isWalletLoggingIn ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      {isConnecting ? "Connecting Wallet..." : "Signing In..."}
                    </>
                  ) : (
                    <>
                      <Wallet className="mr-2 h-4 w-4" />
                      Connect Wallet
                    </>
                  )}
                </Button>
                
                <p className="text-xs text-gray-500">
                  By connecting your wallet, you agree to our Terms of Service and Privacy Policy.
                </p>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
        <CardFooter className="flex flex-col">
          <div className="w-full flex items-center justify-center gap-2 mb-4">
            <Separator className="flex-1" />
            <span className="text-xs text-gray-500">Don&apos;t have an account?</span>
            <Separator className="flex-1" />
          </div>
          
          <Button 
            variant="outline" 
            className="w-full"
            onClick={() => navigate("/register")}
          >
            Create Account
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}