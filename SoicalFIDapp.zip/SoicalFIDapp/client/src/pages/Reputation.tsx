import { useQuery, useMutation } from "@tanstack/react-query";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { useAuth } from "@/contexts/Web3Context";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { StarIcon, Shield, Loader2, BadgeCheck, AlertCircle } from "lucide-react";
import { format } from "date-fns";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";

const ratingSchema = z.object({
  comment: z
    .string()
    .min(3, { message: "Comment must be at least 3 characters." })
    .max(500, { message: "Comment must be less than 500 characters." })
    .nullable(),
  score: z
    .number()
    .min(1, { message: "Score must be at least 1." })
    .max(5, { message: "Score must be no more than 5." })
});

export default function Reputation() {
  const { isConnected } = useAuth();
  const { toast } = useToast();
  
  // Mock user ID for demo - in a real app, this would be from authentication
  const userId = 1;
  
  // Fetch user data
  const { data: userData, isLoading: userLoading } = useQuery({
    queryKey: ['/api/profiles/user', userId],
    enabled: !!userId && isConnected,
  });
  
  // Fetch ratings received
  const { data: ratingsReceived, isLoading: ratingsLoading } = useQuery({
    queryKey: ['/api/ratings/user', userId],
    enabled: !!userId && isConnected,
  });
  
  // Initialize form with rating schema
  const form = useForm<z.infer<typeof ratingSchema>>({
    resolver: zodResolver(ratingSchema),
    defaultValues: {
      comment: "",
      score: 5
    },
  });
  
  // Mock function for submitting rating (would be connected to real API)
  const handleSubmitRating = (values: z.infer<typeof ratingSchema>) => {
    toast({
      title: "Rating Submitted",
      description: `You rated this user ${values.score} stars.`,
    });
    form.reset();
  };
  
  // Calculate rating statistics
  const calculateRatingStats = (ratings = []) => {
    if (!ratings.length) return { average: 0, total: 0, distribution: [0, 0, 0, 0, 0] };
    
    const distribution = [0, 0, 0, 0, 0]; // Index 0 = 1 star, Index 4 = 5 stars
    let sum = 0;
    
    ratings.forEach((rating: any) => {
      sum += rating.score;
      distribution[rating.score - 1]++;
    });
    
    return {
      average: (sum / ratings.length).toFixed(1),
      total: ratings.length,
      distribution
    };
  };
  
  const ratingStats = calculateRatingStats(ratingsReceived);
  
  // If not connected
  if (!isConnected) {
    return (
      <div className="flex flex-col items-center justify-center h-[60vh] max-w-md mx-auto text-center">
        <div className="bg-primary/10 p-6 rounded-full mb-4">
          <StarIcon className="h-10 w-10 text-primary" />
        </div>
        <h2 className="text-2xl font-bold mb-2">Connect to View Reputation</h2>
        <p className="text-gray-500 mb-4">
          Connect your wallet to view your reputation and ratings from other users.
        </p>
        <Button className="w-full">Connect Wallet</Button>
      </div>
    );
  }
  
  // Loading state
  if (userLoading || ratingsLoading) {
    return (
      <div className="flex justify-center items-center h-[60vh]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <span className="ml-2 text-lg">Loading reputation data...</span>
      </div>
    );
  }
  
  const reputationScore = userData?.reputationScore || 0;
  const isVerified = userData?.verificationStatus || false;
  
  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <h1 className="text-3xl font-bold mb-2">Reputation & Ratings</h1>
      <p className="text-gray-500">
        Your on-chain reputation helps other users trust you. Higher reputation scores unlock additional features.
      </p>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Left column - reputation overview */}
        <div className="md:col-span-2 space-y-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>Reputation Overview</CardTitle>
              <CardDescription>
                Your current reputation score and verification status
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col md:flex-row items-center gap-6 mb-6">
                <div className="relative">
                  <div className={`
                    h-32 w-32 rounded-full flex items-center justify-center text-4xl font-bold
                    ${reputationScore >= 80 ? 'bg-green-100 text-green-600' :
                      reputationScore >= 60 ? 'bg-blue-100 text-blue-600' :
                      reputationScore >= 40 ? 'bg-yellow-100 text-yellow-600' :
                      reputationScore >= 20 ? 'bg-orange-100 text-orange-600' :
                      'bg-gray-100 text-gray-600'}
                  `}>
                    {reputationScore}
                  </div>
                  <div className="absolute -bottom-2 -right-2 bg-white rounded-full p-2 border border-gray-200">
                    <StarIcon className="h-8 w-8 text-yellow-400" />
                  </div>
                </div>
                
                <div className="flex-1 space-y-4">
                  <div>
                    <h3 className="text-lg font-medium">Reputation Level</h3>
                    <div className="flex items-center mt-1">
                      <Badge className={`mr-2 
                        ${reputationScore >= 80 ? 'bg-green-100 text-green-600 hover:bg-green-100' :
                          reputationScore >= 60 ? 'bg-blue-100 text-blue-600 hover:bg-blue-100' :
                          reputationScore >= 40 ? 'bg-yellow-100 text-yellow-600 hover:bg-yellow-100' :
                          reputationScore >= 20 ? 'bg-orange-100 text-orange-600 hover:bg-orange-100' :
                          'bg-gray-100 text-gray-600 hover:bg-gray-100'}
                      `}>
                        {reputationScore >= 80 ? 'Excellent' :
                          reputationScore >= 60 ? 'Good' :
                          reputationScore >= 40 ? 'Average' :
                          reputationScore >= 20 ? 'Fair' : 'New User'}
                      </Badge>
                      <span className="text-sm text-gray-500">
                        Based on {ratingStats.total} ratings
                      </span>
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-medium">Verification Status</h3>
                    <div className="flex items-center mt-1">
                      {isVerified ? (
                        <div className="flex items-center text-blue-600">
                          <BadgeCheck className="h-5 w-5 mr-1" />
                          <span>Verified User</span>
                        </div>
                      ) : (
                        <div className="flex items-center text-gray-500">
                          <AlertCircle className="h-5 w-5 mr-1" />
                          <span>Not Verified</span>
                          <Button size="sm" variant="outline" className="ml-3">
                            Get Verified
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
              
              <Separator className="my-6" />
              
              <div>
                <h3 className="text-lg font-medium mb-3">Reputation Benefits</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className={`p-4 rounded-lg border ${reputationScore >= 20 ? 'bg-gray-50 border-gray-200' : 'bg-gray-100 border-gray-300'}`}>
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-medium">Basic Features</span>
                      <Badge variant="outline" className="bg-green-50 text-green-600 border-green-200">
                        Unlocked
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-600">Access to basic matching and messaging</p>
                  </div>
                  
                  <div className={`p-4 rounded-lg border ${reputationScore >= 40 ? 'bg-gray-50 border-gray-200' : 'bg-gray-100 border-gray-300'}`}>
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-medium">Advanced Filters</span>
                      {reputationScore >= 40 ? (
                        <Badge variant="outline" className="bg-green-50 text-green-600 border-green-200">
                          Unlocked
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="bg-gray-50 text-gray-600 border-gray-200">
                          Locked
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm text-gray-600">Access to additional matching criteria</p>
                  </div>
                  
                  <div className={`p-4 rounded-lg border ${reputationScore >= 60 ? 'bg-gray-50 border-gray-200' : 'bg-gray-100 border-gray-300'}`}>
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-medium">Priority Matching</span>
                      {reputationScore >= 60 ? (
                        <Badge variant="outline" className="bg-green-50 text-green-600 border-green-200">
                          Unlocked
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="bg-gray-50 text-gray-600 border-gray-200">
                          Locked
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm text-gray-600">Your profile gets shown more frequently</p>
                  </div>
                  
                  <div className={`p-4 rounded-lg border ${reputationScore >= 80 ? 'bg-gray-50 border-gray-200' : 'bg-gray-100 border-gray-300'}`}>
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-medium">Premium Features</span>
                      {reputationScore >= 80 ? (
                        <Badge variant="outline" className="bg-green-50 text-green-600 border-green-200">
                          Unlocked
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="bg-gray-50 text-gray-600 border-gray-200">
                          Locked
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm text-gray-600">Access to all platform features and rewards</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* Right column - rating stats and details */}
        <div className="space-y-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>Rating Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-center gap-2 mb-4">
                <span className="text-3xl font-bold">{ratingStats.average}</span>
                <div className="flex">
                  {[1, 2, 3, 4, 5].map(star => (
                    <StarIcon 
                      key={star} 
                      className={`h-5 w-5 ${
                        star <= Math.round(parseFloat(ratingStats.average)) 
                          ? 'text-yellow-400 fill-yellow-400' 
                          : 'text-gray-300'
                      }`} 
                    />
                  ))}
                </div>
                <span className="text-sm text-gray-500">({ratingStats.total})</span>
              </div>
              
              <div className="space-y-2">
                {[5, 4, 3, 2, 1].map(stars => {
                  const count = ratingStats.distribution[stars - 1];
                  const percentage = ratingStats.total 
                    ? Math.round((count / ratingStats.total) * 100) 
                    : 0;
                  
                  return (
                    <div key={stars} className="flex items-center gap-2">
                      <div className="flex items-center w-12">
                        <span>{stars}</span>
                        <StarIcon className="h-4 w-4 text-yellow-400 ml-1" />
                      </div>
                      <div className="flex-1 h-2 bg-gray-100 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-yellow-400 rounded-full"
                          style={{ width: `${percentage}%` }}
                        ></div>
                      </div>
                      <div className="w-8 text-right text-sm">{count}</div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>Submit a Rating</CardTitle>
              <CardDescription>
                Rate other users you've interacted with
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(handleSubmitRating)} className="space-y-4">
                  <div className="flex justify-center mb-2">
                    <div className="flex">
                      {[1, 2, 3, 4, 5].map(star => (
                        <button
                          key={star}
                          type="button"
                          onClick={() => form.setValue('score', star)}
                          className="focus:outline-none"
                        >
                          <StarIcon 
                            className={`h-8 w-8 cursor-pointer hover:text-yellow-400 ${
                              star <= form.getValues('score') 
                                ? 'text-yellow-400 fill-yellow-400' 
                                : 'text-gray-300'
                            }`} 
                          />
                        </button>
                      ))}
                    </div>
                  </div>
                  
                  <FormField
                    control={form.control}
                    name="comment"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <Textarea
                            placeholder="Add a comment (optional)"
                            className="resize-none"
                            {...field}
                            value={field.value || ''}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <Button type="submit" className="w-full">
                    Submit Rating
                  </Button>
                  
                  <p className="text-xs text-gray-500 text-center">
                    Ratings are stored on-chain and cannot be modified after submission.
                  </p>
                </form>
              </Form>
            </CardContent>
          </Card>
        </div>
      </div>
      
      {/* List of received ratings */}
      <Card>
        <CardHeader>
          <CardTitle>Your Received Ratings</CardTitle>
          <CardDescription>
            Ratings and feedback from other users
          </CardDescription>
        </CardHeader>
        <CardContent>
          {ratingsReceived?.length === 0 ? (
            <div className="text-center py-8">
              <div className="bg-gray-100 p-4 rounded-full w-16 h-16 mx-auto mb-3 flex items-center justify-center">
                <StarIcon className="h-8 w-8 text-gray-400" />
              </div>
              <p className="text-gray-700 font-medium">No Ratings Yet</p>
              <p className="text-gray-500 mt-1">
                When users rate you, their feedback will appear here.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {/* Sample rating items - would be from the API in production */}
              {[
                {
                  id: 1,
                  fromUser: {
                    displayName: "Alex Thompson",
                    profilePicture: "",
                  },
                  score: 5,
                  comment: "Great conversation and a very genuine person. Would definitely recommend connecting!",
                  createdAt: new Date(new Date().setDate(new Date().getDate() - 2))
                },
                {
                  id: 2,
                  fromUser: {
                    displayName: "Jordan Liu",
                    profilePicture: "",
                  },
                  score: 4,
                  comment: "Very responsive and easy to talk to.",
                  createdAt: new Date(new Date().setDate(new Date().getDate() - 7))
                }
              ].map(rating => (
                <div key={rating.id} className="flex gap-4 p-4 border rounded-lg">
                  <Avatar>
                    <AvatarImage src={rating.fromUser.profilePicture} />
                    <AvatarFallback>
                      {rating.fromUser.displayName.slice(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-medium">{rating.fromUser.displayName}</span>
                      <div className="flex">
                        {[1, 2, 3, 4, 5].map(star => (
                          <StarIcon 
                            key={star} 
                            className={`h-4 w-4 ${
                              star <= rating.score 
                                ? 'text-yellow-400 fill-yellow-400' 
                                : 'text-gray-300'
                            }`} 
                          />
                        ))}
                      </div>
                    </div>
                    
                    <p className="text-gray-700 mb-2">{rating.comment}</p>
                    
                    <div className="text-xs text-gray-500">
                      {format(rating.createdAt, "PPP")}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}