import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/contexts/Web3Context";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, UserCircle, Edit, Shield, Star } from "lucide-react";

export default function Profile() {
  const { account, shortAddress, isConnected } = useAuth();
  const { toast } = useToast();
  
  // Mock user ID for demo - in a real app, this would be from authentication
  const userId = 1;
  
  // Fetch profile data
  const { data: profile, isLoading: profileLoading } = useQuery({
    queryKey: ['/api/profiles/user', userId],
    enabled: !!userId,
  });
  
  // Fetch user ratings
  const { data: ratings, isLoading: ratingsLoading } = useQuery({
    queryKey: ['/api/ratings/user', userId],
    enabled: !!userId,
  });
  
  // Fetch token balance
  const { data: tokenData, isLoading: tokenLoading } = useQuery({
    queryKey: ['/api/token-balance', userId],
    enabled: !!userId,
  });
  
  const handleEditProfile = () => {
    toast({
      title: "Coming Soon",
      description: "Profile editing will be available in the next update.",
    });
  };
  
  if (profileLoading) {
    return (
      <div className="flex justify-center items-center h-[60vh]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <span className="ml-2 text-lg">Loading profile...</span>
      </div>
    );
  }
  
  if (!profile) {
    return (
      <div className="flex flex-col items-center justify-center h-[60vh] space-y-4">
        <UserCircle className="h-24 w-24 text-gray-300" />
        <h2 className="text-2xl font-bold">Profile Not Found</h2>
        <p className="text-gray-500 max-w-md text-center">
          {isConnected 
            ? "You need to create a profile to continue. Complete your profile to start matching with others." 
            : "Please connect your wallet to view or create your profile."}
        </p>
        <Button>Create Profile</Button>
      </div>
    );
  }
  
  // Placeholder data - in a real app this would come from the API
  const displayName = profile.displayName;
  const bio = profile.bio || "No bio provided yet.";
  const age = profile.age || "N/A";
  const location = profile.location || "Not specified";
  const interests = profile.interests || [];
  const verificationStatus = profile.verificationStatus;
  const reputationScore = profile.reputationScore || 0;
  const profilePicture = profile.profilePicture || "";
  
  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">My Profile</h1>
        <Button onClick={handleEditProfile} className="flex items-center gap-2">
          <Edit className="h-4 w-4" /> Edit Profile
        </Button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Left column - profile details */}
        <div className="md:col-span-2 space-y-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-col md:flex-row gap-6">
                <Avatar className="h-24 w-24 border-2 border-primary">
                  <AvatarImage src={profilePicture} alt={displayName} />
                  <AvatarFallback>{displayName.slice(0, 2).toUpperCase()}</AvatarFallback>
                </Avatar>
                
                <div className="space-y-2 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h2 className="text-2xl font-bold">{displayName}</h2>
                    {verificationStatus && (
                      <Badge variant="outline" className="bg-blue-50 text-blue-600 border-blue-200">
                        <Shield className="h-3 w-3 mr-1" /> Verified
                      </Badge>
                    )}
                  </div>
                  
                  <div className="flex flex-wrap gap-2 items-center text-sm text-gray-500">
                    <span>{age} years</span>
                    <span>•</span>
                    <span>{location}</span>
                    <span>•</span>
                    <div className="flex items-center">
                      <Star className="h-4 w-4 text-yellow-400 mr-1" />
                      <span>{reputationScore} reputation</span>
                    </div>
                  </div>
                  
                  <p className="text-gray-700 mt-2">{bio}</p>
                </div>
              </div>
              
              <Separator className="my-6" />
              
              <div>
                <h3 className="font-medium mb-2">Interests</h3>
                <div className="flex flex-wrap gap-2">
                  {interests && interests.length > 0 ? (
                    interests.map((interest, index) => (
                      <Badge key={index} className="bg-primary/10 text-primary hover:bg-primary/20">
                        {interest}
                      </Badge>
                    ))
                  ) : (
                    <p className="text-gray-500 text-sm">No interests added yet</p>
                  )}
                </div>
              </div>
              
              <Separator className="my-6" />
              
              <div>
                <h3 className="font-medium mb-2">Wallet</h3>
                <div className="flex flex-col sm:flex-row sm:items-center gap-4">
                  <div className="bg-gray-100 rounded-lg px-3 py-2 flex-1">
                    <span className="text-gray-500 text-sm block">Connected Address</span>
                    <span className="font-mono">{shortAddress || "Not connected"}</span>
                  </div>
                  <div className="bg-primary/10 rounded-lg px-3 py-2">
                    <span className="text-gray-500 text-sm block">Token Balance</span>
                    <span className="font-medium text-primary">
                      {tokenLoading ? "Loading..." : `${tokenData?.balance || 0} LOVE`}
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* Right column - ratings and stats */}
        <div className="space-y-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Ratings & Reputation</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex justify-center mb-4">
                <div className="relative">
                  <div className="h-24 w-24 rounded-full flex items-center justify-center bg-primary/10 text-primary text-3xl font-bold">
                    {reputationScore}
                  </div>
                  <div className="absolute -bottom-2 -right-2 bg-white rounded-full p-1 border border-gray-200">
                    <Star className="h-6 w-6 text-yellow-400" />
                  </div>
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Total ratings</span>
                  <span className="font-medium">{ratings?.length || 0}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Reputation level</span>
                  <span className="font-medium">
                    {reputationScore >= 80 ? "Excellent" :
                      reputationScore >= 60 ? "Good" :
                      reputationScore >= 40 ? "Average" :
                      reputationScore >= 20 ? "Fair" : "New"}
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Profile completion</span>
                  <span className="font-medium">
                    {(profile.bio && profile.age && profile.location && profile.interests?.length) ? "100%" : "Incomplete"}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Recent Activity</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="text-sm">
                  <p className="text-gray-500">Last active</p>
                  <p>Today</p>
                </div>
                <div className="text-sm">
                  <p className="text-gray-500">New matches</p>
                  <p>3 this week</p>
                </div>
                <div className="text-sm">
                  <p className="text-gray-500">Messages</p>
                  <p>12 conversations</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}