import { useState } from "react";
import { Tab } from "@headlessui/react";
import ProposalList from "@/components/proposals/ProposalList";
import CreateProposalModal from "@/components/proposals/CreateProposalModal";
import { Button } from "@/components/ui/button";
import { useWeb3 } from "@/contexts/Web3Context";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

const Proposals = () => {
  const { account } = useWeb3();
  const { toast } = useToast();
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

  const handleCreateProposal = () => {
    if (!account) {
      toast({
        title: "Wallet not connected",
        description: "Please connect your wallet to create a proposal",
        variant: "destructive"
      });
      return;
    }
    
    setIsCreateModalOpen(true);
  };

  return (
    <>
      {/* Proposals Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">Proposals</h2>
          <p className="text-gray-600">View and vote on DAO governance proposals</p>
        </div>
        <Button
          onClick={handleCreateProposal}
          className="mt-4 md:mt-0 bg-primary hover:bg-blue-600 text-white flex items-center"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
          </svg>
          Create Proposal
        </Button>
      </div>
      
      {/* Proposal Tabs */}
      <Tab.Group>
        <Tab.List className="flex space-x-1 rounded-xl bg-white p-1 mb-6 shadow-sm border border-gray-100">
          <Tab className={({ selected }) => cn(
            "w-full rounded-lg py-2.5 text-sm font-medium leading-5",
            "ring-opacity-60 focus:outline-none focus:ring-1 focus:ring-primary",
            selected
              ? "bg-primary text-white shadow"
              : "text-gray-700 hover:bg-gray-100"
          )}>
            Active
          </Tab>
          <Tab className={({ selected }) => cn(
            "w-full rounded-lg py-2.5 text-sm font-medium leading-5",
            "ring-opacity-60 focus:outline-none focus:ring-1 focus:ring-primary",
            selected
              ? "bg-primary text-white shadow"
              : "text-gray-700 hover:bg-gray-100"
          )}>
            Executed
          </Tab>
          <Tab className={({ selected }) => cn(
            "w-full rounded-lg py-2.5 text-sm font-medium leading-5",
            "ring-opacity-60 focus:outline-none focus:ring-1 focus:ring-primary",
            selected
              ? "bg-primary text-white shadow"
              : "text-gray-700 hover:bg-gray-100"
          )}>
            Rejected
          </Tab>
        </Tab.List>
        <Tab.Panels>
          <Tab.Panel>
            <ProposalList status="active" showViewAll={false} title="Active Proposals" />
          </Tab.Panel>
          <Tab.Panel>
            <ProposalList status="executed" showViewAll={false} title="Executed Proposals" />
          </Tab.Panel>
          <Tab.Panel>
            <ProposalList status="rejected" showViewAll={false} title="Rejected Proposals" />
          </Tab.Panel>
        </Tab.Panels>
      </Tab.Group>
      
      {/* Create Proposal Modal */}
      <CreateProposalModal 
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
      />
    </>
  );
};

export default Proposals;
