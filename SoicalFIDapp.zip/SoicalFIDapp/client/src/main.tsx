import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { AuthProvider } from "./contexts/Web3Context";
import { QueryClientProvider } from '@tanstack/react-query';
import { queryClient } from './lib/queryClient';

// Polyfill global for libraries that expect Node.js environment
if (typeof window !== 'undefined') {
  // For libraries expecting 'global'
  (window as any).global = window;
  
  // For libraries expecting 'process'
  if (!window.process) {
    (window as any).process = { env: {} };
  }
  
  // For libraries that use 'Buffer'
  if (!window.Buffer) {
    // Empty implementation - will be replaced by actual implementation if needed
    (window as any).Buffer = { isBuffer: () => false };
  }
}

createRoot(document.getElementById("root")!).render(
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <App />
    </AuthProvider>
  </QueryClientProvider>
);
