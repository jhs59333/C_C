import React, { createContext, useState, useEffect, useContext, ReactNode } from 'react';
import { ethers } from 'ethers';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { useLocation } from 'wouter';

// Extending Window interface to include ethereum
declare global {
  interface Window {
    ethereum?: any;
  }
}

// User profile types
interface UserProfile {
  id: number;
  username: string;
  email: string | null;
  walletAddress: string | null;
  authMethod: 'email' | 'wallet';
  lastActive: string | null;
  createdAt: string;
}

interface ProfileData {
  id?: number;  // Added id property
  displayName: string;
  bio: string | null;
  gender: string | null;
  age: number | null;
  location: string | null;
  interests: string[];
  profilePicture: string | null;
  verificationStatus: boolean;
  reputationScore: number;
}

interface UserData {
  user: UserProfile;
  profile: ProfileData | null;
  preferences: any | null;
  tokenBalance: number;
}

interface AuthContextType {
  // User state
  user: UserProfile | null;
  profile: ProfileData | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  token: string | null;
  tokenBalance: number;
  
  // Web3 wallet properties
  account: string | null;
  isConnected: boolean;
  provider: ethers.BrowserProvider | null;
  signer: ethers.JsonRpcSigner | null;
  isConnecting: boolean;
  shortAddress: string | null;
  chainId: number | null;
  
  // Auth methods
  loginWithEmail: (email: string, password: string) => Promise<void>;
  registerWithEmail: (username: string, email: string, password: string) => Promise<void>;
  connectWallet: () => Promise<string | null>;
  disconnectWallet: () => void;
  loginWithWallet: (walletAddress: string, signature: string) => Promise<void>;
  registerWithWallet: (username: string, walletAddress: string) => Promise<void>;
  logout: () => Promise<void>;
  
  // Profile methods
  createProfile: (profileData: Partial<ProfileData>) => Promise<void>;
  updateProfile: (profileData: Partial<ProfileData>) => Promise<void>;
}

const defaultAuthContext: AuthContextType = {
  // User state
  user: null,
  profile: null,
  isAuthenticated: false,
  isLoading: true,
  token: null,
  tokenBalance: 0,
  
  // Web3 wallet properties
  account: null,
  isConnected: false,
  provider: null,
  signer: null,
  isConnecting: false,
  shortAddress: null,
  chainId: null,
  
  // Auth methods
  loginWithEmail: async () => {},
  registerWithEmail: async () => {},
  connectWallet: async () => null,
  disconnectWallet: () => {},
  loginWithWallet: async () => {},
  registerWithWallet: async () => {},
  logout: async () => {},
  
  // Profile methods
  createProfile: async () => {},
  updateProfile: async () => {},
};

const Web3Context = createContext<AuthContextType>(defaultAuthContext);

export const useAuth = () => useContext(Web3Context);
// Provide backward compatibility with existing components
export const useWeb3 = useAuth;

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  // User state
  const [user, setUser] = useState<UserProfile | null>(null);
  const [profile, setProfile] = useState<ProfileData | null>(null);
  const [token, setToken] = useState<string | null>(localStorage.getItem('auth_token'));
  const [tokenBalance, setTokenBalance] = useState<number>(0);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  
  // Web3 state
  const [account, setAccount] = useState<string | null>(null);
  const [provider, setProvider] = useState<ethers.BrowserProvider | null>(null);
  const [signer, setSigner] = useState<ethers.JsonRpcSigner | null>(null);
  const [isConnecting, setIsConnecting] = useState(false);
  const [chainId, setChainId] = useState<number | null>(null);
  
  const { toast } = useToast();
  const [, navigate] = useLocation();

  // Check if the window.ethereum object exists
  const hasMetaMask = typeof window !== 'undefined' && window.ethereum !== undefined;

  // Format the account address to display a shortened version
  const shortAddress = account 
    ? `${account.substring(0, 6)}...${account.substring(account.length - 4)}`
    : null;

  // Fetch current user data with the token
  const fetchCurrentUser = async () => {
    if (!token) {
      setIsLoading(false);
      return;
    }

    try {
      setIsLoading(true);
      
      // 添加超時處理，防止接口無響應時界面一直處於加載狀態
      const fetchWithTimeout = async () => {
        const timeout = new Promise((_, reject) => {
          setTimeout(() => reject(new Error('請求超時')), 5000);
        });
        
        try {
          const responsePromise = apiRequest({
            url: '/api/users/me',
            method: 'GET',
            headers: {
              'Authorization': `Bearer ${token}`
            }
          });
          
          return await Promise.race([responsePromise, timeout]);
        } catch (error) {
          console.error('API請求錯誤:', error);
          throw error;
        }
      };
      
      const response = await fetchWithTimeout();
      
      setUser(response.user);
      setProfile(response.profile);
      setTokenBalance(response.tokenBalance);
      
      // If user has a wallet address, try to connect to it
      if (response.user.authMethod === 'wallet' && response.user.walletAddress && hasMetaMask) {
        const provider = new ethers.BrowserProvider(window.ethereum);
        const accounts = await provider.send("eth_requestAccounts", []);
        
        // Check if the wallet address matches the user's registered address
        if (accounts.length > 0 && accounts[0].toLowerCase() === response.user.walletAddress.toLowerCase()) {
          const signer = await provider.getSigner();
          const network = await provider.getNetwork();
          
          setAccount(accounts[0]);
          setProvider(provider);
          setSigner(signer);
          setChainId(Number(network.chainId));
        }
      }
    } catch (error) {
      console.error('Error fetching user data:', error);
      // Token might be invalid or expired
      localStorage.removeItem('auth_token');
      setToken(null);
    } finally {
      setIsLoading(false);
    }
  };

  // Connect to MetaMask wallet and return the address (without login)
  const connectWallet = async (): Promise<string | null> => {
    // 模擬連接錢包，返回假地址用於測試
    // 真實情況下，應該檢查 MetaMask 是否安裝並請求訪問
    try {
      setIsConnecting(true);
      
      // 模擬錢包連接流程
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // 使用一個測試地址代替真實連接
      const mockWalletAddress = "0x742d35Cc6634C0532925a3b844Bc454e4438f44e";
      
      setAccount(mockWalletAddress);
      setProvider(null); // 測試模式下不設置 provider
      setSigner(null); // 測試模式下不設置 signer
      setChainId(1); // 設置為以太坊主網鏈 ID
      
      toast({
        title: "錢包已連接",
        description: `連接到 ${mockWalletAddress.substring(0, 6)}...${mockWalletAddress.substring(mockWalletAddress.length - 4)}`,
        variant: "default"
      });
      
      return mockWalletAddress;
    } catch (error) {
      console.error('連接錢包錯誤:', error);
      toast({
        title: "連接錯誤",
        description: "無法連接到錢包",
        variant: "destructive"
      });
      return null;
    } finally {
      setIsConnecting(false);
    }
  };

  // Register with email and password
  const registerWithEmail = async (username: string, email: string, password: string) => {
    try {
      const response = await apiRequest({
        url: '/api/users/register',
        method: 'POST',
        data: {
          authMethod: 'email',
          username,
          email,
          password
        }
      });
      
      // Save token and user data
      const { token: authToken, user: userData } = response;
      localStorage.setItem('auth_token', authToken);
      setToken(authToken);
      setUser(userData);
      
      toast({
        title: "Registration Successful",
        description: "Welcome to C_C Dating App!",
        variant: "default"
      });
      
      navigate('/dashboard');
    } catch (error: any) {
      console.error('Registration error:', error);
      toast({
        title: "Registration Failed",
        description: error.message || "Could not create account",
        variant: "destructive"
      });
      throw error;
    }
  };

  // Login with email and password
  const loginWithEmail = async (email: string, password: string) => {
    try {
      const response = await apiRequest({
        url: '/api/auth/login/email',
        method: 'POST',
        data: {
          authMethod: 'email',
          email,
          password
        }
      });
      
      // Save token and user data
      const { token: authToken, user: userData } = response;
      localStorage.setItem('auth_token', authToken);
      setToken(authToken);
      setUser(userData);
      
      toast({
        title: "Login Successful",
        description: "Welcome back!",
        variant: "default"
      });
      
      // Fetch full user data including profile
      await fetchCurrentUser();
      
      navigate('/dashboard');
    } catch (error: any) {
      console.error('Login error:', error);
      toast({
        title: "Login Failed",
        description: error.message || "Invalid email or password",
        variant: "destructive"
      });
      throw error;
    }
  };

  // Login with wallet
  const loginWithWallet = async (walletAddress: string, signature: string) => {
    try {
      const response = await apiRequest({
        url: '/api/auth/login/wallet',
        method: 'POST',
        data: {
          authMethod: 'wallet',
          walletAddress,
          signature
        }
      });
      
      // Save token and user data
      const { token: authToken, user: userData } = response;
      localStorage.setItem('auth_token', authToken);
      setToken(authToken);
      setUser(userData);
      
      toast({
        title: "Login Successful",
        description: "Welcome back!",
        variant: "default"
      });
      
      // Fetch full user data including profile
      await fetchCurrentUser();
      
      navigate('/dashboard');
    } catch (error: any) {
      console.error('Wallet login error:', error);
      
      // Check if user needs to register
      if (error.response?.data?.needsRegistration) {
        toast({
          title: "Account Not Found",
          description: "Please register with this wallet first",
          variant: "default"
        });
        navigate('/register');
      } else {
        toast({
          title: "Login Failed",
          description: error.message || "Could not login with wallet",
          variant: "destructive"
        });
      }
      throw error;
    }
  };

  // Register with wallet
  const registerWithWallet = async (username: string, walletAddress: string) => {
    try {
      const response = await apiRequest({
        url: '/api/users/register',
        method: 'POST',
        data: {
          authMethod: 'wallet',
          username,
          walletAddress
        }
      });
      
      // Save token and user data
      const { token: authToken, user: userData } = response;
      localStorage.setItem('auth_token', authToken);
      setToken(authToken);
      setUser(userData);
      
      toast({
        title: "Registration Successful",
        description: "Welcome to C_C Dating App!",
        variant: "default"
      });
      
      navigate('/dashboard');
    } catch (error: any) {
      console.error('Wallet registration error:', error);
      toast({
        title: "Registration Failed",
        description: error.message || "Could not create account",
        variant: "destructive"
      });
      throw error;
    }
  };

  // Disconnect wallet without logging out
  const disconnectWallet = () => {
    if (account) {
      setAccount(null);
      setProvider(null);
      setSigner(null);
      setChainId(null);
      
      toast({
        title: "Wallet Disconnected",
        description: "Your wallet has been disconnected",
        variant: "default"
      });
    }
  };

  // Logout
  const logout = async () => {
    try {
      if (token) {
        // Call logout API
        await apiRequest({
          url: '/api/auth/logout',
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token}`
          }
        });
      }
    } catch (error) {
      console.error('Error during logout:', error);
    } finally {
      // Clear local storage and state
      localStorage.removeItem('auth_token');
      localStorage.removeItem('walletConnected');
      
      // Reset all state
      setToken(null);
      setUser(null);
      setProfile(null);
      setTokenBalance(0);
      setAccount(null);
      setProvider(null);
      setSigner(null);
      setChainId(null);
      
      toast({
        title: "Logged Out",
        description: "You have been logged out successfully",
        variant: "default"
      });
      
      navigate('/login');
    }
  };

  // Create user profile
  const createProfile = async (profileData: Partial<ProfileData>) => {
    if (!user) {
      toast({
        title: "Authentication Required",
        description: "Please login first",
        variant: "destructive"
      });
      return;
    }
    
    try {
      const response = await apiRequest({
        url: '/api/profiles',
        method: 'POST',
        data: {
          userId: user.id,
          ...profileData
        },
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      setProfile(response);
      
      toast({
        title: "Profile Created",
        description: "Your profile has been created successfully",
        variant: "default"
      });
    } catch (error: any) {
      console.error('Error creating profile:', error);
      toast({
        title: "Profile Creation Failed",
        description: error.message || "Could not create profile",
        variant: "destructive"
      });
      throw error;
    }
  };

  // Update user profile
  const updateProfile = async (profileData: Partial<ProfileData>) => {
    if (!user || !profile) {
      toast({
        title: "Profile Not Found",
        description: "Please create a profile first",
        variant: "destructive"
      });
      return;
    }
    
    try {
      const response = await apiRequest({
        url: `/api/profiles/${profile.id}`,
        method: 'PATCH',
        data: profileData,
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      setProfile(response);
      
      toast({
        title: "Profile Updated",
        description: "Your profile has been updated successfully",
        variant: "default"
      });
    } catch (error: any) {
      console.error('Error updating profile:', error);
      toast({
        title: "Profile Update Failed",
        description: error.message || "Could not update profile",
        variant: "destructive"
      });
      throw error;
    }
  };

  // Load user data on initial render if token exists
  useEffect(() => {
    fetchCurrentUser();
  }, [token]);

  // Setup event listeners for account and chain changes
  useEffect(() => {
    if (hasMetaMask && provider && user?.authMethod === 'wallet') {
      const handleAccountsChanged = async (accounts: string[]) => {
        if (accounts.length === 0) {
          // User disconnected their wallet
          if (user && token) {
            // Only log out if the user was authenticated with a wallet
            await logout();
          }
        } else if (accounts[0] !== account) {
          // Account changed
          setAccount(accounts[0]);
          
          // If user is logged in with a wallet and the address doesn't match
          if (user && user.walletAddress && accounts[0].toLowerCase() !== user.walletAddress.toLowerCase()) {
            toast({
              title: "Wallet Changed",
              description: "Your connected wallet address has changed. Please login again.",
              variant: "destructive"
            });
            await logout();
          } else {
            toast({
              title: "Wallet Changed",
              description: `Switched to ${accounts[0].substring(0, 6)}...${accounts[0].substring(accounts[0].length - 4)}`,
              variant: "default"
            });
          }
        }
      };

      const handleChainChanged = (chainIdHex: string) => {
        const newChainId = parseInt(chainIdHex, 16);
        setChainId(newChainId);
        
        // Reload the page as recommended by MetaMask
        window.location.reload();
      };

      const handleDisconnect = async (error: { code: number; message: string }) => {
        console.error('Ethereum disconnected:', error);
        
        // If user was authenticated with a wallet, log them out
        if (user?.authMethod === 'wallet' && token) {
          await logout();
        } else {
          // Just disconnect the wallet without logging out
          setAccount(null);
          setProvider(null);
          setSigner(null);
          setChainId(null);
        }
      };

      window.ethereum.on('accountsChanged', handleAccountsChanged);
      window.ethereum.on('chainChanged', handleChainChanged);
      window.ethereum.on('disconnect', handleDisconnect);

      // Cleanup
      return () => {
        window.ethereum.removeListener('accountsChanged', handleAccountsChanged);
        window.ethereum.removeListener('chainChanged', handleChainChanged);
        window.ethereum.removeListener('disconnect', handleDisconnect);
      };
    }
  }, [provider, account, user, token]);

  const contextValue: AuthContextType = {
    // User state
    user,
    profile,
    isAuthenticated: !!user && !!token,
    isLoading,
    token,
    tokenBalance,
    
    // Web3 wallet properties
    account,
    isConnected: !!account,
    provider,
    signer,
    isConnecting,
    shortAddress,
    chainId,
    
    // Auth methods
    loginWithEmail,
    registerWithEmail,
    connectWallet,
    disconnectWallet,
    loginWithWallet,
    registerWithWallet,
    logout,
    
    // Profile methods
    createProfile,
    updateProfile,
  };

  return (
    <Web3Context.Provider value={contextValue}>
      {children}
    </Web3Context.Provider>
  );
};
