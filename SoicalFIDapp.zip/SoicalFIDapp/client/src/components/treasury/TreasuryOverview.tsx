import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface TreasuryData {
  tokenBalance: number;
  ethBalance: string;
  usdValue: string;
}

const TreasuryOverview = () => {
  const { data: treasury, isLoading } = useQuery<TreasuryData>({
    queryKey: ['/api/treasury'],
  });

  if (isLoading) {
    return (
      <Card className="bg-white rounded-xl shadow-md">
        <CardHeader>
          <CardTitle className="text-lg font-semibold">Treasury Overview</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="bg-blue-50 rounded-lg p-4">
                <p className="text-sm text-gray-500">
                  <Skeleton className="h-4 w-24" />
                </p>
                <div className="mt-2">
                  <Skeleton className="h-8 w-32" />
                </div>
                <div className="mt-2">
                  <Skeleton className="h-4 w-36" />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  const formatNumber = (num: number): string => {
    return num.toLocaleString();
  };

  return (
    <Card className="bg-white rounded-xl shadow-md">
      <CardHeader>
        <CardTitle className="text-lg font-semibold">Treasury Overview</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-blue-50 rounded-lg p-4">
            <p className="text-sm text-gray-500">DAO Token Balance</p>
            <div className="flex items-end">
              <span className="text-2xl font-bold">{formatNumber(treasury?.tokenBalance || 0)}</span>
              <span className="ml-2 text-sm font-medium text-gray-500">DAO</span>
            </div>
            <div className="mt-2 text-sm text-gray-500">
              <span className="text-green-600 flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="m18 15-6-6-6 6" />
                </svg>
                2.4% from last month
              </span>
            </div>
          </div>
          
          <div className="bg-blue-50 rounded-lg p-4">
            <p className="text-sm text-gray-500">ETH Balance</p>
            <div className="flex items-end">
              <span className="text-2xl font-bold">{treasury?.ethBalance || "0"}</span>
              <span className="ml-2 text-sm font-medium text-gray-500">ETH</span>
            </div>
            <div className="mt-2 text-sm text-gray-500">
              <span className="text-red-600 flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="m6 9 6 6 6-6" />
                </svg>
                0.8% from last month
              </span>
            </div>
          </div>
          
          <div className="bg-blue-50 rounded-lg p-4">
            <p className="text-sm text-gray-500">USD Value</p>
            <div className="flex items-end">
              <span className="text-2xl font-bold">
                ${treasury?.usdValue ? 
                  Number(treasury.usdValue).toLocaleString() : 
                  "0"}
              </span>
            </div>
            <div className="mt-2 text-sm text-gray-500">
              <span className="text-green-600 flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="m18 15-6-6-6 6" />
                </svg>
                5.3% from last month
              </span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default TreasuryOverview;
