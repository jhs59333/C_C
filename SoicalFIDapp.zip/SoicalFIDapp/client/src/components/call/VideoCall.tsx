import React, { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/Web3Context';
import { io, Socket } from 'socket.io-client';
import { Phone, PhoneOff, Mic, MicOff, Video, VideoOff } from 'lucide-react';

interface VideoCallProps {
  matchId: number;
  recipientId: number;
  recipientName: string;
  onEndCall: () => void;
}

const VideoCall: React.FC<VideoCallProps> = ({ 
  matchId, 
  recipientId,
  recipientName,
  onEndCall 
}) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [receivingCall, setReceivingCall] = useState(false);
  const [callAccepted, setCallAccepted] = useState(false);
  const [callEnded, setCallEnded] = useState(false);
  const [callerSignal, setCallerSignal] = useState<any>();
  const [calling, setCalling] = useState(false);
  const [audioEnabled, setAudioEnabled] = useState(true);
  const [videoEnabled, setVideoEnabled] = useState(true);
  const [SimplePeer, setSimplePeer] = useState<any>(null);

  const myVideo = useRef<HTMLVideoElement>(null);
  const userVideo = useRef<HTMLVideoElement>(null);
  const connectionRef = useRef<any>(null);
  const socketRef = useRef<Socket | null>(null);

  // Load SimplePeer dynamically to avoid global is not defined error
  useEffect(() => {
    const loadSimplePeer = async () => {
      try {
        const SimplePeerModule = await import('simple-peer');
        setSimplePeer(SimplePeerModule.default || SimplePeerModule);
      } catch (error) {
        console.error("Error loading SimplePeer:", error);
        toast({
          title: "Loading Error",
          description: "Could not load video call components. Please refresh the page.",
          variant: "destructive"
        });
      }
    };
    
    loadSimplePeer();
  }, []);

  useEffect(() => {
    // Connect to socket server
    socketRef.current = io();

    // Request camera & mic access
    navigator.mediaDevices.getUserMedia({ video: true, audio: true })
      .then((currentStream) => {
        setStream(currentStream);
        if (myVideo.current) {
          myVideo.current.srcObject = currentStream;
        }
      })
      .catch((error) => {
        console.error("Error accessing media devices:", error);
        toast({
          title: "Media Access Error",
          description: "Cannot access camera or microphone. Please check permissions.",
          variant: "destructive"
        });
      });

    // Setup socket events
    if (socketRef.current) {
      socketRef.current.emit("join", { userId: user?.id, matchId });

      socketRef.current.on("callUser", (data) => {
        setReceivingCall(true);
        setCallerSignal(data.signal);
        toast({
          title: "Incoming Call",
          description: `${data.name} is calling you`,
          variant: "default"
        });
      });

      socketRef.current.on("callEnded", () => {
        handleEndCall();
        toast({
          title: "Call Ended",
          description: "The other user has ended the call",
          variant: "default"
        });
      });
    }

    // Cleanup function
    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
      if (socketRef.current) {
        socketRef.current.disconnect();
      }
      if (connectionRef.current) {
        connectionRef.current.destroy();
      }
    };
  }, [user?.id, matchId]);

  const callUser = async () => {
    if (!stream || !SimplePeer) return;
    
    setCalling(true);
    
    try {
      const peer = new SimplePeer({
        initiator: true,
        trickle: false,
        stream: stream
      });

      peer.on("signal", (data: any) => {
        if (socketRef.current) {
          socketRef.current.emit("callUser", {
            userToCall: recipientId,
            signalData: data,
            from: user?.id,
            name: user?.username
          });
        }
      });

      peer.on("stream", (currentStream: MediaStream) => {
        if (userVideo.current) {
          userVideo.current.srcObject = currentStream;
        }
      });

      socketRef.current?.on("callAccepted", (signal) => {
        setCallAccepted(true);
        setCalling(false);
        peer.signal(signal);
      });

      connectionRef.current = peer;
    } catch (error) {
      console.error("Error initializing peer connection:", error);
      setCalling(false);
      toast({
        title: "Connection Error",
        description: "Could not establish call. Please try again.",
        variant: "destructive"
      });
    }
  };

  const answerCall = () => {
    if (!stream || !SimplePeer) return;
    
    setCallAccepted(true);
    setReceivingCall(false);

    try {
      // Use SimplePeer from state to create the peer instance
      const peer = new SimplePeer({
        initiator: false,
        trickle: false,
        stream: stream
      });

      peer.on("signal", (data: any) => {
        socketRef.current?.emit("answerCall", { signal: data, to: recipientId });
      });

      peer.on("stream", (currentStream: MediaStream) => {
        if (userVideo.current) {
          userVideo.current.srcObject = currentStream;
        }
      });

      peer.signal(callerSignal);
      connectionRef.current = peer;
    } catch (error) {
      console.error("Error answering call:", error);
      setCallAccepted(false);
      toast({
        title: "Connection Error",
        description: "Could not answer call. Please try again.",
        variant: "destructive"
      });
    }
  };

  const handleEndCall = () => {
    setCallEnded(true);
    setCalling(false);
    setReceivingCall(false);
    
    if (connectionRef.current) {
      connectionRef.current.destroy();
    }
    
    socketRef.current?.emit("endCall", { userId: recipientId });
    
    // Stop all media tracks
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
    }
    
    onEndCall();
  };

  const toggleAudio = () => {
    if (stream) {
      stream.getAudioTracks().forEach(track => {
        track.enabled = !audioEnabled;
      });
      setAudioEnabled(!audioEnabled);
    }
  };

  const toggleVideo = () => {
    if (stream) {
      stream.getVideoTracks().forEach(track => {
        track.enabled = !videoEnabled;
      });
      setVideoEnabled(!videoEnabled);
    }
  };

  const isSimplePeerReady = !!SimplePeer;

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>
            {callAccepted && !callEnded ? 
              `Connected with ${recipientName}` : 
              (calling ? `Calling ${recipientName}...` : `Video Call with ${recipientName}`)}
          </span>
          {receivingCall && !callAccepted && (
            <div className="flex items-center gap-2 text-sm animate-pulse text-green-500">
              <span className="flex h-3 w-3 rounded-full bg-green-500"></span>
              Incoming call...
            </div>
          )}
        </CardTitle>
      </CardHeader>
      
      <CardContent className="flex flex-col lg:flex-row gap-4 mb-4">
        <div className="relative w-full lg:w-1/2 h-64 lg:h-80 bg-gray-800 rounded-lg overflow-hidden">
          <video 
            playsInline 
            muted 
            ref={myVideo} 
            autoPlay 
            className="absolute inset-0 w-full h-full object-cover"
          />
          <div className="absolute bottom-2 left-2 bg-black/50 text-white px-2 py-1 rounded text-sm">
            You {!videoEnabled && "(Video Off)"}
          </div>
        </div>
        
        {callAccepted && !callEnded && (
          <div className="relative w-full lg:w-1/2 h-64 lg:h-80 bg-gray-800 rounded-lg overflow-hidden">
            <video 
              playsInline 
              ref={userVideo} 
              autoPlay 
              className="absolute inset-0 w-full h-full object-cover" 
            />
            <div className="absolute bottom-2 left-2 bg-black/50 text-white px-2 py-1 rounded text-sm">
              {recipientName}
            </div>
          </div>
        )}
      </CardContent>
      
      <CardFooter className="flex justify-center gap-4">
        {callAccepted && !callEnded ? (
          <>
            <Button 
              variant="outline" 
              size="icon" 
              onClick={toggleAudio}
              className={audioEnabled ? "bg-gray-200" : "bg-red-100 text-red-500"}
            >
              {audioEnabled ? <Mic /> : <MicOff />}
            </Button>
            
            <Button 
              variant="outline" 
              size="icon" 
              onClick={toggleVideo}
              className={videoEnabled ? "bg-gray-200" : "bg-red-100 text-red-500"}
            >
              {videoEnabled ? <Video /> : <VideoOff />}
            </Button>
            
            <Button 
              variant="destructive" 
              size="icon" 
              onClick={handleEndCall}
            >
              <PhoneOff />
            </Button>
          </>
        ) : (
          <>
            {receivingCall && !callAccepted ? (
              <>
                <Button 
                  variant="default" 
                  className="bg-green-500 hover:bg-green-600"
                  onClick={answerCall}
                  disabled={!isSimplePeerReady}
                >
                  <Phone className="mr-2 h-4 w-4" />
                  Answer Call
                </Button>
                <Button 
                  variant="destructive" 
                  onClick={handleEndCall}
                >
                  <PhoneOff className="mr-2 h-4 w-4" />
                  Decline
                </Button>
              </>
            ) : (
              <Button 
                variant="default" 
                className="bg-blue-500 hover:bg-blue-600"
                onClick={callUser}
                disabled={calling || !isSimplePeerReady}
              >
                <Phone className="mr-2 h-4 w-4" />
                {calling ? "Calling..." : (isSimplePeerReady ? "Start Call" : "Loading...")}
              </Button>
            )}
          </>
        )}
      </CardFooter>
    </Card>
  );
};

export default VideoCall;