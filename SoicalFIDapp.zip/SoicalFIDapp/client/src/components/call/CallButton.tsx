import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Phone } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import VideoCall from './VideoCall';

interface CallButtonProps {
  matchId: number;
  recipientId: number;
  recipientName: string;
}

const CallButton: React.FC<CallButtonProps> = ({ 
  matchId, 
  recipientId, 
  recipientName 
}) => {
  const [isCallDialogOpen, setIsCallDialogOpen] = useState(false);

  const handleEndCall = () => {
    setIsCallDialogOpen(false);
  };

  return (
    <Dialog open={isCallDialogOpen} onOpenChange={setIsCallDialogOpen}>
      <DialogTrigger asChild>
        <Button 
          variant="outline" 
          size="icon" 
          className="bg-blue-50 text-blue-600 hover:bg-blue-100 hover:text-blue-700 rounded-full"
          title="Start video call"
        >
          <Phone size={18} />
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-4xl">
        <DialogHeader>
          <DialogTitle>Video Call</DialogTitle>
        </DialogHeader>
        <VideoCall 
          matchId={matchId}
          recipientId={recipientId}
          recipientName={recipientName}
          onEndCall={handleEndCall}
        />
      </DialogContent>
    </Dialog>
  );
};

export default CallButton;