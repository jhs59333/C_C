import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";

// Member interface since we don't have it in schema.ts
interface Member {
  id: number;
  userId: number;
  displayName?: string;
  address?: string;
  tokenBalance?: number;
  joinedAt: Date;
}

interface MemberListProps {
  limit?: number;
  showViewAll?: boolean;
  title?: string;
}

const MemberList = ({ limit, showViewAll = true, title = "Recent Members" }: MemberListProps) => {
  const { data: members, isLoading } = useQuery<Member[]>({
    queryKey: [`/api/members${limit ? `?limit=${limit}` : ''}`],
  });

  // Format the wallet address to a shorter version
  const formatAddress = (address?: string) => {
    if (!address) return "Unknown";
    return `${address.substring(0, 6)}...${address.substring(address.length - 4)}`;
  };

  // Generate initials from address for the avatar
  const getInitials = (address?: string) => {
    if (!address) return "XX";
    return address.substring(2, 4).toUpperCase();
  };

  // Get a random color class based on the address
  const getColorClass = (address?: string) => {
    const colors = ["primary", "secondary", "accent", "indigo", "violet", "fuchsia"];
    if (!address) return colors[0]; // 使用默認顏色
    const index = parseInt(address.substring(2, 4), 16) % colors.length;
    return colors[index];
  };

  // Calculate the voting power percentage
  const calculateVotingPower = (tokenBalance?: number) => {
    if (!tokenBalance) return "0%";
    if (!members || members.length === 0) return "0%";
    
    const totalTokens = members.reduce((sum, member) => sum + (member.tokenBalance || 0), 0);
    if (totalTokens === 0) return "0%";
    
    return ((tokenBalance / totalTokens) * 100).toFixed(2) + "%";
  };

  // Format the joined date
  const formatJoinedDate = (date: Date) => {
    const now = new Date();
    const joinedDate = new Date(date);
    const diffTime = Math.abs(now.getTime() - joinedDate.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) return "Today";
    if (diffDays === 1) return "Yesterday";
    if (diffDays < 7) return `${diffDays} days ago`;
    if (diffDays < 30) return `${Math.floor(diffDays / 7)} weeks ago`;
    return `${Math.floor(diffDays / 30)} months ago`;
  };

  if (isLoading) {
    return (
      <div>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold">{title}</h3>
          {showViewAll && (
            <Link href="/members" className="text-primary text-sm font-medium hover:underline">
              View all
            </Link>
          )}
        </div>
        
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[300px]">Member</TableHead>
                  <TableHead>Token Holdings</TableHead>
                  <TableHead>Voting Power</TableHead>
                  <TableHead>Joined</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {[1, 2, 3].map((i) => (
                  <TableRow key={i}>
                    <TableCell>
                      <div className="flex items-center">
                        <Skeleton className="h-8 w-8 rounded-full" />
                        <Skeleton className="h-4 w-36 ml-4" />
                      </div>
                    </TableCell>
                    <TableCell><Skeleton className="h-4 w-20" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-12" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-16" /></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </div>
      </div>
    );
  }

  if (!members || members.length === 0) {
    return (
      <div>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold">{title}</h3>
        </div>
        <div className="bg-white rounded-xl shadow-md p-6 text-center">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mx-auto text-gray-400 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
          </svg>
          <p className="text-gray-600">No members found.</p>
          <p className="text-gray-500 text-sm mt-1">Connect your wallet to become the first member.</p>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold">{title}</h3>
        {showViewAll && members.length > 0 && (
          <Link href="/members" className="text-primary text-sm font-medium hover:underline">
            View all
          </Link>
        )}
      </div>
      
      <div className="bg-white rounded-xl shadow-md overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[300px]">Member</TableHead>
                <TableHead>Token Holdings</TableHead>
                <TableHead>Voting Power</TableHead>
                <TableHead>Joined</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {members.map((member) => (
                <TableRow key={member.id}>
                  <TableCell>
                    <div className="flex items-center">
                      <div className={`flex-shrink-0 h-8 w-8 rounded-full bg-${getColorClass(member.address)}/10 flex items-center justify-center`}>
                        <span className={`text-${getColorClass(member.address)} font-medium text-sm`}>
                          {member.displayName ? member.displayName.substring(0, 2).toUpperCase() : getInitials(member.address)}
                        </span>
                      </div>
                      <div className="ml-4">
                        <div className="text-sm font-medium text-gray-900 font-mono">{formatAddress(member.address)}</div>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell className="text-sm text-gray-900">
                    {member.tokenBalance ? `${member.tokenBalance.toLocaleString()} DAO` : "0 DAO"}
                  </TableCell>
                  <TableCell className="text-sm text-gray-900">
                    {calculateVotingPower(member.tokenBalance)}
                  </TableCell>
                  <TableCell className="text-sm text-gray-500">
                    {member.joinedAt ? formatJoinedDate(member.joinedAt) : "Unknown"}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
};

export default MemberList;
