import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { useWeb3 } from "@/contexts/Web3Context";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Proposal } from "@shared/schema";
import TransactionModal from "@/components/common/TransactionModal";

interface ProposalCardProps {
  proposal: Proposal;
}

const ProposalCard = ({ proposal }: ProposalCardProps) => {
  const { account } = useWeb3();
  const { toast } = useToast();
  const [isTransactionModalOpen, setIsTransactionModalOpen] = useState(false);
  const [transactionState, setTransactionState] = useState<'pending' | 'success' | 'error'>('pending');
  const [currentVote, setCurrentVote] = useState<'yes' | 'no' | null>(null);

  // Calculate days remaining for voting
  const daysRemaining = () => {
    const now = new Date();
    const endDate = new Date(proposal.votingEndsAt);
    const diffTime = endDate.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays > 0 ? diffDays : 0;
  };

  // Calculate vote percentages
  const totalVotes = proposal.yesVotes + proposal.noVotes;
  const yesPercentage = totalVotes > 0 ? Math.round((proposal.yesVotes / totalVotes) * 100) : 0;
  const noPercentage = totalVotes > 0 ? 100 - yesPercentage : 0;

  // Format the proposer address for display
  const formatAddress = (address: string) => {
    return `${address.substring(0, 6)}...${address.substring(address.length - 4)}`;
  };

  const voteMutation = useMutation({
    mutationFn: async (voteType: 'yes' | 'no') => {
      if (!account) {
        throw new Error("Please connect your wallet to vote");
      }

      // In a real implementation, we would use the wallet to sign this transaction
      // For now, we'll simulate a transaction with the API
      const response = await apiRequest('POST', '/api/votes', {
        proposalId: proposal.id,
        voterAddress: account,
        voteType: voteType,
        votePower: 1, // In a real implementation, this would be the user's token balance
      });
      
      return response.json();
    },
    onSuccess: () => {
      // Simulate a blockchain transaction
      setTimeout(() => {
        setTransactionState('success');
        
        // Invalidate queries to refresh the data
        queryClient.invalidateQueries({ queryKey: [`/api/proposals`] });
        queryClient.invalidateQueries({ queryKey: [`/api/proposals?status=active`] });
      }, 2000);
    },
    onError: (error) => {
      console.error("Vote error:", error);
      setTransactionState('error');
      toast({
        title: "Voting Failed",
        description: error instanceof Error ? error.message : "Failed to cast your vote",
        variant: "destructive"
      });
    }
  });

  const handleVote = (voteType: 'yes' | 'no') => {
    if (!account) {
      toast({
        title: "Wallet not connected",
        description: "Please connect your wallet to vote",
        variant: "destructive"
      });
      return;
    }

    setCurrentVote(voteType);
    setTransactionState('pending');
    setIsTransactionModalOpen(true);
    
    voteMutation.mutate(voteType);
  };

  const closeTransactionModal = () => {
    setIsTransactionModalOpen(false);
    if (transactionState === 'success') {
      toast({
        title: "Vote Recorded",
        description: `Your ${currentVote?.toUpperCase()} vote has been recorded`,
        variant: "default"
      });
    }
  };

  return (
    <>
      <Card className="bg-white rounded-xl shadow-md transition-all duration-200 hover:-translate-y-1 hover:shadow-lg">
        <CardContent className="p-5">
          <div className="flex items-start justify-between">
            <div>
              <div className="flex items-center">
                <span className="inline-block px-2 py-1 text-xs font-medium bg-amber-100 text-amber-800 rounded-full">
                  {proposal.status === 'active' ? 'Voting' : proposal.status === 'executed' ? 'Executed' : 'Rejected'}
                </span>
                {proposal.status === 'active' && (
                  <span className="ml-2 text-xs text-gray-500">
                    Ends in {daysRemaining()} days
                  </span>
                )}
              </div>
              <h4 className="mt-2 text-lg font-semibold">{proposal.title}</h4>
              <p className="mt-1 text-gray-600 text-sm line-clamp-2">{proposal.description}</p>
            </div>
          </div>
          
          <div className="mt-4">
            <div className="flex items-center justify-between text-sm">
              <span>Yes: {yesPercentage}%</span>
              <span>No: {noPercentage}%</span>
            </div>
            <div className="mt-1 h-2 bg-gray-200 rounded-full overflow-hidden">
              <div className="h-full bg-green-500 rounded-full" style={{ width: `${yesPercentage}%` }}></div>
            </div>
          </div>
          
          <div className="mt-4 flex items-center text-sm text-gray-500">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
              <circle cx="12" cy="7" r="4" />
            </svg>
            <span>Proposed by <span className="font-mono">{formatAddress(proposal.proposerId)}</span></span>
          </div>
          
          {proposal.status === 'active' && (
            <div className="mt-4 pt-4 border-t border-gray-100 flex space-x-2">
              <Button
                className="flex-1 bg-green-100 hover:bg-green-200 text-green-800"
                variant="outline"
                onClick={() => handleVote('yes')}
                disabled={voteMutation.isPending}
              >
                Vote Yes
              </Button>
              <Button
                className="flex-1 bg-red-100 hover:bg-red-200 text-red-800"
                variant="outline"
                onClick={() => handleVote('no')}
                disabled={voteMutation.isPending}
              >
                Vote No
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Transaction Modal */}
      <TransactionModal 
        isOpen={isTransactionModalOpen}
        onClose={closeTransactionModal}
        state={transactionState}
        transactionHash="0x123...abc" // In a real implementation, this would be the actual transaction hash
      />
    </>
  );
};

export default ProposalCard;
