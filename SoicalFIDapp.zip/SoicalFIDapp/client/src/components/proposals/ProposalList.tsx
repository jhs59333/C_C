import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";
import ProposalCard from "./ProposalCard";
import { Proposal } from "@shared/schema";

interface ProposalListProps {
  status?: string;
  limit?: number;
  showViewAll?: boolean;
  title?: string;
}

const ProposalList = ({ status = "active", limit, showViewAll = true, title = "Active Proposals" }: ProposalListProps) => {
  const { data: proposals, isLoading } = useQuery<Proposal[]>({
    queryKey: [`/api/proposals?status=${status}${limit ? `&limit=${limit}` : ''}`],
  });

  if (isLoading) {
    return (
      <div className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold">{title}</h3>
          {showViewAll && <Link href="/proposals"><a className="text-primary text-sm font-medium hover:underline">View all</a></Link>}
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {[1, 2].map((i) => (
            <div key={i} className="bg-white rounded-xl shadow-md p-5">
              <div className="flex items-start justify-between">
                <div>
                  <Skeleton className="h-6 w-24 mb-2" />
                  <Skeleton className="h-6 w-64 mb-4" />
                  <Skeleton className="h-4 w-full mb-1" />
                  <Skeleton className="h-4 w-5/6" />
                </div>
              </div>
              
              <div className="mt-4">
                <div className="flex items-center justify-between text-sm">
                  <Skeleton className="h-4 w-16" />
                  <Skeleton className="h-4 w-16" />
                </div>
                <Skeleton className="h-2 w-full mt-2" />
              </div>
              
              <div className="mt-4">
                <Skeleton className="h-4 w-48" />
              </div>
              
              <div className="mt-4 pt-4 border-t border-gray-100 flex space-x-2">
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-10 w-full" />
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (!proposals || proposals.length === 0) {
    return (
      <div className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold">{title}</h3>
        </div>
        <div className="bg-white rounded-xl shadow-md p-6 text-center">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mx-auto text-gray-400 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
          </svg>
          <p className="text-gray-600">No proposals found.</p>
          <p className="text-gray-500 text-sm mt-1">Be the first to create a proposal for the DAO.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="mb-8">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold">{title}</h3>
        {showViewAll && proposals.length > 0 && (
          <Link href="/proposals"><a className="text-primary text-sm font-medium hover:underline">View all</a></Link>
        )}
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {proposals.map((proposal) => (
          <ProposalCard key={proposal.id} proposal={proposal} />
        ))}
      </div>
    </div>
  );
};

export default ProposalList;
