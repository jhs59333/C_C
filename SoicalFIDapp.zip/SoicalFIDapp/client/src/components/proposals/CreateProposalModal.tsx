import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import { useWeb3 } from "@/contexts/Web3Context";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { insertProposalSchema } from "@shared/schema";
import { z } from "zod";
import TransactionModal from "@/components/common/TransactionModal";

interface CreateProposalModalProps {
  isOpen: boolean;
  onClose: () => void;
}

// Extend the schema for form validation
const formSchema = insertProposalSchema.extend({
  votingPeriod: z.number().min(1).max(30),
});

type FormValues = z.infer<typeof formSchema>;

const CreateProposalModal = ({ isOpen, onClose }: CreateProposalModalProps) => {
  const { account } = useWeb3();
  const { toast } = useToast();
  const [isTransactionModalOpen, setIsTransactionModalOpen] = useState(false);
  const [transactionState, setTransactionState] = useState<'pending' | 'success' | 'error'>('pending');

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      description: "",
      type: "treasury",
      votingPeriod: 7,
      votingEndsAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      proposerId: account || "",
      status: "active",
    },
  });

  // Update the proposerId when the account changes
  if (account && form.getValues().proposerId !== account) {
    form.setValue("proposerId", account);
  }

  const createProposalMutation = useMutation({
    mutationFn: async (data: FormValues) => {
      if (!account) {
        throw new Error("Please connect your wallet to create a proposal");
      }

      // Calculate the voting end date based on the voting period
      const votingEndsAt = new Date();
      votingEndsAt.setDate(votingEndsAt.getDate() + data.votingPeriod);

      // Remove the votingPeriod field as it's not in the backend schema
      const { votingPeriod, ...proposalData } = data;
      proposalData.votingEndsAt = votingEndsAt;
      proposalData.proposerId = account;

      const response = await apiRequest("POST", "/api/proposals", proposalData);
      return response.json();
    },
    onSuccess: () => {
      // Simulate a blockchain transaction
      setTimeout(() => {
        setTransactionState('success');
        
        // Invalidate queries to refresh the data
        queryClient.invalidateQueries({ queryKey: [`/api/proposals`] });
        queryClient.invalidateQueries({ queryKey: [`/api/proposals?status=active`] });
      }, 2000);
    },
    onError: (error) => {
      console.error("Create proposal error:", error);
      setTransactionState('error');
      toast({
        title: "Proposal Creation Failed",
        description: error instanceof Error ? error.message : "Failed to create your proposal",
        variant: "destructive"
      });
    }
  });

  const onSubmit = (data: FormValues) => {
    setTransactionState('pending');
    setIsTransactionModalOpen(true);
    createProposalMutation.mutate(data);
  };

  const closeTransactionModal = () => {
    setIsTransactionModalOpen(false);
    if (transactionState === 'success') {
      toast({
        title: "Proposal Created",
        description: "Your proposal has been successfully created",
        variant: "default"
      });
      form.reset();
      onClose();
    }
  };

  return (
    <>
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold">Create New Proposal</DialogTitle>
            <DialogDescription className="text-gray-600">
              Create a new proposal for the DAO members to vote on.
            </DialogDescription>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Proposal Title</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Enter a clear, descriptive title" 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Explain your proposal in detail..." 
                        rows={4}
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="type"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Proposal Type</FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select the type of proposal" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="treasury">Treasury Action</SelectItem>
                        <SelectItem value="governance">Governance Change</SelectItem>
                        <SelectItem value="membership">Membership Rules</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="votingPeriod"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Voting Period (days)</FormLabel>
                    <FormControl>
                      <Input 
                        type="number"
                        min={1}
                        max={30}
                        {...field}
                        onChange={(e) => {
                          const value = parseInt(e.target.value);
                          field.onChange(value);
                          
                          // Update the votingEndsAt field based on the voting period
                          const votingEndsAt = new Date();
                          votingEndsAt.setDate(votingEndsAt.getDate() + value);
                          form.setValue("votingEndsAt", votingEndsAt);
                        }}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="bg-blue-50 rounded-lg p-4 text-sm">
                <p className="font-medium text-blue-800">About this proposal</p>
                <ul className="mt-2 text-blue-700 list-disc list-inside space-y-1">
                  <li>You need at least 1,000 DAO tokens to create a proposal</li>
                  <li>Proposal creation will require a transaction on Ethereum</li>
                  <li>Gas fees will apply to this transaction</li>
                </ul>
              </div>
              
              <div className="flex justify-end space-x-3 pt-2">
                <Button 
                  type="button" 
                  variant="ghost" 
                  onClick={onClose}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit"
                  disabled={createProposalMutation.isPending || !account}
                >
                  Create Proposal
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Transaction Modal */}
      <TransactionModal 
        isOpen={isTransactionModalOpen}
        onClose={closeTransactionModal}
        state={transactionState}
        transactionHash="0x123...abc" // In a real implementation, this would be the actual transaction hash
      />
    </>
  );
};

export default CreateProposalModal;
