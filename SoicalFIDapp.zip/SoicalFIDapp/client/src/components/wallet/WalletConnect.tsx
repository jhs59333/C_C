import { useAuth } from "@/contexts/Web3Context";
import { Button } from "@/components/ui/button";

const WalletConnect = () => {
  const { account, shortAddress, isConnected, connectWallet, disconnectWallet, isConnecting } = useAuth();

  return (
    <div className="ml-auto flex items-center space-x-3">
      {isConnected ? (
        <>
          <div className="hidden md:flex items-center bg-gray-100 rounded-full px-3 py-1 text-sm">
            <span className="rounded-full h-2 w-2 bg-green-400 mr-2"></span>
            <span className="text-xs font-medium font-mono">{shortAddress}</span>
          </div>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={disconnectWallet}
            className="border-gray-200 text-gray-700"
          >
            Disconnect
          </Button>
        </>
      ) : (
        <Button
          onClick={connectWallet}
          disabled={isConnecting}
          className="bg-primary hover:bg-blue-600 text-white rounded-lg px-4 py-2 text-sm font-medium transition-colors"
        >
          {isConnecting ? 'Connecting...' : 'Connect Wallet'}
        </Button>
      )}
      
      <div className="relative">
        <button className="p-1 rounded-full text-gray-500 hover:text-gray-700 focus:outline-none">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
            <path d="M13.73 21a2 2 0 0 1-3.46 0" />
          </svg>
        </button>
        <div className="absolute top-0 right-0 w-2 h-2 rounded-full bg-red-500"></div>
      </div>
      
      <button className="md:hidden p-1 rounded-full text-gray-500 hover:text-gray-700">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M4 12h16M4 6h16M4 18h16" />
        </svg>
      </button>
    </div>
  );
};

export default WalletConnect;
