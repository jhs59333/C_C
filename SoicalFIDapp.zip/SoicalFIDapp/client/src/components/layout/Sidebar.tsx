import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { useAuth } from "@/contexts/Web3Context";

const Sidebar = () => {
  const [location] = useLocation();
  const { account, shortAddress } = useAuth();

  const isActive = (path: string) => {
    if (path === "/dashboard" && location === "/") return true;
    return location === path;
  };

  return (
    <div className="bg-white shadow-md w-64 flex-shrink-0 hidden md:block relative h-screen">
      <div className="p-4 flex items-center">
        <div className="w-10 h-10 rounded-full bg-pink-500 flex items-center justify-center text-white">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5">
            <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
          </svg>
        </div>
        <h1 className="ml-3 font-bold text-lg">C_C</h1>
      </div>
      
      <nav className="mt-8 px-4">
        <div className="space-y-6">
          <div>
            <p className="text-gray-400 text-xs uppercase tracking-wider mb-3">MAIN FEATURES</p>
            <Link 
              href="/dashboard"
              className={cn(
                "flex items-center p-2 rounded-md text-gray-600 hover:bg-gray-100",
                isActive("/dashboard") && "bg-pink-50 text-pink-500"
              )}>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <rect x="3" y="3" width="7" height="9" />
                  <rect x="14" y="3" width="7" height="5" />
                  <rect x="14" y="12" width="7" height="9" />
                  <rect x="3" y="16" width="7" height="5" />
                </svg>
                <span>Home</span>
            </Link>
            <Link 
              href="/discover"
              className={cn(
                "flex items-center p-2 rounded-md text-gray-600 hover:bg-gray-100 mt-1",
                isActive("/discover") && "bg-pink-50 text-pink-500"
              )}>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="10" />
                  <line x1="2" y1="12" x2="22" y2="12" />
                  <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" />
                </svg>
                <span>Discover</span>
            </Link>
            <Link 
              href="/messages"
              className={cn(
                "flex items-center p-2 rounded-md text-gray-600 hover:bg-gray-100 mt-1",
                isActive("/messages") && "bg-pink-50 text-pink-500"
              )}>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
                </svg>
                <span>Messages</span>
            </Link>
            <Link 
              href="/matches"
              className={cn(
                "flex items-center p-2 rounded-md text-gray-600 hover:bg-gray-100 mt-1",
                isActive("/matches") && "bg-pink-50 text-pink-500"
              )}>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
                </svg>
                <span>Matches</span>
            </Link>
          </div>
          
          <div>
            <p className="text-gray-400 text-xs uppercase tracking-wider mb-3">ACCOUNT</p>
            <Link 
              href="/profile"
              className={cn(
                "flex items-center p-2 rounded-md text-gray-600 hover:bg-gray-100",
                isActive("/profile") && "bg-pink-50 text-pink-500"
              )}>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
                  <circle cx="12" cy="7" r="4" />
                </svg>
                <span>Profile</span>
            </Link>
            <Link 
              href="/reputation"
              className={cn(
                "flex items-center p-2 rounded-md text-gray-600 hover:bg-gray-100 mt-1",
                isActive("/reputation") && "bg-pink-50 text-pink-500"
              )}>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
                </svg>
                <span>Reputation</span>
            </Link>
            <Link 
              href="/settings"
              className={cn(
                "flex items-center p-2 rounded-md text-gray-600 hover:bg-gray-100 mt-1",
                isActive("/settings") && "bg-pink-50 text-pink-500"
              )}>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" />
                  <circle cx="12" cy="12" r="3" />
                </svg>
                <span>Settings</span>
            </Link>
          </div>
        </div>
      </nav>
      
      {account && (
        <div className="absolute bottom-0 w-64 p-4 border-t">
          <div className="flex items-center">
            <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center overflow-hidden">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
                <circle cx="12" cy="7" r="4" />
              </svg>
            </div>
            <div className="ml-3 overflow-hidden">
              <p className="text-sm font-medium truncate font-mono">{shortAddress}</p>
              <p className="text-xs text-gray-500">Wallet Connected</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Sidebar;
