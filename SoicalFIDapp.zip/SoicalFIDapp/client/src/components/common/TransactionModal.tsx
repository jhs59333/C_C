import { Dialog, DialogContent } from "@/components/ui/dialog";

interface TransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  state: 'pending' | 'success' | 'error';
  transactionHash?: string;
}

const TransactionModal = ({ isOpen, onClose, state, transactionHash }: TransactionModalProps) => {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md text-center">
        {state === 'pending' && (
          <div className="mb-4">
            <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-primary mx-auto"></div>
            <h3 className="text-xl font-bold mt-4">Transaction Pending</h3>
            <p className="text-gray-600 mt-2">Your transaction is being processed on the Ethereum blockchain.</p>
            <div className="mt-4 text-left bg-blue-50 rounded-lg p-4">
              <div className="flex items-center justify-between text-sm mb-2">
                <span className="text-gray-700">Transaction Hash:</span>
                <a 
                  href={`https://etherscan.io/tx/${transactionHash}`} 
                  className="text-primary hover:underline font-mono"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  {transactionHash}
                </a>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-700">Estimated Time:</span>
                <span>~1-2 minutes</span>
              </div>
            </div>
          </div>
        )}
        
        {state === 'success' && (
          <div>
            <div className="rounded-full h-16 w-16 bg-green-100 flex items-center justify-center mx-auto">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <h3 className="text-xl font-bold mt-4">Transaction Successful!</h3>
            <p className="text-gray-600 mt-2">Your transaction has been confirmed on the blockchain.</p>
            <div className="mt-4 text-left bg-green-50 rounded-lg p-4">
              <div className="flex items-center justify-between text-sm mb-2">
                <span className="text-gray-700">Transaction Hash:</span>
                <a 
                  href={`https://etherscan.io/tx/${transactionHash}`} 
                  className="text-primary hover:underline font-mono"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  {transactionHash}
                </a>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-700">Block Number:</span>
                <span>15,422,301</span>
              </div>
            </div>
          </div>
        )}
        
        {state === 'error' && (
          <div>
            <div className="rounded-full h-16 w-16 bg-red-100 flex items-center justify-center mx-auto">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </div>
            <h3 className="text-xl font-bold mt-4">Transaction Failed</h3>
            <p className="text-gray-600 mt-2">There was an error processing your transaction.</p>
            <div className="mt-4 text-left bg-red-50 rounded-lg p-4">
              <div className="flex items-center justify-between text-sm mb-2">
                <span className="text-gray-700">Error:</span>
                <span className="text-red-600">User rejected transaction</span>
              </div>
            </div>
          </div>
        )}
        
        <div className="mt-6">
          <button 
            className="w-full bg-gray-200 hover:bg-gray-300 text-gray-800 rounded-lg px-4 py-2 font-medium transition-colors"
            onClick={onClose}
          >
            Close
          </button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default TransactionModal;
