import { useState, useEffect } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { X, CheckCircle, AlertCircle, AlertTriangle, Info } from "lucide-react";

export type NotificationType = "success" | "error" | "warning" | "info";

export interface Notification {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
}

// Global notifications store
let notifications: Notification[] = [];
let listeners: Array<(notifications: Notification[]) => void> = [];

const addNotification = (notification: Omit<Notification, "id">) => {
  const id = Math.random().toString(36).substring(2, 9);
  const newNotification = { ...notification, id };
  notifications = [...notifications, newNotification];
  listeners.forEach(listener => listener(notifications));
  
  // Auto-remove after 5 seconds
  setTimeout(() => {
    removeNotification(id);
  }, 5000);
  
  return id;
};

const removeNotification = (id: string) => {
  notifications = notifications.filter(n => n.id !== id);
  listeners.forEach(listener => listener(notifications));
};

// Notification component to show a single notification
const NotificationItem = ({ notification, onClose }: { notification: Notification, onClose: () => void }) => {
  const { type, title, message } = notification;
  
  let bgColor = "bg-blue-100 border-l-4 border-blue-500";
  let icon = <Info className="h-5 w-5 text-blue-500" />;
  
  switch (type) {
    case "success":
      bgColor = "bg-green-100 border-l-4 border-green-500";
      icon = <CheckCircle className="h-5 w-5 text-green-500" />;
      break;
    case "error":
      bgColor = "bg-red-100 border-l-4 border-red-500";
      icon = <AlertCircle className="h-5 w-5 text-red-500" />;
      break;
    case "warning":
      bgColor = "bg-amber-100 border-l-4 border-amber-500";
      icon = <AlertTriangle className="h-5 w-5 text-amber-500" />;
      break;
  }
  
  return (
    <motion.div
      initial={{ opacity: 0, y: -10, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95, transition: { duration: 0.2 } }}
      className={`${bgColor} p-4 rounded shadow-md flex items-center mb-2 transform transition-all duration-300 ease-in-out`}
    >
      <span className="mr-2">{icon}</span>
      <div className="flex-1">
        <p className="font-medium">{title}</p>
        {message && <p className="text-sm">{message}</p>}
      </div>
      <button
        onClick={onClose}
        className="ml-4 text-gray-500 hover:text-gray-700 focus:outline-none"
      >
        <X className="h-4 w-4" />
      </button>
    </motion.div>
  );
};

// Main notification system component
export const NotificationSystem = () => {
  const [currentNotifications, setCurrentNotifications] = useState<Notification[]>([]);
  
  useEffect(() => {
    const handleNotificationsChange = (newNotifications: Notification[]) => {
      setCurrentNotifications([...newNotifications]);
    };
    
    listeners.push(handleNotificationsChange);
    
    return () => {
      listeners = listeners.filter(listener => listener !== handleNotificationsChange);
    };
  }, []);
  
  return (
    <div className="fixed top-4 right-4 z-50 space-y-2 w-80">
      <AnimatePresence>
        {currentNotifications.map(notification => (
          <NotificationItem 
            key={notification.id}
            notification={notification}
            onClose={() => removeNotification(notification.id)}
          />
        ))}
      </AnimatePresence>
    </div>
  );
};

// Export helper functions
export const useNotifications = () => {
  return {
    addNotification,
    removeNotification,
    notifications
  };
};
