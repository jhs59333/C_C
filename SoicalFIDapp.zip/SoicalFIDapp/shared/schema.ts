import { pgTable, text, serial, integer, timestamp, boolean, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// This is a placeholder schema for the DAO proposal system
// It's needed for backward compatibility with existing code
export const proposals = pgTable("proposals", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  type: text("type").notNull(), // 'treasury', 'governance', 'membership', 'other'
  proposerId: text("proposer_id").notNull(), // Wallet address of the proposer
  status: text("status").notNull().default("active"), // 'active', 'executed', 'rejected', 'canceled'
  votingEndsAt: timestamp("voting_ends_at").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  executedAt: timestamp("executed_at"),
});

export const insertProposalSchema = createInsertSchema(proposals).omit({
  id: true,
  createdAt: true,
  executedAt: true,
});

export type InsertProposal = z.infer<typeof insertProposalSchema>;
export type Proposal = typeof proposals.$inferSelect;

// Base user schema with expanded profile for dating app
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  walletAddress: text("wallet_address").unique(), // Optional blockchain wallet address
  email: text("email").unique(), // Optional email for traditional login
  username: text("username").notNull().unique(),
  passwordHash: text("password_hash"), // Optional password hash for traditional login
  authMethod: text("auth_method").notNull().default("wallet"), // 'email', 'wallet', 'social'
  createdAt: timestamp("created_at").notNull().defaultNow(),
  lastActive: timestamp("last_active"),
});

// Schema for wallet-based registration
export const insertUserWalletSchema = createInsertSchema(users).pick({
  walletAddress: true,
  username: true,
}).extend({
  authMethod: z.literal("wallet")
});

// Schema for email-based registration
export const insertUserEmailSchema = createInsertSchema(users).pick({
  email: true,
  username: true,
}).extend({
  password: z.string().min(8), // Plain password (will be hashed before storage)
  authMethod: z.literal("email")
});

// Combined schema for any registration method
export const insertUserSchema = z.discriminatedUnion("authMethod", [
  insertUserWalletSchema,
  insertUserEmailSchema
]);

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// User profile information for dating
export const profiles = pgTable("profiles", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(), // References users.id
  displayName: text("display_name").notNull(),
  bio: text("bio"),
  gender: text("gender"),
  age: integer("age"),
  location: text("location"),
  interests: text("interests").array(), // Array of interests
  profilePicture: text("profile_picture"), // IPFS hash for profile picture
  verificationStatus: boolean("verification_status").default(false),
  reputationScore: integer("reputation_score").default(100), // 0-100 scale
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertProfileSchema = createInsertSchema(profiles)
  .omit({
    id: true,
    updatedAt: true,
    verificationStatus: true,
    reputationScore: true,
  });

export type InsertProfile = z.infer<typeof insertProfileSchema>;
export type Profile = typeof profiles.$inferSelect;

// Matching and dating preferences
export const preferences = pgTable("preferences", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  minAge: integer("min_age"),
  maxAge: integer("max_age"),
  genderPreference: text("gender_preference"),
  locationPreference: text("location_preference"),
  interestPreference: text("interest_preference").array(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertPreferenceSchema = createInsertSchema(preferences).omit({
  id: true,
  updatedAt: true,
});

export type InsertPreference = z.infer<typeof insertPreferenceSchema>;
export type Preference = typeof preferences.$inferSelect;

// Match connections between users
export const matches = pgTable("matches", {
  id: serial("id").primaryKey(),
  user1Id: integer("user1_id").notNull(), // First user in match
  user2Id: integer("user2_id").notNull(), // Second user in match
  status: text("status").notNull().default("pending"), // 'pending', 'matched', 'rejected'
  matchQuality: integer("match_quality").default(0), // Algorithm-determined match quality (0-100)
  createdAt: timestamp("created_at").notNull().defaultNow(),
  lastInteractionAt: timestamp("last_interaction_at"),
  // Prevents duplicate matches by ensuring one record per user pair
  // Note: This would be implemented in database migration/constraints
});

export const insertMatchSchema = createInsertSchema(matches).omit({
  id: true,
  createdAt: true,
  lastInteractionAt: true,
});

export type InsertMatch = z.infer<typeof insertMatchSchema>;
export type Match = typeof matches.$inferSelect;

// Messages between matched users
export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  matchId: integer("match_id").notNull(), // References matches.id
  senderId: integer("sender_id").notNull(), // References users.id
  content: text("content").notNull(),
  ipfsHash: text("ipfs_hash"), // For storing media content hash
  sentAt: timestamp("sent_at").notNull().defaultNow(),
  readAt: timestamp("read_at"),
  isEncrypted: boolean("is_encrypted").default(false),
});

export const insertMessageSchema = createInsertSchema(messages).omit({
  id: true,
  sentAt: true,
  readAt: true,
});

export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Message = typeof messages.$inferSelect;

// User ratings and reviews
export const ratings = pgTable("ratings", {
  id: serial("id").primaryKey(),
  fromUserId: integer("from_user_id").notNull(), // Who gave the rating
  toUserId: integer("to_user_id").notNull(), // Who received the rating
  score: integer("score").notNull(), // 1-5 scale
  comment: text("comment"),
  verifiedInteraction: boolean("verified_interaction").default(false), // Whether they actually met
  createdAt: timestamp("created_at").notNull().defaultNow(),
  // Each user can only rate another user once (would be implemented in DB constraints)
});

export const insertRatingSchema = createInsertSchema(ratings).omit({
  id: true,
  createdAt: true,
});

export type InsertRating = z.infer<typeof insertRatingSchema>;
export type Rating = typeof ratings.$inferSelect;

// Tokenomics - reward tokens for app participation
export const tokenTransactions = pgTable("token_transactions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  amount: integer("amount").notNull(), // Can be positive (reward) or negative (spent)
  transactionType: text("transaction_type").notNull(), // 'reward', 'purchase', 'transfer', etc.
  description: text("description"),
  transactionHash: text("transaction_hash"), // Blockchain transaction hash if applicable
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertTokenTransactionSchema = createInsertSchema(tokenTransactions).omit({
  id: true,
  createdAt: true,
});

export type InsertTokenTransaction = z.infer<typeof insertTokenTransactionSchema>;
export type TokenTransaction = typeof tokenTransactions.$inferSelect;

// Authentication tokens for sessions
export const authTokens = pgTable("auth_tokens", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  token: text("token").notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  revokedAt: timestamp("revoked_at"),
});

export const insertAuthTokenSchema = createInsertSchema(authTokens).omit({
  id: true,
  createdAt: true,
  revokedAt: true,
});

export type InsertAuthToken = z.infer<typeof insertAuthTokenSchema>;
export type AuthToken = typeof authTokens.$inferSelect;

// Login schema
export const loginUserEmailSchema = z.object({
  email: z.string().email(),
  password: z.string(),
  authMethod: z.literal("email")
});

export const loginUserWalletSchema = z.object({
  walletAddress: z.string(),
  signature: z.string(),
  authMethod: z.literal("wallet")
});

export const loginUserSchema = z.discriminatedUnion("authMethod", [
  loginUserEmailSchema,
  loginUserWalletSchema
]);
