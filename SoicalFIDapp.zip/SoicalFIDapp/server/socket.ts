import { Server as HttpServer } from 'http';
import { Server, Socket } from 'socket.io';
import { log } from './vite';

interface User {
  userId: number;
  socketId: string;
}

export function setupSocketServer(server: HttpServer) {
  const io = new Server(server, {
    cors: {
      origin: '*',
      methods: ['GET', 'POST']
    }
  });

  const users: User[] = [];

  io.on('connection', (socket: Socket) => {
    log(`New socket connection: ${socket.id}`, 'socket');

    // Join a room for a specific match
    socket.on('join', ({ userId, matchId }) => {
      log(`User ${userId} joined match room ${matchId}`, 'socket');
      
      // Add user to tracking array
      const existingUser = users.find(user => user.userId === userId);
      if (existingUser) {
        existingUser.socketId = socket.id;
      } else {
        users.push({ userId, socketId: socket.id });
      }
      
      // Join a room specific to this match
      socket.join(`match_${matchId}`);
    });

    // Initiate a call to another user
    socket.on('callUser', ({ userToCall, signalData, from, name }) => {
      log(`Call from ${from} to user ${userToCall}`, 'socket');
      
      const targetUser = users.find(user => user.userId === userToCall);
      if (targetUser) {
        io.to(targetUser.socketId).emit('callUser', {
          signal: signalData,
          from,
          name
        });
      } else {
        log(`User ${userToCall} not found or offline`, 'socket');
        // Inform caller that user is not available
        socket.emit('userUnavailable', { userId: userToCall });
      }
    });

    // Answer an incoming call
    socket.on('answerCall', ({ signal, to }) => {
      log(`Call answered to user ${to}`, 'socket');
      
      const targetUser = users.find(user => user.userId === to);
      if (targetUser) {
        io.to(targetUser.socketId).emit('callAccepted', signal);
      }
    });

    // End a call
    socket.on('endCall', ({ userId }) => {
      log(`Call ended with user ${userId}`, 'socket');
      
      const targetUser = users.find(user => user.userId === userId);
      if (targetUser) {
        io.to(targetUser.socketId).emit('callEnded');
      }
    });

    // Handle disconnect
    socket.on('disconnect', () => {
      log(`Socket disconnected: ${socket.id}`, 'socket');
      
      // Remove user from tracking array
      const index = users.findIndex(user => user.socketId === socket.id);
      if (index !== -1) {
        users.splice(index, 1);
      }
    });
  });

  log('Socket.IO server initialized', 'socket');
  return io;
}