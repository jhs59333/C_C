import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema, 
  insertProfileSchema, 
  insertPreferenceSchema, 
  insertMatchSchema, 
  insertMessageSchema, 
  insertRatingSchema,
  insertTokenTransactionSchema,
  insertAuthTokenSchema,
  loginUserSchema,
  loginUserEmailSchema,
  loginUserWalletSchema
} from "@shared/schema";
import { fromZodError } from "zod-validation-error";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import { ethers } from "ethers";

export async function registerRoutes(app: Express): Promise<Server> {
  // Secret key for JWT token signing
  const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key-change-in-production";
  const TOKEN_EXPIRY = '24h'; // Token expires in 24 hours
  
  // Middleware to verify JWT token
  const authenticateToken = async (req: any, res: any, next: any) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1]; // Bearer TOKEN format
    
    if (!token) {
      return res.status(401).json({ message: "Authentication token required" });
    }
    
    try {
      // Verify token
      const decoded = jwt.verify(token, JWT_SECRET) as any;
      
      // Get token from database to check if it's been revoked
      const authToken = await storage.getAuthTokenByToken(token);
      if (!authToken || authToken.revokedAt) {
        return res.status(401).json({ message: "Token is invalid or has been revoked" });
      }
      
      // Get user
      const user = await storage.getUser(decoded.userId);
      if (!user) {
        return res.status(401).json({ message: "User not found" });
      }
      
      // Attach user to request
      req.user = user;
      next();
    } catch (error) {
      return res.status(403).json({ message: "Invalid or expired token" });
    }
  };
  
  // === User Routes ===
  
  // Register a new user with email or wallet
  app.post("/api/users/register", async (req, res) => {
    try {
      const validation = insertUserSchema.safeParse(req.body);
      
      if (!validation.success) {
        return res.status(400).json({ 
          message: "Invalid user data", 
          errors: fromZodError(validation.error).message 
        });
      }
      
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(validation.data.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      // Additional checks based on auth method
      if (validation.data.authMethod === "email") {
        // Check if email already exists
        const existingEmail = await storage.getUserByEmail(validation.data.email);
        if (existingEmail) {
          return res.status(400).json({ message: "Email already in use" });
        }
        
        // Hash the password
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(validation.data.password, salt);
        
        // Create user with the hashed password
        const userData = {
          ...validation.data,
          password: hashedPassword // Will be mapped to passwordHash in storage
        };
        
        const user = await storage.createUser(userData);
        
        // Generate JWT token
        const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: TOKEN_EXPIRY });
        
        // Create auth token in database
        const expiresAt = new Date();
        expiresAt.setHours(expiresAt.getHours() + 24); // 24 hours from now
        
        await storage.createAuthToken({
          userId: user.id,
          token,
          expiresAt
        });
        
        // Return user data and token
        res.status(201).json({
          user: {
            id: user.id,
            username: user.username,
            email: user.email,
            authMethod: user.authMethod
          },
          token
        });
      } else if (validation.data.authMethod === "wallet") {
        // Check if wallet address already exists
        if (!validation.data.walletAddress) {
          return res.status(400).json({ message: "Wallet address is required for wallet authentication" });
        }
        
        const existingWallet = await storage.getUserByWalletAddress(validation.data.walletAddress);
        if (existingWallet) {
          return res.status(400).json({ message: "Wallet address already in use" });
        }
        
        const user = await storage.createUser(validation.data);
        
        // Generate JWT token
        const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: TOKEN_EXPIRY });
        
        // Create auth token in database
        const expiresAt = new Date();
        expiresAt.setHours(expiresAt.getHours() + 24); // 24 hours from now
        
        await storage.createAuthToken({
          userId: user.id,
          token,
          expiresAt
        });
        
        // Return user data and token
        res.status(201).json({
          user: {
            id: user.id,
            username: user.username,
            walletAddress: user.walletAddress,
            authMethod: user.authMethod
          },
          token
        });
      }
    } catch (error) {
      console.error("Error registering user:", error);
      res.status(500).json({ message: "Failed to register user" });
    }
  });
  
  // Login with email/password
  app.post("/api/auth/login/email", async (req, res) => {
    try {
      const validation = loginUserEmailSchema.safeParse(req.body);
      
      if (!validation.success) {
        return res.status(400).json({ 
          message: "Invalid login data", 
          errors: fromZodError(validation.error).message 
        });
      }
      
      // Find user by email
      const user = await storage.getUserByEmail(validation.data.email);
      
      if (!user) {
        return res.status(401).json({ message: "Invalid email or password" });
      }
      
      // Check if user is registered with email auth method
      if (user.authMethod !== "email") {
        return res.status(400).json({ 
          message: "This account uses a different authentication method",
          authMethod: user.authMethod
        });
      }
      
      // Verify password
      if (!user.passwordHash) {
        return res.status(500).json({ message: "Account configuration error" });
      }
      
      const validPassword = await bcrypt.compare(validation.data.password, user.passwordHash);
      if (!validPassword) {
        return res.status(401).json({ message: "Invalid email or password" });
      }
      
      // Update last active timestamp
      await storage.updateUserLastActive(user.id);
      
      // Generate JWT token
      const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: TOKEN_EXPIRY });
      
      // Create auth token in database
      const expiresAt = new Date();
      expiresAt.setHours(expiresAt.getHours() + 24); // 24 hours from now
      
      await storage.createAuthToken({
        userId: user.id,
        token,
        expiresAt
      });
      
      // Return user data and token
      res.json({
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          authMethod: user.authMethod
        },
        token
      });
    } catch (error) {
      console.error("Error logging in with email:", error);
      res.status(500).json({ message: "Failed to log in" });
    }
  });
  
  // Login with wallet
  app.post("/api/auth/login/wallet", async (req, res) => {
    try {
      const validation = loginUserWalletSchema.safeParse(req.body);
      
      if (!validation.success) {
        return res.status(400).json({ 
          message: "Invalid login data", 
          errors: fromZodError(validation.error).message 
        });
      }
      
      const { walletAddress, signature } = validation.data;
      
      // Find user by wallet address
      const user = await storage.getUserByWalletAddress(walletAddress);
      
      if (!user) {
        return res.status(404).json({ 
          message: "Wallet not registered",
          needsRegistration: true
        });
      }
      
      // Check if user is registered with wallet auth method
      if (user.authMethod !== "wallet") {
        return res.status(400).json({ 
          message: "This account uses a different authentication method",
          authMethod: user.authMethod
        });
      }
      
      // Verify signature (in a real app, we'd verify a message signed by the wallet)
      // For simplicity in this example, we'll just check if a signature is provided
      if (!signature) {
        return res.status(401).json({ message: "Invalid wallet signature" });
      }
      
      // In a real implementation, we would verify the signature:
      // const message = "Sign in to C_C Dating DApp"; // The message we asked the wallet to sign
      // const signerAddress = ethers.utils.verifyMessage(message, signature);
      // if (signerAddress.toLowerCase() !== walletAddress.toLowerCase()) {
      //   return res.status(401).json({ message: "Invalid signature" });
      // }
      
      // Update last active timestamp
      await storage.updateUserLastActive(user.id);
      
      // Generate JWT token
      const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: TOKEN_EXPIRY });
      
      // Create auth token in database
      const expiresAt = new Date();
      expiresAt.setHours(expiresAt.getHours() + 24); // 24 hours from now
      
      await storage.createAuthToken({
        userId: user.id,
        token,
        expiresAt
      });
      
      // Return user data and token
      res.json({
        user: {
          id: user.id,
          username: user.username,
          walletAddress: user.walletAddress,
          authMethod: user.authMethod
        },
        token
      });
    } catch (error) {
      console.error("Error logging in with wallet:", error);
      res.status(500).json({ message: "Failed to log in with wallet" });
    }
  });
  
  // Logout - revoke token
  app.post("/api/auth/logout", authenticateToken, async (req: any, res) => {
    try {
      const authHeader = req.headers['authorization'];
      const token = authHeader && authHeader.split(' ')[1];
      
      if (!token) {
        return res.status(400).json({ message: "No token provided" });
      }
      
      // Find and revoke the token
      const authToken = await storage.getAuthTokenByToken(token);
      if (authToken && !authToken.revokedAt) {
        await storage.revokeAuthToken(authToken.id);
      }
      
      res.json({ message: "Logged out successfully" });
    } catch (error) {
      console.error("Error logging out:", error);
      res.status(500).json({ message: "Failed to logout" });
    }
  });
  
  // Get current user (protected route)
  app.get("/api/users/me", authenticateToken, async (req: any, res) => {
    try {
      // User is already attached to request by the authenticateToken middleware
      const user = req.user;
      
      // Get profile and preferences if they exist
      const profile = await storage.getProfileByUserId(user.id);
      const preferences = await storage.getPreferenceByUserId(user.id);
      
      // Get token balance
      const tokenBalance = await storage.getUserTokenBalance(user.id);
      
      // Return user data with related information
      res.json({
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          walletAddress: user.walletAddress,
          authMethod: user.authMethod,
          lastActive: user.lastActive,
          createdAt: user.createdAt
        },
        profile: profile || null,
        preferences: preferences || null,
        tokenBalance
      });
    } catch (error) {
      console.error("Error fetching current user:", error);
      res.status(500).json({ message: "Failed to fetch user data" });
    }
  });
  
  // === Profile Routes ===
  
  // Create profile
  app.post("/api/profiles", async (req, res) => {
    try {
      const validation = insertProfileSchema.safeParse(req.body);
      
      if (!validation.success) {
        return res.status(400).json({ 
          message: "Invalid profile data", 
          errors: fromZodError(validation.error).message 
        });
      }
      
      // Check if user exists
      const user = await storage.getUser(validation.data.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Check if profile already exists for this user
      const existingProfile = await storage.getProfileByUserId(validation.data.userId);
      if (existingProfile) {
        return res.status(400).json({ message: "Profile already exists for this user" });
      }
      
      const profile = await storage.createProfile(validation.data);
      res.status(201).json(profile);
    } catch (error) {
      console.error("Error creating profile:", error);
      res.status(500).json({ message: "Failed to create profile" });
    }
  });
  
  // Get profile by user ID
  app.get("/api/profiles/user/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const profile = await storage.getProfileByUserId(userId);
      
      if (!profile) {
        return res.status(404).json({ message: "Profile not found" });
      }
      
      res.json(profile);
    } catch (error) {
      console.error("Error fetching profile:", error);
      res.status(500).json({ message: "Failed to fetch profile" });
    }
  });
  
  // Update profile
  app.patch("/api/profiles/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const profileData = req.body;
      
      // Check if profile exists
      const existingProfile = await storage.getProfile(id);
      if (!existingProfile) {
        return res.status(404).json({ message: "Profile not found" });
      }
      
      const updatedProfile = await storage.updateProfile(id, profileData);
      res.json(updatedProfile);
    } catch (error) {
      console.error("Error updating profile:", error);
      res.status(500).json({ message: "Failed to update profile" });
    }
  });
  
  // Get profiles (with filtering)
  app.get("/api/profiles", async (req, res) => {
    try {
      const filters = {
        gender: req.query.gender as string | undefined,
        minAge: req.query.minAge ? parseInt(req.query.minAge as string) : undefined,
        maxAge: req.query.maxAge ? parseInt(req.query.maxAge as string) : undefined,
        interests: req.query.interests ? (req.query.interests as string).split(',') : undefined,
        limit: req.query.limit ? parseInt(req.query.limit as string) : undefined
      };
      
      const profiles = await storage.getProfiles(filters);
      res.json(profiles);
    } catch (error) {
      console.error("Error fetching profiles:", error);
      res.status(500).json({ message: "Failed to fetch profiles" });
    }
  });
  
  // === Preferences Routes ===
  
  // Create or update preference
  app.post("/api/preferences", async (req, res) => {
    try {
      const validation = insertPreferenceSchema.safeParse(req.body);
      
      if (!validation.success) {
        return res.status(400).json({ 
          message: "Invalid preference data", 
          errors: fromZodError(validation.error).message 
        });
      }
      
      // Check if user exists
      const user = await storage.getUser(validation.data.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Check if preference already exists for this user
      const existingPreference = await storage.getPreferenceByUserId(validation.data.userId);
      
      if (existingPreference) {
        // Update existing preference
        const updatedPreference = await storage.updatePreference(
          existingPreference.id, 
          validation.data
        );
        return res.json(updatedPreference);
      }
      
      // Create new preference
      const preference = await storage.createPreference(validation.data);
      res.status(201).json(preference);
    } catch (error) {
      console.error("Error creating/updating preference:", error);
      res.status(500).json({ message: "Failed to create/update preference" });
    }
  });
  
  // Get preferences by user ID
  app.get("/api/preferences/user/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const preference = await storage.getPreferenceByUserId(userId);
      
      if (!preference) {
        return res.status(404).json({ message: "Preferences not found" });
      }
      
      res.json(preference);
    } catch (error) {
      console.error("Error fetching preferences:", error);
      res.status(500).json({ message: "Failed to fetch preferences" });
    }
  });
  
  // === Match Routes ===
  
  // Get potential matches for a user
  app.get("/api/matches/potential/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      
      // Check if user exists
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const potentialMatches = await storage.getPotentialMatches(userId, limit);
      res.json(potentialMatches);
    } catch (error) {
      console.error("Error fetching potential matches:", error);
      res.status(500).json({ message: "Failed to fetch potential matches" });
    }
  });
  
  // Get a diverse set of profiles as discovery suggestions (less strict matching)
  app.get("/api/matches/discover", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      const userId = req.query.userId ? parseInt(req.query.userId as string) : undefined;
      
      // Get all profiles 
      const allProfiles = await storage.getProfiles();
      
      // Filter out profiles that are already matched with the user if userId is provided
      let filteredProfiles = allProfiles;
      
      if (userId) {
        const existingMatches = await storage.getMatchesByUserId(userId);
        const matchedUserIds = existingMatches
          .filter(match => match.status !== 'rejected')
          .map(match => match.user1Id === userId ? match.user2Id : match.user1Id);
        
        // Filter out user's own profile and matched profiles
        filteredProfiles = allProfiles.filter(profile => 
          profile.userId !== userId && !matchedUserIds.includes(profile.userId));
      }
      
      // Calculate diverse match qualities - focus on high reputation & verification
      const diverseMatches = filteredProfiles.map(profile => {
        let diversityScore = 70; // Higher base score for more matches
        
        // Bonus for verified profiles
        if (profile.verificationStatus) {
          diversityScore += 5;
        }
        
        // Bonus for higher reputation
        if (profile.reputationScore !== null) {
          diversityScore += profile.reputationScore > 70 ? 5 : 0;
        }
        
        // Bonus for complete profiles (with photos and bios)
        if (profile.profilePicture && profile.bio) {
          diversityScore += 10;
        }
        
        // Randomize a bit to ensure diversity
        diversityScore += Math.floor(Math.random() * 10);
        
        return { 
          profile, 
          matchQuality: diversityScore / 100 // Convert to 0-1 range
        };
      });
      
      // Sort by score and return the requested number
      diverseMatches.sort((a, b) => b.matchQuality - a.matchQuality);
      res.json(diverseMatches.slice(0, limit));
    } catch (error) {
      console.error("Error fetching discovery suggestions:", error);
      res.status(500).json({ message: "Failed to fetch discovery suggestions" });
    }
  });
  
  // Create a match (like/swipe right)
  app.post("/api/matches", async (req, res) => {
    try {
      const validation = insertMatchSchema.safeParse(req.body);
      
      if (!validation.success) {
        return res.status(400).json({ 
          message: "Invalid match data", 
          errors: fromZodError(validation.error).message 
        });
      }
      
      // Check if users exist
      const user1 = await storage.getUser(validation.data.user1Id);
      const user2 = await storage.getUser(validation.data.user2Id);
      
      if (!user1 || !user2) {
        return res.status(404).json({ message: "One or both users not found" });
      }
      
      // Check if match already exists (in either direction)
      const existingMatches = await storage.getMatchesByUserId(validation.data.user1Id);
      const alreadyMatched = existingMatches.find(
        match => 
          (match.user1Id === validation.data.user1Id && match.user2Id === validation.data.user2Id) ||
          (match.user1Id === validation.data.user2Id && match.user2Id === validation.data.user1Id)
      );
      
      if (alreadyMatched) {
        // If the existing match is in the opposite direction and pending, update to matched
        if (alreadyMatched.user1Id === validation.data.user2Id && 
            alreadyMatched.user2Id === validation.data.user1Id &&
            alreadyMatched.status === "pending") {
          const updatedMatch = await storage.updateMatchStatus(alreadyMatched.id, "matched");
          return res.json({
            ...updatedMatch,
            isNewMatch: true
          });
        }
        
        return res.status(400).json({ 
          message: "Match already exists between these users",
          existingMatch: alreadyMatched
        });
      }
      
      // Create new match with pending status
      const match = await storage.createMatch({
        ...validation.data,
        status: "pending"
      });
      
      res.status(201).json(match);
    } catch (error) {
      console.error("Error creating match:", error);
      res.status(500).json({ message: "Failed to create match" });
    }
  });
  
  // Update match status (accept/reject)
  app.patch("/api/matches/:id/status", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { status } = req.body;
      
      if (!status || !["pending", "matched", "rejected"].includes(status)) {
        return res.status(400).json({ message: "Invalid status value" });
      }
      
      const match = await storage.getMatch(id);
      if (!match) {
        return res.status(404).json({ message: "Match not found" });
      }
      
      const updatedMatch = await storage.updateMatchStatus(id, status);
      res.json(updatedMatch);
    } catch (error) {
      console.error("Error updating match status:", error);
      res.status(500).json({ message: "Failed to update match status" });
    }
  });
  
  // Get matches for a user
  app.get("/api/matches/user/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      
      // Check if user exists
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const matches = await storage.getMatchesByUserId(userId);
      
      // Enhance the matches with profile info
      const enhancedMatches = await Promise.all(matches.map(async match => {
        const otherUserId = match.user1Id === userId ? match.user2Id : match.user1Id;
        const otherUserProfile = await storage.getProfileByUserId(otherUserId);
        
        return {
          ...match,
          otherUser: otherUserProfile
        };
      }));
      
      res.json(enhancedMatches);
    } catch (error) {
      console.error("Error fetching matches:", error);
      res.status(500).json({ message: "Failed to fetch matches" });
    }
  });
  
  // === Message Routes ===
  
  // Send a message
  app.post("/api/messages", async (req, res) => {
    try {
      const validation = insertMessageSchema.safeParse(req.body);
      
      if (!validation.success) {
        return res.status(400).json({ 
          message: "Invalid message data", 
          errors: fromZodError(validation.error).message 
        });
      }
      
      // Check if match exists
      const match = await storage.getMatch(validation.data.matchId);
      if (!match) {
        return res.status(404).json({ message: "Match not found" });
      }
      
      // Verify the sender is part of the match
      if (match.user1Id !== validation.data.senderId && match.user2Id !== validation.data.senderId) {
        return res.status(403).json({ message: "Sender is not part of this match" });
      }
      
      // Check if match status allows messaging
      if (match.status !== "matched") {
        return res.status(400).json({ message: "Cannot send messages in this match status" });
      }
      
      const message = await storage.createMessage(validation.data);
      res.status(201).json(message);
    } catch (error) {
      console.error("Error sending message:", error);
      res.status(500).json({ message: "Failed to send message" });
    }
  });
  
  // Get messages for a match
  app.get("/api/messages/match/:matchId", async (req, res) => {
    try {
      const matchId = parseInt(req.params.matchId);
      
      // Check if match exists
      const match = await storage.getMatch(matchId);
      if (!match) {
        return res.status(404).json({ message: "Match not found" });
      }
      
      const messages = await storage.getMessagesByMatchId(matchId);
      res.json(messages);
    } catch (error) {
      console.error("Error fetching messages:", error);
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });
  
  // Mark message as read
  app.patch("/api/messages/:id/read", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      
      const message = await storage.getMessage(id);
      if (!message) {
        return res.status(404).json({ message: "Message not found" });
      }
      
      const updatedMessage = await storage.markMessageAsRead(id);
      res.json(updatedMessage);
    } catch (error) {
      console.error("Error marking message as read:", error);
      res.status(500).json({ message: "Failed to mark message as read" });
    }
  });
  
  // === Proposals Route (for Dashboard) ===
  app.get("/api/proposals", async (req, res) => {
    try {
      const status = req.query.status as string | undefined;
      
      // 這僅是一個示例回應，實際應用中會從數據庫獲取
      const proposals = [
        {
          id: 1,
          title: "增加驗證獎勵",
          description: "將完成身份驗證的獎勵從50代幣增加到100代幣，以鼓勵更多用戶完成驗證。",
          type: "governance",
          proposerId: "0x1234567890abcdef1234567890abcdef12345678",
          status: "active",
          votingEndsAt: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000),
          createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
          executedAt: null,
          votes: {
            for: 15,
            against: 5,
            totalVotingPower: 100
          }
        },
        {
          id: 2,
          title: "實施評分獎勵系統",
          description: "為每次評分用戶行為提供10代幣獎勵，以鼓勵用戶提供誠實的反饋。",
          type: "treasury",
          proposerId: "0xabcdef1234567890abcdef1234567890abcdef12",
          status: "executed",
          votingEndsAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
          createdAt: new Date(Date.now() - 17 * 24 * 60 * 60 * 1000),
          executedAt: new Date(Date.now() - 9 * 24 * 60 * 60 * 1000),
          votes: {
            for: 35,
            against: 12,
            totalVotingPower: 100
          }
        },
        {
          id: 3,
          title: "擴展用戶隱私選項",
          description: "增加更多隱私設置選項，允許用戶控制個人資料的可見性和訊息加密設置。",
          type: "membership",
          proposerId: "0x7890abcdef1234567890abcdef1234567890abcd",
          status: "active",
          votingEndsAt: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000),
          createdAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000),
          executedAt: null,
          votes: {
            for: 28,
            against: 2,
            totalVotingPower: 100
          }
        }
      ];
      
      // 如果有狀態篩選，應用篩選
      const filteredProposals = status 
        ? proposals.filter(p => p.status === status)
        : proposals;
        
      res.json(filteredProposals);
    } catch (error) {
      console.error("Error fetching proposals:", error);
      res.status(500).json({ message: "Failed to fetch proposals" });
    }
  });
  
  // Create a new proposal
  app.post("/api/proposals", async (req, res) => {
    try {
      const { title, description, type, proposerId } = req.body;
      
      // 驗證必要欄位
      if (!title || !description || !type || !proposerId) {
        return res.status(400).json({ 
          message: "Missing required fields" 
        });
      }
      
      // 為了示範，我們只是返回一個模擬的提案對象
      const newProposal = {
        id: 4, // 在實際應用中會自動生成
        title,
        description,
        type,
        proposerId,
        status: "active",
        votingEndsAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7天後結束投票
        createdAt: new Date(),
        executedAt: null,
        votes: {
          for: 0,
          against: 0,
          totalVotingPower: 100
        }
      };
      
      res.status(201).json(newProposal);
    } catch (error) {
      console.error("Error creating proposal:", error);
      res.status(500).json({ message: "Failed to create proposal" });
    }
  });
  
  // Vote on a proposal
  app.post("/api/proposals/:id/vote", async (req, res) => {
    try {
      const proposalId = parseInt(req.params.id);
      const { voterId, vote } = req.body;
      
      // 驗證必要欄位
      if (!voterId || vote === undefined) {
        return res.status(400).json({ 
          message: "Missing required fields" 
        });
      }
      
      // 檢查投票類型是否有效
      if (vote !== "for" && vote !== "against") {
        return res.status(400).json({ 
          message: "Invalid vote value. Must be 'for' or 'against'" 
        });
      }
      
      // 為了示範，假設我們已經找到了提案
      const mockProposal = {
        id: proposalId,
        title: "增加驗證獎勵",
        description: "將完成身份驗證的獎勵從50代幣增加到100代幣，以鼓勵更多用戶完成驗證。",
        type: "governance",
        proposerId: "0x1234567890abcdef1234567890abcdef12345678",
        status: "active",
        votingEndsAt: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000),
        createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
        executedAt: null,
        votes: {
          for: 15,
          against: 5,
          totalVotingPower: 100
        }
      };
      
      // 更新投票
      if (vote === "for") {
        mockProposal.votes.for += 1;
      } else {
        mockProposal.votes.against += 1;
      }
      
      res.json({
        message: `Vote ${vote} recorded for proposal ${proposalId}`,
        proposal: mockProposal
      });
    } catch (error) {
      console.error("Error voting on proposal:", error);
      res.status(500).json({ message: "Failed to vote on proposal" });
    }
  });

  // === Members Route (for Dashboard) ===
  app.get("/api/members", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 5;
      const profiles = await storage.getProfiles({ limit });
      res.json(profiles);
    } catch (error) {
      console.error("Error fetching members:", error);
      res.status(500).json({ message: "Failed to fetch members" });
    }
  });

  // === Rating Routes ===
  
  // Create a rating
  app.post("/api/ratings", async (req, res) => {
    try {
      const validation = insertRatingSchema.safeParse(req.body);
      
      if (!validation.success) {
        return res.status(400).json({ 
          message: "Invalid rating data", 
          errors: fromZodError(validation.error).message 
        });
      }
      
      // Check if users exist
      const fromUser = await storage.getUser(validation.data.fromUserId);
      const toUser = await storage.getUser(validation.data.toUserId);
      
      if (!fromUser || !toUser) {
        return res.status(404).json({ message: "One or both users not found" });
      }
      
      // Check if rating already exists
      const existingRating = await storage.getRatingByUserPair(
        validation.data.fromUserId, 
        validation.data.toUserId
      );
      
      if (existingRating) {
        return res.status(400).json({ 
          message: "You have already rated this user" 
        });
      }
      
      const rating = await storage.createRating(validation.data);
      res.status(201).json(rating);
    } catch (error) {
      console.error("Error creating rating:", error);
      res.status(500).json({ message: "Failed to create rating" });
    }
  });
  
  // Get ratings for a user
  app.get("/api/ratings/user/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      
      // Check if user exists
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const ratings = await storage.getRatingsByToUserId(userId);
      res.json(ratings);
    } catch (error) {
      console.error("Error fetching ratings:", error);
      res.status(500).json({ message: "Failed to fetch ratings" });
    }
  });
  
  // === API健康檢查和測試 ===
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", message: "API伺服器運行正常" });
  });
  
  app.post("/api/echo", (req, res) => {
    res.json({ 
      message: "回應請求數據", 
      data: req.body,
      method: req.method,
      headers: req.headers,
      url: req.url,
      path: req.path
    });
  });
  
  // === Treasury Route (for Dashboard) ===
  app.get("/api/treasury", async (req, res) => {
    try {
      // 這僅是一個示例回應，在實際應用中會從區塊鏈獲取
      const treasuryData = {
        tokenBalance: 1000000,
        ethBalance: "10.5",
        usdValue: "25,750.00"
      };
      res.json(treasuryData);
    } catch (error) {
      console.error("Error fetching treasury data:", error);
      res.status(500).json({ message: "Failed to fetch treasury data" });
    }
  });

  // === Token Transaction Routes ===
  
  // Create a token transaction
  app.post("/api/token-transactions", async (req, res) => {
    try {
      const validation = insertTokenTransactionSchema.safeParse(req.body);
      
      if (!validation.success) {
        return res.status(400).json({ 
          message: "Invalid transaction data", 
          errors: fromZodError(validation.error).message 
        });
      }
      
      // Check if user exists
      const user = await storage.getUser(validation.data.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const transaction = await storage.createTokenTransaction(validation.data);
      
      // Get updated balance
      const balance = await storage.getUserTokenBalance(validation.data.userId);
      
      res.status(201).json({
        transaction,
        balance
      });
    } catch (error) {
      console.error("Error creating token transaction:", error);
      res.status(500).json({ message: "Failed to create token transaction" });
    }
  });
  
  // Get token balance for a user
  app.get("/api/token-balance/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      
      // Check if user exists
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const balance = await storage.getUserTokenBalance(userId);
      res.json({ userId, balance });
    } catch (error) {
      console.error("Error fetching token balance:", error);
      res.status(500).json({ message: "Failed to fetch token balance" });
    }
  });
  
  // Get token transaction history for a user
  app.get("/api/token-transactions/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      
      // Check if user exists
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const transactions = await storage.getTokenTransactionsByUserId(userId);
      const balance = await storage.getUserTokenBalance(userId);
      
      res.json({
        transactions,
        balance
      });
    } catch (error) {
      console.error("Error fetching token transactions:", error);
      res.status(500).json({ message: "Failed to fetch token transactions" });
    }
  });
  
  const httpServer = createServer(app);
  return httpServer;
}
