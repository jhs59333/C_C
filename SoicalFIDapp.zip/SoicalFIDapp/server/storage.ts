import { 
  users, type User, type InsertUser,
  profiles, type Profile, type InsertProfile,
  preferences, type Preference, type InsertPreference,
  matches, type Match, type InsertMatch,
  messages, type Message, type InsertMessage,
  ratings, type Rating, type InsertRating,
  tokenTransactions, type TokenTransaction, type InsertTokenTransaction,
  authTokens, type AuthToken, type InsertAuthToken
} from "@shared/schema";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByWalletAddress(walletAddress: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserLastActive(id: number): Promise<User | undefined>;
  
  // Profiles
  getProfile(id: number): Promise<Profile | undefined>;
  getProfileByUserId(userId: number): Promise<Profile | undefined>;
  getProfiles(filters?: {
    gender?: string;
    minAge?: number;
    maxAge?: number;
    interests?: string[];
    limit?: number;
  }): Promise<Profile[]>;
  createProfile(profile: InsertProfile): Promise<Profile>;
  updateProfile(id: number, profileData: Partial<Profile>): Promise<Profile | undefined>;
  updateVerificationStatus(id: number, status: boolean): Promise<Profile | undefined>;
  updateReputationScore(id: number, newScore: number): Promise<Profile | undefined>;
  
  // Preferences
  getPreference(id: number): Promise<Preference | undefined>;
  getPreferenceByUserId(userId: number): Promise<Preference | undefined>;
  createPreference(preference: InsertPreference): Promise<Preference>;
  updatePreference(id: number, preferenceData: Partial<Preference>): Promise<Preference | undefined>;
  
  // Matches
  getMatch(id: number): Promise<Match | undefined>;
  getMatchesByUserId(userId: number): Promise<Match[]>;
  getPotentialMatches(userId: number, limit?: number): Promise<{ profile: Profile; matchQuality: number }[]>;
  createMatch(match: InsertMatch): Promise<Match>;
  updateMatchStatus(id: number, status: string): Promise<Match | undefined>;
  updateLastInteraction(id: number): Promise<Match | undefined>;
  
  // Messages
  getMessage(id: number): Promise<Message | undefined>;
  getMessagesByMatchId(matchId: number): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  markMessageAsRead(id: number): Promise<Message | undefined>;
  
  // Ratings
  getRating(id: number): Promise<Rating | undefined>;
  getRatingsByToUserId(userId: number): Promise<Rating[]>;
  getRatingByUserPair(fromUserId: number, toUserId: number): Promise<Rating | undefined>; 
  createRating(rating: InsertRating): Promise<Rating>;
  
  // Token Transactions
  getTokenTransaction(id: number): Promise<TokenTransaction | undefined>;
  getTokenTransactionsByUserId(userId: number): Promise<TokenTransaction[]>;
  createTokenTransaction(transaction: InsertTokenTransaction): Promise<TokenTransaction>;
  getUserTokenBalance(userId: number): Promise<number>;
  
  // Auth Tokens
  getAuthToken(id: number): Promise<AuthToken | undefined>;
  getAuthTokenByToken(token: string): Promise<AuthToken | undefined>;
  getAuthTokensByUserId(userId: number): Promise<AuthToken[]>;
  createAuthToken(token: InsertAuthToken): Promise<AuthToken>;
  revokeAuthToken(id: number): Promise<AuthToken | undefined>;
  revokeAllUserTokens(userId: number): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private profiles: Map<number, Profile>;
  private preferences: Map<number, Preference>;
  private matches: Map<number, Match>;
  private messages: Map<number, Message>;
  private ratings: Map<number, Rating>;
  private tokenTransactions: Map<number, TokenTransaction>;
  private authTokens: Map<number, AuthToken>;
  
  private currentUserId: number;
  private currentProfileId: number;
  private currentPreferenceId: number;
  private currentMatchId: number;
  private currentMessageId: number;
  private currentRatingId: number;
  private currentTokenTransactionId: number;
  private currentAuthTokenId: number;

  constructor() {
    this.users = new Map();
    this.profiles = new Map();
    this.preferences = new Map();
    this.matches = new Map();
    this.messages = new Map();
    this.ratings = new Map();
    this.tokenTransactions = new Map();
    this.authTokens = new Map();
    
    this.currentUserId = 1;
    this.currentProfileId = 1;
    this.currentPreferenceId = 1;
    this.currentMatchId = 1;
    this.currentMessageId = 1;
    this.currentRatingId = 1;
    this.currentTokenTransactionId = 1;
    this.currentAuthTokenId = 1;
  }

  // Users
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }
  
  async getUserByWalletAddress(walletAddress: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.walletAddress && user.walletAddress.toLowerCase() === walletAddress.toLowerCase(),
    );
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email && user.email.toLowerCase() === email.toLowerCase()
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    
    let user: User;
    
    if (insertUser.authMethod === "email") {
      // Email-based registration
      user = {
        id,
        email: insertUser.email,
        username: insertUser.username,
        passwordHash: insertUser.password, // Will be hashed before storage in routes
        walletAddress: null,
        authMethod: insertUser.authMethod,
        createdAt: new Date(),
        lastActive: new Date()
      };
    } else {
      // Wallet-based registration
      user = {
        id,
        walletAddress: insertUser.walletAddress,
        username: insertUser.username,
        email: null,
        passwordHash: null,
        authMethod: insertUser.authMethod,
        createdAt: new Date(),
        lastActive: new Date()
      };
    }
    
    this.users.set(id, user);
    return user;
  }
  
  async updateUserLastActive(id: number): Promise<User | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;
    
    const updatedUser: User = {
      ...user,
      lastActive: new Date()
    };
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  // Profiles
  async getProfile(id: number): Promise<Profile | undefined> {
    return this.profiles.get(id);
  }
  
  async getProfileByUserId(userId: number): Promise<Profile | undefined> {
    return Array.from(this.profiles.values()).find(
      (profile) => profile.userId === userId
    );
  }
  
  async getProfiles(filters?: {
    gender?: string;
    minAge?: number;
    maxAge?: number;
    interests?: string[];
    limit?: number;
  }): Promise<Profile[]> {
    let result = Array.from(this.profiles.values());
    
    if (filters) {
      if (filters.gender) {
        result = result.filter(profile => profile.gender === filters.gender);
      }
      
      if (filters.minAge !== undefined && filters.minAge !== null) {
        const minAgeValue = filters.minAge;
        result = result.filter(profile => profile.age !== null && profile.age >= minAgeValue);
      }
      
      if (filters.maxAge !== undefined && filters.maxAge !== null) {
        const maxAgeValue = filters.maxAge;
        result = result.filter(profile => profile.age !== null && profile.age <= maxAgeValue);
      }
      
      if (filters.interests && filters.interests.length > 0) {
        result = result.filter(profile => 
          profile.interests !== null && 
          filters.interests!.some(interest => profile.interests!.includes(interest))
        );
      }
      
      if (filters.limit && filters.limit > 0) {
        result = result.slice(0, filters.limit);
      }
    }
    
    return result;
  }
  
  async createProfile(insertProfile: InsertProfile): Promise<Profile> {
    const id = this.currentProfileId++;
    const profile: Profile = {
      ...insertProfile,
      id,
      bio: insertProfile.bio || null,
      gender: insertProfile.gender || null,
      age: insertProfile.age || null,
      location: insertProfile.location || null,
      interests: insertProfile.interests || null,
      profilePicture: insertProfile.profilePicture || null,
      verificationStatus: false,
      reputationScore: 100,
      updatedAt: new Date()
    };
    this.profiles.set(id, profile);
    return profile;
  }
  
  async updateProfile(id: number, profileData: Partial<Profile>): Promise<Profile | undefined> {
    const profile = await this.getProfile(id);
    if (!profile) return undefined;
    
    const updatedProfile: Profile = {
      ...profile,
      ...profileData,
      updatedAt: new Date()
    };
    this.profiles.set(id, updatedProfile);
    return updatedProfile;
  }
  
  async updateVerificationStatus(id: number, status: boolean): Promise<Profile | undefined> {
    const profile = await this.getProfile(id);
    if (!profile) return undefined;
    
    const updatedProfile: Profile = {
      ...profile,
      verificationStatus: status,
      updatedAt: new Date()
    };
    this.profiles.set(id, updatedProfile);
    return updatedProfile;
  }
  
  async updateReputationScore(id: number, newScore: number): Promise<Profile | undefined> {
    const profile = await this.getProfile(id);
    if (!profile) return undefined;
    
    // Ensure score is within 0-100 range
    const clampedScore = Math.min(100, Math.max(0, newScore));
    
    const updatedProfile: Profile = {
      ...profile,
      reputationScore: clampedScore,
      updatedAt: new Date()
    };
    this.profiles.set(id, updatedProfile);
    return updatedProfile;
  }
  
  // Preferences
  async getPreference(id: number): Promise<Preference | undefined> {
    return this.preferences.get(id);
  }
  
  async getPreferenceByUserId(userId: number): Promise<Preference | undefined> {
    return Array.from(this.preferences.values()).find(
      (preference) => preference.userId === userId
    );
  }
  
  async createPreference(insertPreference: InsertPreference): Promise<Preference> {
    const id = this.currentPreferenceId++;
    const preference: Preference = {
      ...insertPreference,
      id,
      updatedAt: new Date(),
      minAge: insertPreference.minAge || null,
      maxAge: insertPreference.maxAge || null,
      genderPreference: insertPreference.genderPreference || null,
      locationPreference: insertPreference.locationPreference || null,
      interestPreference: insertPreference.interestPreference || null
    };
    this.preferences.set(id, preference);
    return preference;
  }
  
  async updatePreference(id: number, preferenceData: Partial<Preference>): Promise<Preference | undefined> {
    const preference = await this.getPreference(id);
    if (!preference) return undefined;
    
    const updatedPreference: Preference = {
      ...preference,
      ...preferenceData,
      updatedAt: new Date()
    };
    this.preferences.set(id, updatedPreference);
    return updatedPreference;
  }
  
  // Matches
  async getMatch(id: number): Promise<Match | undefined> {
    return this.matches.get(id);
  }
  
  async getMatchesByUserId(userId: number): Promise<Match[]> {
    return Array.from(this.matches.values()).filter(
      match => match.user1Id === userId || match.user2Id === userId
    ).sort((a, b) => {
      // Sort by lastInteractionAt if available, otherwise by createdAt
      const aDate = a.lastInteractionAt || a.createdAt;
      const bDate = b.lastInteractionAt || b.createdAt;
      return new Date(bDate).getTime() - new Date(aDate).getTime();
    });
  }
  
  async getPotentialMatches(userId: number, limit?: number): Promise<{ profile: Profile; matchQuality: number }[]> {
    // Get the user's profile
    const userProfile = await this.getProfileByUserId(userId);
    if (!userProfile) return [];
    
    // Get the user's preferences
    const userPreferences = await this.getPreferenceByUserId(userId);
    
    // Get all profiles that are not the user
    const allProfiles = Array.from(this.profiles.values())
      .filter(profile => profile.userId !== userId);
    
    // Calculate match quality for each profile
    const potentialMatches = await Promise.all(
      allProfiles.map(async profile => {
        // Simple matching algorithm - can be made more sophisticated
        let matchQuality = 50; // Base score
        
        // Check if already matched
        const existingMatch = Array.from(this.matches.values()).find(
          match => (match.user1Id === userId && match.user2Id === profile.userId) ||
                  (match.user1Id === profile.userId && match.user2Id === userId)
        );
        
        if (existingMatch && existingMatch.status !== 'rejected') {
          return null; // Skip already matched users
        }
        
        // Apply preference filters if available
        if (userPreferences) {
          // Gender preference match
          if (userPreferences.genderPreference && profile.gender === userPreferences.genderPreference) {
            matchQuality += 10;
          }
          
          // Age preference match
          if (profile.age !== null && 
              userPreferences.minAge !== null && 
              userPreferences.maxAge !== null &&
              profile.age >= userPreferences.minAge && 
              profile.age <= userPreferences.maxAge) {
            matchQuality += 10;
          }
          
          // Location preference match
          if (userPreferences.locationPreference && profile.location === userPreferences.locationPreference) {
            matchQuality += 10;
          }
          
          // Interest match
          if (userPreferences.interestPreference && userPreferences.interestPreference.length > 0 &&
              profile.interests !== null && profile.interests.length > 0) {
            const commonInterests = userPreferences.interestPreference.filter(
              interest => profile.interests!.includes(interest)
            );
            matchQuality += commonInterests.length * 5;
          }
        }
        
        // Additional factors
        if (profile.verificationStatus) {
          matchQuality += 5; // Bonus for verified profiles
        }
        
        // Reputation score factor
        if (profile.reputationScore !== null) {
          if (profile.reputationScore > 80) {
            matchQuality += 5; // Bonus for high reputation
          } else if (profile.reputationScore < 50) {
            matchQuality -= 5; // Penalty for low reputation
          }
        }
        
        return { profile, matchQuality };
      })
    );
    
    // Filter out nulls and sort by match quality
    const validMatches = potentialMatches
      .filter(match => match !== null) as { profile: Profile; matchQuality: number }[];
    
    validMatches.sort((a, b) => b.matchQuality - a.matchQuality);
    
    if (limit && limit > 0) {
      return validMatches.slice(0, limit);
    }
    
    return validMatches;
  }
  
  async createMatch(insertMatch: InsertMatch): Promise<Match> {
    const id = this.currentMatchId++;
    const match: Match = {
      ...insertMatch,
      id,
      status: insertMatch.status || "pending",
      matchQuality: insertMatch.matchQuality || null,
      createdAt: new Date(),
      lastInteractionAt: null
    };
    this.matches.set(id, match);
    return match;
  }
  
  async updateMatchStatus(id: number, status: string): Promise<Match | undefined> {
    const match = await this.getMatch(id);
    if (!match) return undefined;
    
    const updatedMatch: Match = {
      ...match,
      status,
      lastInteractionAt: new Date()
    };
    this.matches.set(id, updatedMatch);
    return updatedMatch;
  }
  
  async updateLastInteraction(id: number): Promise<Match | undefined> {
    const match = await this.getMatch(id);
    if (!match) return undefined;
    
    const updatedMatch: Match = {
      ...match,
      lastInteractionAt: new Date()
    };
    this.matches.set(id, updatedMatch);
    return updatedMatch;
  }
  
  // Messages
  async getMessage(id: number): Promise<Message | undefined> {
    return this.messages.get(id);
  }
  
  async getMessagesByMatchId(matchId: number): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter(message => message.matchId === matchId)
      .sort((a, b) => new Date(a.sentAt).getTime() - new Date(b.sentAt).getTime());
  }
  
  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const id = this.currentMessageId++;
    const message: Message = {
      ...insertMessage,
      id,
      sentAt: new Date(),
      readAt: null,
      ipfsHash: insertMessage.ipfsHash || null,
      isEncrypted: insertMessage.isEncrypted || null
    };
    this.messages.set(id, message);
    
    // Update the last interaction time for the match
    await this.updateLastInteraction(insertMessage.matchId);
    
    return message;
  }
  
  async markMessageAsRead(id: number): Promise<Message | undefined> {
    const message = await this.getMessage(id);
    if (!message) return undefined;
    
    const updatedMessage: Message = {
      ...message,
      readAt: new Date()
    };
    this.messages.set(id, updatedMessage);
    return updatedMessage;
  }
  
  // Ratings
  async getRating(id: number): Promise<Rating | undefined> {
    return this.ratings.get(id);
  }
  
  async getRatingsByToUserId(userId: number): Promise<Rating[]> {
    return Array.from(this.ratings.values())
      .filter(rating => rating.toUserId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }
  
  async getRatingByUserPair(fromUserId: number, toUserId: number): Promise<Rating | undefined> {
    return Array.from(this.ratings.values()).find(
      rating => rating.fromUserId === fromUserId && rating.toUserId === toUserId
    );
  }
  
  async createRating(insertRating: InsertRating): Promise<Rating> {
    const id = this.currentRatingId++;
    const rating: Rating = {
      ...insertRating,
      id,
      createdAt: new Date(),
      comment: insertRating.comment || null,
      verifiedInteraction: insertRating.verifiedInteraction || null
    };
    this.ratings.set(id, rating);
    
    // Update the reputation score of the rated user
    const existingRatings = await this.getRatingsByToUserId(insertRating.toUserId);
    const totalRatings = existingRatings.length;
    
    if (totalRatings > 0) {
      const avgScore = existingRatings.reduce((sum, r) => sum + r.score, 0) / totalRatings;
      // Convert 1-5 scale to 0-100 scale
      const newReputationScore = Math.round(avgScore * 20);
      
      // Find the user's profile to update reputation
      const userProfile = await this.getProfileByUserId(insertRating.toUserId);
      if (userProfile) {
        await this.updateReputationScore(userProfile.id, newReputationScore);
      }
    }
    
    return rating;
  }
  
  // Token Transactions
  async getTokenTransaction(id: number): Promise<TokenTransaction | undefined> {
    return this.tokenTransactions.get(id);
  }
  
  async getTokenTransactionsByUserId(userId: number): Promise<TokenTransaction[]> {
    return Array.from(this.tokenTransactions.values())
      .filter(transaction => transaction.userId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }
  
  async createTokenTransaction(insertTransaction: InsertTokenTransaction): Promise<TokenTransaction> {
    const id = this.currentTokenTransactionId++;
    const transaction: TokenTransaction = {
      ...insertTransaction,
      id,
      createdAt: new Date(),
      description: insertTransaction.description || null,
      transactionHash: insertTransaction.transactionHash || null
    };
    this.tokenTransactions.set(id, transaction);
    return transaction;
  }
  
  async getUserTokenBalance(userId: number): Promise<number> {
    const transactions = await this.getTokenTransactionsByUserId(userId);
    return transactions.reduce((balance, tx) => balance + tx.amount, 0);
  }
  
  // Auth Tokens
  async getAuthToken(id: number): Promise<AuthToken | undefined> {
    return this.authTokens.get(id);
  }
  
  async getAuthTokenByToken(token: string): Promise<AuthToken | undefined> {
    return Array.from(this.authTokens.values()).find(
      (authToken) => authToken.token === token
    );
  }
  
  async getAuthTokensByUserId(userId: number): Promise<AuthToken[]> {
    return Array.from(this.authTokens.values())
      .filter(authToken => authToken.userId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }
  
  async createAuthToken(insertAuthToken: InsertAuthToken): Promise<AuthToken> {
    const id = this.currentAuthTokenId++;
    const authToken: AuthToken = {
      ...insertAuthToken,
      id,
      createdAt: new Date(),
      revokedAt: null
    };
    this.authTokens.set(id, authToken);
    return authToken;
  }
  
  async revokeAuthToken(id: number): Promise<AuthToken | undefined> {
    const authToken = await this.getAuthToken(id);
    if (!authToken) return undefined;
    
    const updatedAuthToken: AuthToken = {
      ...authToken,
      revokedAt: new Date()
    };
    this.authTokens.set(id, updatedAuthToken);
    return updatedAuthToken;
  }
  
  async revokeAllUserTokens(userId: number): Promise<void> {
    const tokens = await this.getAuthTokensByUserId(userId);
    const now = new Date();
    
    for (const token of tokens) {
      if (!token.revokedAt) {
        const updatedToken: AuthToken = {
          ...token,
          revokedAt: now
        };
        this.authTokens.set(token.id, updatedToken);
      }
    }
  }
}

export const storage = new MemStorage();
