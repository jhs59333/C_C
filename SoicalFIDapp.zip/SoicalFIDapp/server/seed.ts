import { storage } from './storage';
import { InsertUser, InsertProfile, InsertPreference, InsertMatch, InsertMessage, InsertRating, InsertTokenTransaction } from '../shared/schema';

async function seed() {
  console.log('🌱 開始添加演示數據...');

  // 創建用戶
  const users: InsertUser[] = [
    {
      walletAddress: '0x1234567890abcdef1234567890abcdef12345678',
      username: 'alice123',
      password: 'password123',
    },
    {
      walletAddress: '0xabcdef1234567890abcdef1234567890abcdef12',
      username: 'bob456',
      password: 'password456',
    },
    {
      walletAddress: '0x7890abcdef1234567890abcdef1234567890abcd',
      username: 'carol789',
      password: 'password789',
    },
    {
      walletAddress: '0xdef1234567890abcdef1234567890abcdef12345',
      username: 'david321',
      password: 'password321',
    },
    {
      walletAddress: '0x4567890abcdef1234567890abcdef1234567890a',
      username: 'emma654',
      password: 'password654',
    },
    {
      walletAddress: '0x1111222233334444555566667777888899990000',
      username: 'jason888',
      password: 'password888',
    },
    {
      walletAddress: '0x0000999988887777666655554444333322221111',
      username: 'lily777',
      password: 'password777',
    },
    {
      walletAddress: '0xaaaa1111bbbb2222cccc3333dddd4444eeee5555',
      username: 'mike555',
      password: 'password555',
    },
    {
      walletAddress: '0x5555eeee4444dddd3333cccc2222bbbb1111aaaa',
      username: 'rachel222',
      password: 'password222',
    },
    {
      walletAddress: '0xabababababababababababababababababababab',
      username: 'kevin999',
      password: 'password999',
    },
  ];

  const createdUsers = [];
  for (const user of users) {
    const createdUser = await storage.createUser(user);
    createdUsers.push(createdUser);
    console.log(`👤 創建用戶: ${user.username}`);
  }

  // 創建資料
  const profiles: InsertProfile[] = [
    {
      userId: createdUsers[0].id,
      displayName: 'Alice Wang',
      bio: '喜歡旅行和攝影，尋找志同道合的伴侶。',
      gender: '女',
      age: 28,
      location: '台北',
      interests: ['攝影', '旅行', '瑜伽', '電影'],
      profilePicture: 'https://randomuser.me/api/portraits/women/12.jpg',
    },
    {
      userId: createdUsers[1].id,
      displayName: 'Bob Chen',
      bio: '軟體工程師，喜歡健身和戶外活動。',
      gender: '男',
      age: 32,
      location: '台中',
      interests: ['健身', '編程', '登山', '電子遊戲'],
      profilePicture: 'https://randomuser.me/api/portraits/men/22.jpg',
    },
    {
      userId: createdUsers[2].id,
      displayName: 'Carol Lin',
      bio: '藝術家，喜歡繪畫和音樂。尋找有創意的靈魂。',
      gender: '女',
      age: 26,
      location: '高雄',
      interests: ['繪畫', '音樂', '戲劇', '文學'],
      profilePicture: 'https://randomuser.me/api/portraits/women/33.jpg',
    },
    {
      userId: createdUsers[3].id,
      displayName: 'David Wu',
      bio: '廚師，美食愛好者。喜歡探索新的口味和文化。',
      gender: '男',
      age: 30,
      location: '台北',
      interests: ['烹飪', '美食', '旅行', '咖啡'],
      profilePicture: 'https://randomuser.me/api/portraits/men/44.jpg',
    },
    {
      userId: createdUsers[4].id,
      displayName: 'Emma Chang',
      bio: '醫生，關心健康和福祉。尋找穩定和成熟的關係。',
      gender: '女',
      age: 34,
      location: '新竹',
      interests: ['健康', '瑜伽', '閱讀', '園藝'],
      profilePicture: 'https://randomuser.me/api/portraits/women/55.jpg',
    },
    {
      userId: createdUsers[5].id,
      displayName: 'Jason Liu',
      bio: '攝影師，喜歡捕捉生活中的美好時刻。尋找能一起探索世界的人。',
      gender: '男',
      age: 29,
      location: '台南',
      interests: ['攝影', '旅行', '電影', '咖啡'],
      profilePicture: 'https://randomuser.me/api/portraits/men/66.jpg',
    },
    {
      userId: createdUsers[6].id,
      displayName: 'Lily Huang',
      bio: '旅行部落客，已去過超過20個國家。熱愛冒險和新體驗。',
      gender: '女',
      age: 27,
      location: '台北',
      interests: ['旅行', '寫作', '攝影', '語言學習'],
      profilePicture: 'https://randomuser.me/api/portraits/women/77.jpg',
    },
    {
      userId: createdUsers[7].id,
      displayName: 'Mike Zhang',
      bio: '音樂製作人，熱愛各種音樂類型。尋找能一起分享生活旋律的人。',
      gender: '男',
      age: 31,
      location: '高雄',
      interests: ['音樂', '演唱會', '吉他', '數位製作'],
      profilePicture: 'https://randomuser.me/api/portraits/men/88.jpg',
    },
    {
      userId: createdUsers[8].id,
      displayName: 'Rachel Tsai',
      bio: '瑜伽老師，注重身心靈平衡。喜歡簡單而有意義的生活。',
      gender: '女',
      age: 29,
      location: '台中',
      interests: ['瑜伽', '冥想', '健康飲食', '閱讀'],
      profilePicture: 'https://randomuser.me/api/portraits/women/99.jpg',
    },
    {
      userId: createdUsers[9].id,
      displayName: 'Kevin Ho',
      bio: '室內設計師，喜歡創造舒適的空間。欣賞美的事物和獨特的設計。',
      gender: '男',
      age: 33,
      location: '台北',
      interests: ['設計', '藝術', '建築', '家居DIY'],
      profilePicture: 'https://randomuser.me/api/portraits/men/11.jpg',
    },
  ];

  const createdProfiles = [];
  for (const profile of profiles) {
    const createdProfile = await storage.createProfile(profile);
    createdProfiles.push(createdProfile);
    console.log(`👤 創建個人檔案: ${profile.displayName}`);
  }

  // 創建偏好
  const preferences: InsertPreference[] = [
    {
      userId: createdUsers[0].id,
      minAge: 25,
      maxAge: 40,
      genderPreference: '男',
      locationPreference: '台北',
      interestPreference: ['旅行', '健身', '電影'],
    },
    {
      userId: createdUsers[1].id,
      minAge: 25,
      maxAge: 35,
      genderPreference: '女',
      locationPreference: '台中',
      interestPreference: ['瑜伽', '攝影', '電影'],
    },
    {
      userId: createdUsers[2].id,
      minAge: 25,
      maxAge: 38,
      genderPreference: '男',
      locationPreference: '高雄',
      interestPreference: ['音樂', '藝術', '文學'],
    },
    {
      userId: createdUsers[3].id,
      minAge: 25,
      maxAge: 35,
      genderPreference: '女',
      locationPreference: '台北',
      interestPreference: ['烹飪', '旅行', '音樂'],
    },
    {
      userId: createdUsers[4].id,
      minAge: 28,
      maxAge: 45,
      genderPreference: '男',
      locationPreference: '新竹',
      interestPreference: ['健康', '閱讀', '健身'],
    },
    {
      userId: createdUsers[5].id,
      minAge: 25,
      maxAge: 38,
      genderPreference: '女',
      locationPreference: '台南',
      interestPreference: ['攝影', '旅行', '藝術'],
    },
    {
      userId: createdUsers[6].id,
      minAge: 26,
      maxAge: 40,
      genderPreference: '男',
      locationPreference: '台北',
      interestPreference: ['旅行', '冒險', '運動'],
    },
    {
      userId: createdUsers[7].id,
      minAge: 25,
      maxAge: 40,
      genderPreference: '女',
      locationPreference: '高雄',
      interestPreference: ['音樂', '藝術', '電影'],
    },
    {
      userId: createdUsers[8].id,
      minAge: 27,
      maxAge: 42,
      genderPreference: '男',
      locationPreference: '台中',
      interestPreference: ['瑜伽', '健康', '冥想'],
    },
    {
      userId: createdUsers[9].id,
      minAge: 25,
      maxAge: 40,
      genderPreference: '女',
      locationPreference: '台北',
      interestPreference: ['設計', '藝術', '攝影'],
    },
  ];

  for (const preference of preferences) {
    await storage.createPreference(preference);
    console.log(`⚙️ 創建偏好設置: ${preference.userId}`);
  }

  // 創建匹配
  const matches: InsertMatch[] = [
    {
      user1Id: createdUsers[0].id,
      user2Id: createdUsers[1].id,
      status: 'matched',
      matchQuality: 85,
    },
    {
      user1Id: createdUsers[0].id,
      user2Id: createdUsers[3].id,
      status: 'pending',
      matchQuality: 78,
    },
    {
      user1Id: createdUsers[2].id,
      user2Id: createdUsers[1].id,
      status: 'matched',
      matchQuality: 92,
    },
    {
      user1Id: createdUsers[2].id,
      user2Id: createdUsers[3].id,
      status: 'rejected',
      matchQuality: 65,
    },
    {
      user1Id: createdUsers[4].id,
      user2Id: createdUsers[1].id,
      status: 'pending',
      matchQuality: 73,
    },
    {
      user1Id: createdUsers[5].id,
      user2Id: createdUsers[6].id,
      status: 'matched',
      matchQuality: 88,
    },
    {
      user1Id: createdUsers[7].id,
      user2Id: createdUsers[8].id,
      status: 'pending',
      matchQuality: 75,
    },
    {
      user1Id: createdUsers[9].id,
      user2Id: createdUsers[0].id,
      status: 'matched',
      matchQuality: 80,
    },
    {
      user1Id: createdUsers[6].id,
      user2Id: createdUsers[0].id,
      status: 'pending',
      matchQuality: 82,
    },
    {
      user1Id: createdUsers[8].id,
      user2Id: createdUsers[1].id,
      status: 'matched',
      matchQuality: 90,
    },
  ];

  const createdMatches = [];
  for (const match of matches) {
    const createdMatch = await storage.createMatch(match);
    createdMatches.push(createdMatch);
    console.log(`❤️ 創建匹配: 用戶${match.user1Id} 和 用戶${match.user2Id}`);
  }

  // 創建消息
  const messages: InsertMessage[] = [
    {
      matchId: createdMatches[0].id,
      senderId: createdUsers[0].id,
      content: '嗨，很高興認識你！',
      ipfsHash: null,
      isEncrypted: false,
    },
    {
      matchId: createdMatches[0].id,
      senderId: createdUsers[1].id,
      content: '你好！我也很高興認識你。你喜歡什麼活動？',
      ipfsHash: null,
      isEncrypted: false,
    },
    {
      matchId: createdMatches[0].id,
      senderId: createdUsers[0].id,
      content: '我喜歡攝影和旅行。你呢？',
      ipfsHash: null,
      isEncrypted: false,
    },
    {
      matchId: createdMatches[2].id,
      senderId: createdUsers[2].id,
      content: '嗨！你的個人檔案看起來很有趣。',
      ipfsHash: null,
      isEncrypted: false,
    },
    {
      matchId: createdMatches[2].id,
      senderId: createdUsers[1].id,
      content: '謝謝！我看到你是藝術家，真的很酷。你創作什麼類型的藝術？',
      ipfsHash: null,
      isEncrypted: false,
    },
  ];

  for (const message of messages) {
    await storage.createMessage(message);
    console.log(`✉️ 創建消息: ${message.content.substring(0, 15)}...`);
  }

  // 創建評分
  const ratings: InsertRating[] = [
    {
      fromUserId: createdUsers[0].id,
      toUserId: createdUsers[1].id,
      score: 5,
      comment: '非常好的交談和經驗！',
      verifiedInteraction: true,
    },
    {
      fromUserId: createdUsers[1].id,
      toUserId: createdUsers[0].id,
      score: 4,
      comment: '非常友好和有趣的人。',
      verifiedInteraction: true,
    },
    {
      fromUserId: createdUsers[2].id,
      toUserId: createdUsers[1].id,
      score: 5,
      comment: '有禮貌且有趣！',
      verifiedInteraction: true,
    },
    {
      fromUserId: createdUsers[1].id,
      toUserId: createdUsers[2].id,
      score: 5,
      comment: '真的很有創意和有趣。',
      verifiedInteraction: true,
    },
    {
      fromUserId: createdUsers[5].id,
      toUserId: createdUsers[6].id,
      score: 5,
      comment: '很好的旅行伙伴！聊天很愉快。',
      verifiedInteraction: true,
    },
    {
      fromUserId: createdUsers[6].id,
      toUserId: createdUsers[5].id,
      score: 4,
      comment: '很有趣的人，分享了很多旅行故事。',
      verifiedInteraction: true,
    },
    {
      fromUserId: createdUsers[9].id,
      toUserId: createdUsers[0].id,
      score: 5,
      comment: '真誠的人，交流非常愉快！',
      verifiedInteraction: true,
    },
    {
      fromUserId: createdUsers[7].id,
      toUserId: createdUsers[8].id,
      score: 4,
      comment: '很有智慧的人，談吐優雅。',
      verifiedInteraction: true,
    },
    {
      fromUserId: createdUsers[8].id,
      toUserId: createdUsers[1].id,
      score: 5,
      comment: '健談且幽默，絕對值得更多了解！',
      verifiedInteraction: true,
    },
    {
      fromUserId: createdUsers[3].id,
      toUserId: createdUsers[0].id,
      score: 4,
      comment: '攝影技巧很棒，很有共同話題。',
      verifiedInteraction: true,
    },
  ];

  for (const rating of ratings) {
    await storage.createRating(rating);
    console.log(`⭐ 創建評分: ${rating.fromUserId} 給 ${rating.toUserId} ${rating.score}星`);
  }

  // 創建代幣交易
  const tokenTransactions: InsertTokenTransaction[] = [
    {
      userId: createdUsers[0].id,
      amount: 100,
      transactionType: 'reward',
      description: '註冊獎勵',
      transactionHash: '0xabc123def456',
    },
    {
      userId: createdUsers[1].id,
      amount: 100,
      transactionType: 'reward',
      description: '註冊獎勵',
      transactionHash: '0xdef456abc789',
    },
    {
      userId: createdUsers[2].id,
      amount: 100,
      transactionType: 'reward',
      description: '註冊獎勵',
      transactionHash: '0x789abc123def',
    },
    {
      userId: createdUsers[3].id,
      amount: 100,
      transactionType: 'reward',
      description: '註冊獎勵',
      transactionHash: '0x111abc222def',
    },
    {
      userId: createdUsers[4].id,
      amount: 100,
      transactionType: 'reward',
      description: '註冊獎勵',
      transactionHash: '0x333abc444def',
    },
    {
      userId: createdUsers[5].id,
      amount: 100,
      transactionType: 'reward',
      description: '註冊獎勵',
      transactionHash: '0x555abc666def',
    },
    {
      userId: createdUsers[6].id,
      amount: 100,
      transactionType: 'reward',
      description: '註冊獎勵',
      transactionHash: '0x777abc888def',
    },
    {
      userId: createdUsers[7].id,
      amount: 100,
      transactionType: 'reward',
      description: '註冊獎勵',
      transactionHash: '0x999abc000def',
    },
    {
      userId: createdUsers[8].id,
      amount: 100,
      transactionType: 'reward',
      description: '註冊獎勵',
      transactionHash: '0xaaabbbcccdef',
    },
    {
      userId: createdUsers[9].id,
      amount: 100,
      transactionType: 'reward',
      description: '註冊獎勵',
      transactionHash: '0xdddeeefff123',
    },
    {
      userId: createdUsers[0].id,
      amount: 50,
      transactionType: 'reward',
      description: '完成個人檔案',
      transactionHash: '0x123abc456def',
    },
    {
      userId: createdUsers[1].id,
      amount: 30,
      transactionType: 'reward',
      description: '獲得好評',
      transactionHash: '0x456def789abc',
    },
    {
      userId: createdUsers[2].id,
      amount: 25,
      transactionType: 'reward',
      description: '獲得好評',
      transactionHash: '0xabc789def456',
    },
    {
      userId: createdUsers[5].id,
      amount: 40,
      transactionType: 'reward',
      description: '優質內容分享',
      transactionHash: '0x654fed321cba',
    },
    {
      userId: createdUsers[7].id,
      amount: 35,
      transactionType: 'reward',
      description: '優質互動',
      transactionHash: '0x321cba654fed',
    },
    {
      userId: createdUsers[0].id,
      amount: -20,
      transactionType: 'purchase',
      description: '提升個人檔案可見度',
      transactionHash: '0xabc789def123',
    },
    {
      userId: createdUsers[1].id,
      amount: -15,
      transactionType: 'purchase',
      description: '加入特色會員',
      transactionHash: '0xfedcba987654',
    },
    {
      userId: createdUsers[5].id,
      amount: -25,
      transactionType: 'purchase',
      description: '解鎖進階篩選功能',
      transactionHash: '0x123456789abc',
    },
  ];

  for (const transaction of tokenTransactions) {
    await storage.createTokenTransaction(transaction);
    console.log(`💰 創建代幣交易: ${transaction.userId} ${transaction.amount > 0 ? '+' : ''}${transaction.amount} 代幣`);
  }

  console.log('✅ 演示數據添加完成！');
}

// 導出供其他文件使用
export { seed };